/* app-main.js | v8.1 模組化架構版 | 原 v8.0.2 穩定核心 */
const firebaseConfig = {
  apiKey: "AIzaSyA7jsfNZBaAvAp4ENS-gOX2CrAG6m832Ls",
  authDomain: "battle-panflute-system.firebaseapp.com",
  databaseURL: "https://battle-panflute-system-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "battle-panflute-system",
  storageBucket: "battle-panflute-system.firebasestorage.app",
  messagingSenderId: "1056217759582",
  appId: "1:1056217759582:web:6907f5c42f164b071599cf",
  measurementId: "G-5NJM5SRBL2"
};
firebase.initializeApp(firebaseConfig);
const firebaseDb = firebase.database();

window.addEventListener('unhandledrejection', function(e){ console.error(e.reason); });

window.addEventListener('error', function(e){
  const app = document.getElementById("app");
  if(app){
    app.innerHTML = `<section class="card"><h3>⚠️ 系統載入錯誤</h3><div class="note">${e.message}<br>${e.filename}:${e.lineno}</div></section>`;
  }
});
"use strict";

/* =========================================================
   V7_0_1 SAFE GLOBAL FALLBACKS
   ========================================================= */
function v7NormalizeState(){
  try{
    if(typeof state !== "object" || !state) return;
    const arr = v => Array.isArray(v) ? v : [];
    const obj = v => (v && typeof v === "object" && !Array.isArray(v)) ? v : {};
    state.schools = arr(state.schools);
    state.classes = arr(state.classes);
    state.students = arr(state.students);
    state.enrollments = arr(state.enrollments);
    state.courseNotes = arr(state.courseNotes);
    state.growthLogs = arr(state.growthLogs);
    state.pointLogs = arr(state.pointLogs);
    state.redeemLogs = arr(state.redeemLogs);
    state.performances = arr(state.performances);
    state.unfinishedTasks = obj(state.unfinishedTasks);
    state.weeklyMainline = obj(state.weeklyMainline);
    state.backupMeta = obj(state.backupMeta);
    state.cloud = obj(state.cloud);
    state.settings = obj(state.settings);
  }catch(e){
    console.warn("v7NormalizeState fallback failed", e);
  }
}

function v7PageTitle(pageId){
  const titles = {
    classroom:"上課介面",
    performance:"演出中心",
    exam:"升級考試",
    rewards:"獎品兌換",
    stats:"統計排行",
    history:"紀錄查詢",
    settings:"設定中心",
    guide:"教學手冊"
  };
  return titles[pageId] || "教學管理系統";
}

function safeCurrentPage(){
  const allowed = ["classroom","performance","exam","rewards","stats","history","settings","guide"];
  if(typeof currentPage === "undefined" || !allowed.includes(currentPage)) currentPage = "classroom";
  return currentPage;
}

function v7SafeRender(){
  try{
    const page = safeCurrentPage();
    if(page === "classroom") return renderClassroom();
    if(page === "performance") return (typeof renderPerformanceCenter==="function" ? renderPerformanceCenter() : renderClassroom());
    if(page === "exam") return renderExam();
    if(page === "rewards") return renderRewards();
    if(page === "stats") return renderStats();
    if(page === "history") return renderHistory();
    if(page === "settings") return renderSettings();
    if(page === "guide") return renderGuide();
    return renderClassroom();
  }catch(err){
    console.error("v7SafeRender fallback failed", err);
    const app = document.getElementById("app");
    if(app){
      app.innerHTML = `<section class="card"><h3>⚠️ 頁面保護</h3><div class="note">${escapeHtml(err.message || String(err))}</div><button class="btn primary" onclick="currentPage='classroom'; render()">回上課介面</button></section>`;
    }
  }
}


/* =========================================================
   0. STORAGE / DEFAULT DATA
   ========================================================= */
const STORE_KEY = "bt_teaching_system_v2_structured";
const IMGBB_API_KEY = "d6360ffb3a542876b1862f7e4e5debb9";
const makeId = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
function today(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}
function localDateTimeString(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}`;
}
function localIsoLikeString(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}+08:00`;
}

function currentAcademicTermId(dateStr=today()){
  const d = new Date(dateStr);
  const y = d.getFullYear();
  const m = d.getMonth()+1;
  const schoolYear = m >= 8 ? y - 1911 : y - 1912;
  const semester = (m >= 8 || m <= 1) ? 1 : 2;
  return `${schoolYear}-${semester}`;
}

function currentAcademicTermLabel(dateStr=today()){
  const [year, sem] = currentAcademicTermId(dateStr).split("-");
  return `${year}學年 ${sem === "1" ? "上學期" : "下學期"}`;
}

function buildAcademicTerms(){
  const currentId = currentAcademicTermId();
  const [currentYearRaw] = currentId.split("-");
  const currentYear = Number(currentYearRaw);
  const terms = [];
  for(let year=currentYear-1; year<=currentYear+2; year++){
    terms.push({id:`${year}-1`,name:`${year}學年 上學期`,active:true});
    terms.push({id:`${year}-2`,name:`${year}學年 下學期`,active:true});
  }
  return terms;
}

function buildDefaultState(){
  const schoolId = makeId();
  const classA = makeId();
  const classB = makeId();
  const s1 = makeId(), s2 = makeId(), s3 = makeId();

  return {
    settings:{
      systemName:"教學管理系統",
      attendPoint:1,
      bonusSmall:1,
      bonusBig:5,
      penalty:-1,
      upgradeReward:5
    },
    pointActions:[
      {id:"pa_bonus_small",name:"+1",amount:1,active:true,order:1},
      {id:"pa_bonus_big",name:"+5",amount:5,active:true,order:2},
      {id:"pa_penalty",name:"-1",amount:-1,active:true,order:3}
    ],
    academicTerms:buildAcademicTerms(),
    classDateLists:{},
    hiddenDateLists:{},
    schools:[
      {id:schoolId,name:"銅蘭國小",active:true}
    ],
    classes:[
      {id:classA,schoolId,name:"三年級",order:1,active:true},
      {id:classB,schoolId,name:"排笛隊",order:2,active:true}
    ],
    students:[
      {id:s1,name:"任琪",seat:"1",stageId:"basic",level:1,active:true},
      {id:s2,name:"古雪芙",seat:"2",stageId:"basic",level:2,active:true},
      {id:s3,name:"高海媚",seat:"3",stageId:"basic",level:1,active:true}
    ],
    enrollments:[
      {studentId:s1,classId:classA},
      {studentId:s2,classId:classA},
      {studentId:s3,classId:classA},
      {studentId:s1,classId:classB}
    ],
    points:{
      [s1]:2,
      [s2]:4,
      [s3]:1
    },
    attendance:[],
    pointLogs:[],
    courseNotes:[],
    examLogs:[],
    rewards:[
      {id:"demo_reward_sticker",name:"星星貼紙",cost:5,stock:20,image:"",active:true},
      {id:"demo_reward_pencil",name:"可愛鉛筆",cost:10,stock:12,image:"",active:true}
    ],
    redeemLogs:[],
    growthLogs:[],
    growthSettings:{
      xpLevels:[
        {level:1,xp:0,title:"🌱 排笛幼苗"},
        {level:2,xp:100,title:"🌬 氣息學徒"},
        {level:3,xp:250,title:"🥁 節奏旅人"},
        {level:4,xp:500,title:"🎵 旋律冒險家"},
        {level:5,xp:900,title:"🐍 百步蛇勇者"},
        {level:6,xp:1400,title:"🏰 維也納小演奏家"}
      ],
      growthTypes:[
        {id:"breath",name:"氣息",active:true,order:1,defaultXp:10,defaultFeedback:"氣息控制有進步，能更穩定地完成練習。"},
        {id:"tone",name:"音色",active:true,order:2,defaultXp:10,defaultFeedback:"音色更集中，吹奏品質比上次更穩。"},
        {id:"rhythm",name:"節奏",active:true,order:3,defaultXp:10,defaultFeedback:"節奏掌握有進步，能跟上拍點。"},
        {id:"reading",name:"視譜",active:true,order:4,defaultXp:10,defaultFeedback:"視譜反應變快，能更主動辨認音符。"},
        {id:"ensemble",name:"合奏",active:true,order:5,defaultXp:10,defaultFeedback:"合奏時能注意聆聽同伴，配合度提升。"},
        {id:"helping",name:"幫助同學",active:true,order:6,defaultXp:15,defaultFeedback:"主動幫助同學，展現很好的團隊精神。"},
        {id:"attitude",name:"學習態度",active:true,order:7,defaultXp:10,defaultFeedback:"今天學習態度專注，願意嘗試修正。"},
        {id:"challenge",name:"挑戰精神",active:true,order:8,defaultXp:15,defaultFeedback:"願意挑戰較難內容，值得肯定。"},
        {id:"adjust",name:"XP修正",active:true,order:99,defaultXp:-10,defaultFeedback:"XP 誤按修正。"}
      ]
    },
    activityLogs:[],
    backupMeta:{lastExportAt:""},
    cloudConfig:{gasUrl:""},
    levelStages:[
      {id:"basic",name:"初階",start:1,end:10,unit:"級",order:1,active:true},
      {id:"mid",name:"中階",start:11,end:25,unit:"級",order:2,active:true},
      {id:"high",name:"高階",start:26,end:50,unit:"級",order:3,active:true},
      {id:"pro",name:"演奏家",start:1,end:15,unit:"級",order:4,active:true}
    ],
    levelFields:[
      {id:"name",name:"名稱",order:1,active:true},
      {id:"ability",name:"能力指標",order:2,active:true},
      {id:"technique",name:"技巧重點",order:3,active:true},
      {id:"rhythm",name:"節奏能力",order:4,active:true},
      {id:"range",name:"音域範圍",order:5,active:true},
      {id:"songs",name:"建議曲目",order:6,active:true},
      {id:"standard",name:"通過標準",order:7,active:true},
      {id:"teacherNote",name:"老師備註",order:8,active:true}
    ],
    levelContents:{},
    examChecklists:{}
  };
}

function migrateState(data){
  const fallback = buildDefaultState();
  const merged = {...fallback, ...data};
  merged.settings = {...fallback.settings, ...(data.settings || {})};
  for(const key of ["schools","classes","students","enrollments","attendance","pointLogs","courseNotes","examLogs","rewards","redeemLogs","growthLogs","activityLogs","pointActions","academicTerms","levelStages","levelFields"]){
    if(!Array.isArray(merged[key])) merged[key] = fallback[key];
  }
  if(typeof merged.points !== "object" || !merged.points) merged.points = {};
  if(typeof merged.levelContents !== "object" || !merged.levelContents) merged.levelContents = {};
  if(typeof merged.growthSettings !== "object" || !merged.growthSettings) merged.growthSettings = fallback.growthSettings;
  if(!Array.isArray(merged.growthSettings.xpLevels)) merged.growthSettings.xpLevels = fallback.growthSettings.xpLevels;
  if(!Array.isArray(merged.growthSettings.growthTypes)) merged.growthSettings.growthTypes = fallback.growthSettings.growthTypes;
  if(typeof merged.examChecklists !== "object" || !merged.examChecklists) merged.examChecklists = {};
  if(typeof merged.backupMeta !== "object" || !merged.backupMeta) merged.backupMeta = {lastExportAt:""};
  if(typeof merged.cloudConfig !== "object" || !merged.cloudConfig) merged.cloudConfig = {gasUrl:""};
  if(typeof merged.classDateLists !== "object" || !merged.classDateLists) merged.classDateLists = {};
  if(typeof merged.hiddenDateLists !== "object" || !merged.hiddenDateLists) merged.hiddenDateLists = {};
  if(!Array.isArray(merged.academicTerms)) merged.academicTerms = buildAcademicTerms();
  if(!merged.academicTerms.some(t=>t.id===currentAcademicTermId())){
    merged.academicTerms = [...buildAcademicTerms(), ...merged.academicTerms].filter((term,index,self)=>self.findIndex(t=>t.id===term.id)===index);
  }
  if(!merged.academicTerms.some(t=>t.id===currentAcademicTermId())){
    merged.academicTerms = [...buildAcademicTerms(), ...merged.academicTerms].filter((term,index,self)=>self.findIndex(t=>t.id===term.id)===index);
  }
  merged.levelStages.forEach(x => { if(typeof x.active === "undefined") x.active = true; });
  merged.schools.forEach(x => { if(typeof x.active === "undefined") x.active = true; });
  merged.classes.forEach(x => { if(typeof x.active === "undefined") x.active = true; });
  merged.students.forEach(x => { if(typeof x.active === "undefined") x.active = true; });
  return merged;
}

function loadState(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    if(!raw) return buildDefaultState();
    return migrateState(JSON.parse(raw));
  }catch(err){
    console.warn(err);
    return buildDefaultState();
  }
}

function saveState(){
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
}


/* =========================================================
   CLEAN CORE: FIREBASE SYNC
   - Firebase 為主同步
   - Google Sheet 保留為備份
   - 時間統一使用 localIsoLikeString()
   ========================================================= */
/* SYNC MODULE: Firebase Upload */
async function firebaseUploadAll(silent=false, force=false) {
  try {
    if (typeof firebase === "undefined" || typeof firebaseDb === "undefined") {
      if(!silent) alert("Firebase 尚未載入，請重新整理頁面。");
      return;
    }
    if(!force){
      return guardedFirebaseUpload(silent);
    }

    syncStatus.syncing = true;
    syncStatus.lastError = "";
    renderSyncStatus();

    ensureBackupMeta();
    state.backupMeta.lastFirebaseUploadAt = localIsoLikeString();
    state.backupMeta.lastFirebaseUploadMs = Date.now();
    state.backupMeta.lastLocalChangeAt = state.backupMeta.lastFirebaseUploadAt;
    state.backupMeta.lastLocalChangeMs = state.backupMeta.lastFirebaseUploadMs;

    await firebaseDb.ref("battleSystem/main").set({
      updatedAt: Date.now(),
      updatedAtText: localIsoLikeString(),
      state: JSON.parse(JSON.stringify(state))
    });

    syncStatus.syncing = false;
    syncStatus.cloudIsNewer = false;
    hideCloudWarning?.();
    markClean();
    render();
    if(!silent) alert("🔥 Firebase 上傳成功");
  } catch (err) {
    console.error("Firebase upload failed:", err);
    syncStatus.syncing = false;
    syncStatus.lastError = err && err.message ? err.message : String(err);
    renderSyncStatus();
    if(!silent) alert("Firebase 上傳失敗：" + syncStatus.lastError);
  }
}

/* SYNC MODULE: Firebase Download */
async function firebaseDownloadAll() {
  try {
    if (typeof firebase === "undefined" || typeof firebaseDb === "undefined") {
      return alert("Firebase 尚未載入，請重新整理頁面。");
    }
    syncStatus.syncing = true;
    syncStatus.lastError = "";
    renderSyncStatus();

    const snap = await firebaseDb.ref("battleSystem/main").once("value");
    if (!snap.exists()) {
      syncStatus.syncing = false;
      renderSyncStatus();
      return alert("Firebase 沒有資料");
    }

    const data = snap.val();
    if (!data || !data.state) {
      syncStatus.syncing = false;
      renderSyncStatus();
      return alert("Firebase 資料格式錯誤");
    }

    state = migrateState(data.state);
    ensureBackupMeta();
    state.backupMeta.lastFirebaseDownloadAt = localIsoLikeString();
    state.backupMeta.lastFirebaseDownloadMs = Date.now();
    state.backupMeta.lastLocalChangeMs = Number(data.updatedAt || Date.now());
    hideCloudWarning();

    syncStatus.syncing = false;
    syncStatus.dirty = false;
    syncStatus.lastError = "";
    syncStatus.lastFirebaseSyncAt = state.backupMeta.lastFirebaseDownloadAt;
    syncStatus.cloudIsNewer = false;
    syncStatus.cloudUpdatedAt = Number(data.updatedAt || 0);

    saveState();
    render();
    renderSyncStatus();
    alert("🔥 Firebase 讀取成功");
  } catch (err) {
    console.error("Firebase download failed:", err);
    syncStatus.syncing = false;
    syncStatus.lastError = err && err.message ? err.message : String(err);
    renderSyncStatus();
    alert("Firebase 下載失敗：" + syncStatus.lastError);
  }
}


let state = loadState();

/* =========================================================
   MODULAR CLEAN CORE
   ---------------------------------------------------------
   維持單檔 index.html，避免 GitHub Pages 路徑與快取問題。
   但內部以模組化概念整理：
   Core / Sync / Lesson / Growth / Report / UI
   ========================================================= */
const BattleModules = {
  version:"v6.1 Modular Clean Core",
  core:{},
  sync:{},
  lesson:{},
  growth:{},
  report:{},
  ui:{}
};

function ensureArray(value){ return Array.isArray(value) ? value : []; }
function ensureObject(value){ return value && typeof value === "object" && !Array.isArray(value) ? value : {}; }
function safeText(value,fallback=""){ return value === undefined || value === null ? fallback : String(value); }

function safeCall(name,fn,fallback=null){
  try{ return typeof fn === "function" ? fn() : fallback; }
  catch(err){ console.error(`[${name}]`,err); return fallback; }
}

function requireHelpers(names){
  const missing = names.filter(name => typeof window[name] !== "function");
  if(missing.length) console.warn("Missing helpers:", missing.join(", "));
  return missing;
}

function systemHealthCheck(){
  return {
    version:BattleModules.version,
    requiredMissing:requireHelpers([
      "saveState",
      "render",
      "firebaseUploadAll",
      "firebaseDownloadAll",
      "renderBackupSettings",
      "renderClassroomNotes",
      "saveLinkedCourseNote",
      "daysAgoText",
      "getCloudConfig"
    ]),
    hasFirebase:typeof firebase !== "undefined",
    hasFirebaseDb:typeof firebaseDb !== "undefined",
    hasState:typeof state === "object"
  };
}

BattleModules.core.healthCheck = systemHealthCheck;



/* =========================================================
   UI MODULE: ADAPTIVE DEVICE MODE
   ========================================================= */
function detectTouchMode(){
  const isTouch = (
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0 ||
    window.innerWidth <= 900
  );

  document.body.classList.toggle("touch-mode", isTouch);
  document.body.classList.toggle("desktop-mode", !isTouch);

  renderDeviceBadge(isTouch);
  renderTouchToolbar(isTouch);

  return isTouch;
}

function renderDeviceBadge(isTouch){
  let badge = document.getElementById("deviceModeBadge");

  if(!badge){
    badge = document.createElement("div");
    badge.id = "deviceModeBadge";
    badge.className = "device-badge";
    document.body.appendChild(badge);
  }

  badge.textContent = isTouch ? "📱 平板 / 觸控模式" : "🖥️ 桌面模式";
}

function renderTouchToolbar(isTouch){
  let bar = document.getElementById("touchToolbar");

  if(!bar){
    bar = document.createElement("div");
    bar.id = "touchToolbar";
    bar.className = "touch-toolbar";
    document.body.appendChild(bar);
  }

  if(!isTouch){
    bar.innerHTML = "";
    return;
  }

  bar.innerHTML = `
    <button onclick="enterStartClassMode()">🎺 上課</button>
    <button onclick="guardedFirebaseUpload()">☁️ 同步</button>
    <button onclick="firebaseDownloadAll()">⬇️ 讀取</button>
    <button onclick="toggleThemeMode()">🌙 深色</button>
  `;
}

window.addEventListener("resize", function(){
  detectTouchMode();
});

function applyThemeMode(){
  const mode = localStorage.getItem("battle_theme_mode") || "light";
  document.body.classList.toggle("dark-mode", mode === "dark");
  renderThemeToggle();
}

/* UI MODULE: Theme Toggle */
function toggleThemeMode(){
  const current = localStorage.getItem("battle_theme_mode") || "light";
  localStorage.setItem("battle_theme_mode", current === "dark" ? "light" : "dark");
  applyThemeMode();
}

function renderThemeToggle(){
  let btn = document.getElementById("themeToggleBtn");
  if(!btn){
    btn = document.createElement("button");
    btn.id = "themeToggleBtn";
    btn.className = "theme-toggle";
    btn.onclick = toggleThemeMode;
    document.body.appendChild(btn);
  }
  const mode = localStorage.getItem("battle_theme_mode") || "light";
  btn.textContent = mode === "dark" ? "☀️ 淺色" : "🌙 深色";
}


let syncStatus = {
  dirty:false,
  syncing:false,
  checking:false,
  cloudIsNewer:false,
  lastError:"",
  cloudUpdatedAt:0,
  cloudUpdatedAtText:"",
  localUpdatedAt:state.backupMeta?.lastLocalChangeMs || state.backupMeta?.lastFirebaseUploadMs || 0,
  lastFirebaseSyncAt:state.backupMeta?.lastFirebaseUploadAt || ""
};


/* =========================================================
   CORE MODULE: STATE NORMALIZATION
   ========================================================= */
function normalizeStateShape(){
  state.schools = ensureArray(state.schools);
  state.classes = ensureArray(state.classes);
  state.students = ensureArray(state.students);
  state.enrollments = ensureArray(state.enrollments);
  state.courseNotes = ensureArray(state.courseNotes);
  state.growthLogs = ensureArray(state.growthLogs);
  state.pointLogs = ensureArray(state.pointLogs);
  state.redeemLogs = ensureArray(state.redeemLogs);
  state.backupMeta = ensureObject(state.backupMeta);
  state.weeklyMainline = ensureObject(state.weeklyMainline);
  state.modeTemplates = ensureArray(state.modeTemplates);
  state.curriculumTemplates = ensureArray(state.curriculumTemplates);
  state.cloud = ensureObject(state.cloud);
  return state;
}

BattleModules.core.normalizeState = normalizeStateShape;

function ensureBackupMeta(){
  if(!state.backupMeta) state.backupMeta = {};
}

function markDirty(reason="資料異動"){
  ensureBackupMeta();
  syncStatus.dirty = true;
  syncStatus.lastError = "";
  state.backupMeta.lastLocalChangeAt = localIsoLikeString();
  state.backupMeta.lastLocalChangeMs = Date.now();
  state.backupMeta.lastDirtyReason = reason;
  syncStatus.localUpdatedAt = state.backupMeta.lastLocalChangeMs;
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
  renderSyncStatus();
}

function markClean(){
  ensureBackupMeta();
  syncStatus.dirty = false;
  syncStatus.lastFirebaseSyncAt = localIsoLikeString();
  state.backupMeta.lastFirebaseUploadAt = syncStatus.lastFirebaseSyncAt;
  state.backupMeta.lastFirebaseUploadMs = Date.now();
  syncStatus.localUpdatedAt = state.backupMeta.lastFirebaseUploadMs;
  syncStatus.cloudIsNewer = false;
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
  renderSyncStatus();
}


/* =========================================================
   SYNC MODULE: SMART SYNC GUARD
   - 開啟網頁時檢查雲端版本
   - 避免舊裝置直接上傳覆蓋較新的 Firebase
   ========================================================= */

/* =========================================================
   SYNC MODULE: CONFLICT FIX V7.1.1
   - 「仍使用本機」= 強制上傳本機
   - 上傳前建立本機備份點
   - 避免雲端較新判斷卡住上傳
   ========================================================= */
function createLocalSafetyBackup(reason="manual-force-upload"){
  try{
    const backups = JSON.parse(localStorage.getItem("bt_local_safety_backups") || "[]");
    backups.unshift({
      id:makeId(),
      reason,
      createdAt:localIsoLikeString(),
      state:JSON.parse(JSON.stringify(state))
    });
    localStorage.setItem("bt_local_safety_backups", JSON.stringify(backups.slice(0,5)));
  }catch(err){
    console.warn("createLocalSafetyBackup failed", err);
  }
}

function markLocalChanged(reason="本機資料異動"){
  ensureBackupMeta?.();
  if(!state.backupMeta) state.backupMeta = {};
  state.backupMeta.lastLocalChangeAt = localIsoLikeString();
  state.backupMeta.lastLocalChangeMs = Date.now();
  state.backupMeta.lastDirtyReason = reason;
  if(typeof syncStatus === "object"){
    syncStatus.dirty = true;
    syncStatus.localUpdatedAt = state.backupMeta.lastLocalChangeMs;
    syncStatus.cloudIsNewer = false;
    syncStatus.lastError = "";
  }
  saveState?.();
  renderSyncStatus?.();
}

async function forceUseLocalAndUpload(){
  hideCloudWarning?.();
  await heartbeatSessionLock(true);
  createLocalSafetyBackup("force-use-local-before-upload");
  if(typeof syncStatus === "object"){
    syncStatus.cloudIsNewer = false;
    syncStatus.dirty = true;
    syncStatus.lastError = "";
  }
  return firebaseUploadAll(false,true);
}

function showSyncConflictDialog(){
  let box = document.getElementById("cloudWarningBox");
  if(!box){
    box = document.createElement("div");
    box.id = "cloudWarningBox";
    box.className = "cloud-warning";
    document.body.appendChild(box);
  }

  box.innerHTML = `
    <div>⚠️ 系統偵測到雲端資料時間較新</div>
    <div style="font-weight:700;opacity:.82;margin-top:6px">
      雲端：${escapeHtml(safeFormatDateTime(syncStatus.cloudUpdatedAtText || syncStatus.cloudUpdatedAt))}<br>
      本機：${escapeHtml(safeFormatDateTime(state.backupMeta?.lastLocalChangeAt || state.backupMeta?.lastFirebaseUploadAt || ""))}
    </div>
    <div class="note" style="margin-top:8px">
      如果你確定 iPad / 目前裝置才是最新資料，請按「強制上傳本機」。系統會先保留本機安全備份。
    </div>
    <div class="sync-conflict-actions">
      <button class="btn gold" onclick="firebaseDownloadAll()">⬇️ 讀取雲端</button>
      <button class="btn primary" onclick="forceUseLocalAndUpload()">⬆️ 強制上傳本機</button>
      <button class="btn red" onclick="hideCloudWarning()">取消</button>
    </div>
  `;
}


/* =========================================================
   SYNC MODULE: DEVICE SESSION LOCK V7.2.1
   - 防止舊裝置背景自動上傳覆蓋新資料
   - 屬於「提醒與阻擋」層，不破壞原本 Firebase 同步
   ========================================================= */
const DEVICE_LOCK_TIMEOUT_MS = 2 * 60 * 1000;

function getDeviceId(){
  let id = localStorage.getItem("bt_device_id");
  if(!id){
    id = "dev_" + makeId();
    localStorage.setItem("bt_device_id", id);
  }
  return id;
}

function getDeviceName(){
  let name = localStorage.getItem("bt_device_name");
  if(!name){
    const ua = navigator.userAgent || "";
    if(/iPad/i.test(ua)) name = "iPad";
    else if(/iPhone/i.test(ua)) name = "iPhone";
    else if(/Mac/i.test(ua)) name = "Mac / 電腦";
    else name = "目前裝置";
    localStorage.setItem("bt_device_name", name);
  }
  return name;
}

function setDeviceName(name){
  localStorage.setItem("bt_device_name", name || "目前裝置");
}

function isLockActive(lock){
  return lock && lock.updatedAt && (Date.now() - Number(lock.updatedAt)) < DEVICE_LOCK_TIMEOUT_MS;
}

async function getSessionLock(){
  try{
    if(typeof firebaseDb === "undefined") return null;
    const snap = await firebaseDb.ref("battleSystem/sessionLock").once("value");
    return snap.exists() ? snap.val() : null;
  }catch(err){
    console.warn("getSessionLock failed", err);
    return null;
  }
}

async function heartbeatSessionLock(force=false){
  try{
    if(typeof firebaseDb === "undefined") return false;

    const current = await getSessionLock();
    const myId = getDeviceId();

    if(!force && isLockActive(current) && current.deviceId && current.deviceId !== myId){
      showDeviceLockWarning(current);
      return false;
    }

    await firebaseDb.ref("battleSystem/sessionLock").set({
      deviceId: myId,
      deviceName: getDeviceName(),
      updatedAt: Date.now(),
      updatedAtText: localIsoLikeString()
    });

    hideDeviceLockWarning();
    return true;
  }catch(err){
    console.warn("heartbeatSessionLock failed", err);
    return false;
  }
}

async function checkDeviceLockBeforeUpload(silent=false){
  const lock = await getSessionLock();
  const myId = getDeviceId();

  if(isLockActive(lock) && lock.deviceId && lock.deviceId !== myId){
    if(!silent) showDeviceLockWarning(lock);
    return false;
  }

  await heartbeatSessionLock(true);
  return true;
}

function showDeviceLockWarning(lock){
  let box = document.getElementById("deviceLockWarningBox");
  if(!box){
    box = document.createElement("div");
    box.id = "deviceLockWarningBox";
    box.className = "device-lock-warning";
    document.body.appendChild(box);
  }

  box.innerHTML = `
    <div>🔒 另一台裝置正在編輯中</div>
    <div style="font-weight:700;opacity:.86;margin-top:6px">
      目前編輯裝置：${escapeHtml(lock?.deviceName || "未知裝置")}<br>
      最後活動：${escapeHtml(safeFormatDateTime(lock?.updatedAtText || lock?.updatedAt || ""))}
    </div>
    <div class="note" style="margin-top:8px">
      為了避免舊裝置覆蓋新資料，這台裝置的自動上傳已暫停。若你確定要用目前裝置編輯，可以接管編輯權。
    </div>
    <div class="actions">
      <button class="btn gold" onclick="firebaseDownloadAll()">⬇️ 先讀取雲端</button>
      <button class="btn primary" onclick="takeOverDeviceLock()">接管編輯權</button>
      <button class="btn red" onclick="hideDeviceLockWarning()">只查看</button>
    </div>
  `;
}

function hideDeviceLockWarning(){
  document.getElementById("deviceLockWarningBox")?.remove();
}

async function takeOverDeviceLock(){
  await heartbeatSessionLock(true);
  hideDeviceLockWarning();
  alert("已接管編輯權。接下來這台裝置可以上傳雲端。");
  renderSyncStatus?.();
}

/* 編輯中每 45 秒刷新鎖，避免同一台裝置被誤判過期 */
setInterval(function(){
  if(typeof syncStatus === "object" && syncStatus.dirty){
    heartbeatSessionLock(false);
  }
}, 45000);

/* 開啟後先檢查一次裝置鎖 */
setTimeout(function(){
  heartbeatSessionLock(false);
}, 1800);

async function checkFirebaseFreshness(showAlert=false){
  try{
    if(typeof firebase === "undefined" || typeof firebaseDb === "undefined") return null;

    syncStatus.checking = true;
    renderSyncStatus();

    const snap = await firebaseDb.ref("battleSystem/main").once("value");
    syncStatus.checking = false;

    if(!snap.exists()){
      renderSyncStatus();
      return null;
    }

    const data = snap.val() || {};
    syncStatus.cloudUpdatedAt = Number(data.updatedAt || data.state?.backupMeta?.lastFirebaseUploadMs || 0);
    syncStatus.cloudUpdatedAtText = data.updatedAtText || data.state?.backupMeta?.lastFirebaseUploadAt || "";
    const localMs = Number(state.backupMeta?.lastLocalChangeMs || state.backupMeta?.lastFirebaseUploadMs || 0);

    syncStatus.localUpdatedAt = localMs;
    syncStatus.cloudIsNewer = syncStatus.cloudUpdatedAt > localMs + 3000;

    renderSyncStatus();

    if(syncStatus.cloudIsNewer){
      showCloudNewerWarning();
    }else if(showAlert){
      alert("目前沒有偵測到較新的雲端資料。");
    }

    return {
      cloudUpdatedAt:syncStatus.cloudUpdatedAt,
      localUpdatedAt:localMs,
      cloudIsNewer:syncStatus.cloudIsNewer
    };
  }catch(err){
    syncStatus.checking = false;
    syncStatus.lastError = err?.message || String(err);
    renderSyncStatus();
    if(showAlert) alert("檢查雲端版本失敗：" + syncStatus.lastError);
    return null;
  }
}

function hideCloudWarning(){
  document.getElementById("cloudWarningBox")?.remove();
}

function showCloudNewerWarning(){
  showSyncConflictDialog();
}

async function guardedFirebaseUpload(silent=false){
  const lockOk = await checkDeviceLockBeforeUpload(silent);
  if(!lockOk) return false;

  const fresh = await checkFirebaseFreshness(false);

  if(fresh?.cloudIsNewer){
    if(!silent){
      showSyncConflictDialog();
    }
    return false;
  }

  await firebaseUploadAll(silent,true);
  return true;
}


function renderSyncStatus(){
  let el = document.getElementById("syncStatusBar");
  if(!el){
    el = document.createElement("div");
    el.id = "syncStatusBar";
    document.body.appendChild(el);
  }

  let cls = "clean";
  let text = "🟢 已同步";

  if(syncStatus.syncing){
    cls = "syncing";
    text = "☁️ 同步中…";
  }else if(syncStatus.checking){
    cls = "syncing";
    text = "🔎 檢查雲端…";
  }else if(syncStatus.lastError){
    cls = "error";
    text = "🔴 同步失敗";
  }else if(syncStatus.cloudIsNewer){
    cls = "dirty";
    text = "⚠️ 雲端較新";
  }else if(syncStatus.dirty){
    cls = "dirty";
    text = "🟡 尚未上傳";
  }

  const last = syncStatus.lastFirebaseSyncAt || state.backupMeta?.lastFirebaseUploadAt || "尚未同步";
  el.className = "sync-status " + cls;
  el.innerHTML = `
    <span>${text}</span>
    <span style="opacity:.72;font-weight:700">本機上次：${escapeHtml(safeFormatDateTime(last))}</span>
    <span class="sync-actions">
      <button onclick="guardedFirebaseUpload()">⬆️ 上傳雲端</button>
      <button onclick="firebaseDownloadAll()">⬇️ 讀取雲端</button>
      <button onclick="checkFirebaseFreshness(true)">檢查</button>
    </span>
  `;
}

window.addEventListener("beforeunload", function(e){
  if(syncStatus.dirty){
    e.preventDefault();
    e.returnValue = "你有尚未同步 Firebase 的資料，確定離開？";
  }
});

document.addEventListener("visibilitychange", function(){
  if(document.visibilityState === "hidden" && syncStatus.dirty){
    guardedFirebaseUpload(true);
  }
});

setInterval(function(){
  if(syncStatus.dirty && !syncStatus.syncing) guardedFirebaseUpload(true);
},30000);



/* =========================================================
   1. READ HELPERS
   ========================================================= */
function findById(list,id){ return list.find(item => item.id === id); }
function activeSchools(){ return state.schools.filter(s => s.active !== false); }
function activeClasses(){ return state.classes.filter(c => c.active !== false && findById(state.schools,c.schoolId)?.active !== false); }
function allClassesSorted(){ return state.classes.slice().sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0)); }
function activeRewards(){ return state.rewards.filter(r => r.active !== false); }
function activePointActions(){
  return (state.pointActions || [])
    .filter(a => a.active !== false)
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}
function activeTerms(){
  return (state.academicTerms || buildAcademicTerms()).filter(t => t.active !== false);
}
function termName(id){
  return findById(state.academicTerms || [], id)?.name || currentAcademicTermLabel();
}
function classDateKey(termId,classId){
  return `${termId || currentAcademicTermId()}__${classId || ""}`;
}
function getClassDates(termId,classId){
  const key = classDateKey(termId,classId);
  const saved = (state.classDateLists && state.classDateLists[key]) || [];
  const hidden = (state.hiddenDateLists && state.hiddenDateLists[key]) || [];
  const fromAttendance = state.attendance
    .filter(a => a.classId === classId)
    .map(a => a.date);
  const fromNotes = state.courseNotes
    .filter(n => n.classId === classId)
    .map(n => n.date);
  return [...new Set([...saved, ...fromAttendance, ...fromNotes].filter(Boolean))]
    .filter(d => !hidden.includes(d))
    .sort((a,b)=>a.localeCompare(b));
}
function saveClassDates(termId,classId,dates){
  const key = classDateKey(termId,classId);
  if(!state.classDateLists) state.classDateLists = {};
  state.classDateLists[key] = [...new Set(dates.filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  saveState();
}
function addClassDate(termId,classId,date){
  if(!date) return;
  const key = classDateKey(termId,classId);
  if(!state.hiddenDateLists) state.hiddenDateLists = {};
  state.hiddenDateLists[key] = (state.hiddenDateLists[key] || []).filter(d => d !== date);
  const dates = getClassDates(termId,classId);
  dates.push(date);
  saveClassDates(termId,classId,dates);
  render();
}
function removeClassDate(termId,classId,date){
  const key = classDateKey(termId,classId);
  if(!state.classDateLists) state.classDateLists = {};
  if(!state.hiddenDateLists) state.hiddenDateLists = {};
  const saved = (state.classDateLists && state.classDateLists[key]) || [];
  state.classDateLists[key] = saved.filter(d => d !== date);
  state.hiddenDateLists[key] = [...new Set([...(state.hiddenDateLists[key] || []), date])];

  if(classContext.date === date){
    const remaining = getClassDates(termId,classId).filter(d => d !== date);
    classContext.date = remaining[0] || today();
  }

  saveState();
  render();
}
function generateWeeklyClassDates(termId,classId,startDate,weeks){
  const start = new Date(startDate);
  if(Number.isNaN(start.getTime())) return alert("請先選擇起始日期");
  const count = Math.max(1, Math.min(60, Number(weeks)||1));
  const key = classDateKey(termId,classId);
  if(!state.hiddenDateLists) state.hiddenDateLists = {};
  const generated = [];
  const dates = getClassDates(termId,classId);
  for(let i=0;i<count;i++){
    const d = new Date(start);
    d.setDate(start.getDate()+i*7);
    generated.push(d.toISOString().slice(0,10));
    dates.push(d.toISOString().slice(0,10));
  }
  state.hiddenDateLists[key] = (state.hiddenDateLists[key] || []).filter(d => !generated.includes(d));
  saveClassDates(termId,classId,dates);
  render();
}
function cycleAttendance(studentId,classId,date){
  const order = ["", "present", "leave", "late", "absent"];
  const current = attendanceStatus(studentId,classId,date);
  const next = order[(order.indexOf(current)+1) % order.length] || "";
  if(next){
    setAttendance(studentId,classId,date,next);
  }else{
    const existing = state.attendance.find(a => a.studentId === studentId && a.classId === classId && a.date === date);
    if(existing && existing.status === "present"){
      const rollback = existing.pointValue || Number(state.settings.attendPoint || 0);
      state.points[studentId] = (Number(state.points[studentId]) || 0) - rollback;
      state.pointLogs.push({id:makeId(),studentId,amount:-rollback,reason:"取消出席",date:new Date().toISOString()});
    }
    state.attendance = state.attendance.filter(a => !(a.studentId === studentId && a.classId === classId && a.date === date));
    saveState();
    render();
  }
}
function classesBySchool(schoolId){
  return activeClasses()
    .filter(c => c.schoolId === schoolId)
    .sort((a,b) => (Number(a.order)||0) - (Number(b.order)||0));
}
function enrollmentsByClass(classId){ return state.enrollments.filter(e => e.classId === classId); }
function classesOfStudent(studentId, includeInactive=false){
  return state.enrollments
    .filter(e => e.studentId === studentId)
    .map(e => findById(state.classes, e.classId))
    .filter(Boolean)
    .filter(c => includeInactive || (c.active !== false && findById(state.schools,c.schoolId)?.active !== false));
}
function studentsByClass(classId){
  return enrollmentsByClass(classId)
    .map(e => findById(state.students, e.studentId))
    .filter(s => s && s.active !== false)
    .sort((a,b) => (Number(a.seat)||9999) - (Number(b.seat)||9999));
}
function schoolName(id){ return findById(state.schools,id)?.name || "未指定學校"; }
function className(id){ return findById(state.classes,id)?.name || "未指定課程"; }
function stageList(){
  return state.levelStages
    .filter(s => s.active !== false)
    .slice()
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}
function allStageList(){
  return state.levelStages.slice().sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}
function stageOfStudent(student){
  return findById(state.levelStages, student.stageId) || stageList()[0];
}
function levelLabel(student){
  const stage = stageOfStudent(student);
  if(!stage) return "未設定等級";
  return `${stage.name}第${student.level}${stage.unit || "級"}`;
}
function studentLine(student,classId){
  const cls = findById(state.classes,classId) || classesOfStudent(student.id)[0];
  return `${schoolName(cls?.schoolId)} / ${cls?.name || "未指定課程"} / ${student.seat || "-"}號 / ${levelLabel(student)}`;
}
function previousCourseNotes(classId,date,limit=5){
  return state.courseNotes
    .filter(n => n.classId === classId && n.date < date && (n.content || "").trim())
    .sort((a,b)=> b.date.localeCompare(a.date))
    .slice(0,limit);
}
function courseNoteFor(classId,date){
  return state.courseNotes.find(n => n.classId === classId && n.date === date)?.content || "";
}
function studentEnrolledIn(studentId,classId){
  return state.enrollments.some(e => e.studentId === studentId && e.classId === classId);
}
function levelKey(stageId,level){ return `${stageId}_${level}`; }
function levelContent(stageId,level){
  return state.levelContents[levelKey(stageId,level)] || {};
}
function examChecklistKey(studentId,stageId,level){
  return `${studentId}_${stageId}_${level}`;
}
function examChecklist(studentId,stageId,level){
  if(!state.examChecklists) state.examChecklists = {};
  const key = examChecklistKey(studentId,stageId,level);
  if(!state.examChecklists[key]) state.examChecklists[key] = {};
  return state.examChecklists[key];
}
function setExamChecklistItem(studentId,stageId,level,fieldId,checked){
  const list = examChecklist(studentId,stageId,level);
  list[fieldId] = !!checked;
  saveState();
  render();
}
function examRelevantFields(content){
  return state.levelFields
    .filter(field => field.active !== false)
    .filter(field => String(content?.[field.id] || "").trim())
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}
function examChecklistSummary(studentId,stageId,level,content={}){
  const fields = examRelevantFields(content);
  const list = examChecklist(studentId,stageId,level);
  const total = fields.length;
  const checked = fields.filter(field => list[field.id]).length;
  return {total, checked, pass: total > 0 && checked === total};
}
function displayLevelPlain(student){
  if(!student) return "";
  const stage = findById(state.levelStages, student.stageId);
  const level = Number(student.level || 0);
  if(level <= 0) return `${stage?.name || ""}尚未通過`;
  return `${stage?.name || ""}第${level}${stage?.unit || "級"}`;
}
function nextLevel(student){
  const stages = stageList();
  const stage = findById(stages, student.stageId);
  const index = stages.findIndex(s => s.id === student.stageId);
  if(!stage || index < 0) return null;

  const currentLevel = Number(student.level || 0);

  if(currentLevel < Number(stage.start)){
    return {stageId:stage.id, level:Number(stage.start)};
  }

  if(currentLevel < Number(stage.end)){
    return {stageId:stage.id, level:currentLevel+1};
  }

  const nextStage = stages[index+1];
  if(nextStage){
    return {stageId:nextStage.id, level:Number(nextStage.start)};
  }

  return null;
}
function previousLevel(student){
  const stages = stageList();
  const stage = findById(stages, student.stageId);
  const index = stages.findIndex(s => s.id === student.stageId);
  if(!stage || index < 0) return null;

  const currentLevel = Number(student.level || 0);
  if(currentLevel <= 0) return null;

  if(currentLevel <= Number(stage.start)){
    return {stageId:stage.id, level:0};
  }

  return {stageId:stage.id, level:currentLevel-1};
}

/* =========================================================
   2. WRITE LOGIC
   ========================================================= */
function addPoints(studentId, amount, reason){
  const value = Number(amount) || 0;
  state.points[studentId] = (Number(state.points[studentId]) || 0) + value;
  state.pointLogs.push({
    id:makeId(),
    studentId,
    amount:value,
    reason,
    date:new Date().toISOString()
  });
  const student = findById(state.students,studentId);
  recordActivity("points", `${student?.name || "學生"} ${value >= 0 ? "+" : ""}${value}｜${reason}`, {studentId,amount:value,reason});
  saveState();
  render();
}

function setAttendance(studentId,classId,date,status){
  const pointValue = Number(state.settings.attendPoint || 0);
  const existing = state.attendance.find(a => a.studentId === studentId && a.classId === classId && a.date === date);
  const oldStatus = existing ? existing.status : "";

  if(existing){
    existing.status = status;
    if(typeof existing.pointValue === "undefined") existing.pointValue = pointValue;
  }else{
    state.attendance.push({id:makeId(),studentId,classId,date,status,pointValue});
  }

  if(oldStatus !== "present" && status === "present"){
    state.points[studentId] = (Number(state.points[studentId]) || 0) + pointValue;
    state.pointLogs.push({
      id:makeId(),
      studentId,
      amount:pointValue,
      reason:"出席",
      date:new Date().toISOString()
    });
  }

  if(oldStatus === "present" && status !== "present"){
    const rollback = existing?.pointValue || pointValue;
    state.points[studentId] = (Number(state.points[studentId]) || 0) - rollback;
    state.pointLogs.push({
      id:makeId(),
      studentId,
      amount:-rollback,
      reason:"取消出席",
      date:new Date().toISOString()
    });
  }

  const student = findById(state.students,studentId);
  recordActivity("attendance", `${student?.name || "學生"} ${statusText(status)}｜${className(classId)} ${date}`, {studentId,classId,date,status});
  saveState();
  render();
}

function attendanceStatus(studentId,classId,date){
  return state.attendance.find(a => a.studentId === studentId && a.classId === classId && a.date === date)?.status || "";
}

function saveCourseNote(classId,date,content,termId=classContext.termId){
  if(!Array.isArray(state.courseNotes)) state.courseNotes = [];
  const safeClassId = classId || classContext.classId;
  const safeDate = date || classContext.date || today();
  const safeTermId = termId || classContext.termId || currentAcademicTermId(safeDate);
  const existing = state.courseNotes.find(n => n.classId === safeClassId && n.date === safeDate && (n.termId || currentAcademicTermId(n.date)) === safeTermId);
  if(existing){
    existing.content = content;
    existing.termId = safeTermId;
    existing.updatedAt = localIsoLikeString();
  }else{
    state.courseNotes.push({
      id:makeId(),
      termId:safeTermId,
      classId:safeClassId,
      date:safeDate,
      content,
      createdAt:localIsoLikeString(),
      updatedAt:localIsoLikeString()
    });
  }
  saveState();
}


/* =========================================================
   CLEAN CORE: COURSE NOTE SAVE
   - 一律使用目前學期 / 課程 / 日期儲存
   - 避免錯把 content 當 classId 傳入
   ========================================================= */
function saveTodayCourseNoteFixed(){
  if(!classContext.classId) return alert("請先選擇課程單位。");
  if(!classContext.date) classContext.date = today();
  if(!classContext.termId) classContext.termId = currentAcademicTermId();

  const content = document.getElementById("courseNoteInput")?.value || "";
  if(!content.trim()) return alert("請先輸入今日課程紀錄。");

  saveCourseNote(classContext.classId, classContext.date, content, classContext.termId);
  recordActivity("course-note", `儲存課程紀錄：${className(classContext.classId)} ${classContext.date}`, {
    classId:classContext.classId,
    date:classContext.date,
    termId:classContext.termId
  });
  markDirty("課程紀錄");
  render();
  alert("課程紀錄已儲存");
}

function passExam(studentId,comment){
  const student = findById(state.students,studentId);
  if(!student) return alert("找不到學生");

  const target = nextLevel(student);
  if(!target) return alert("已經是最高等級");

  const from = {stageId:student.stageId,level:Number(student.level)};
  student.stageId = target.stageId;
  student.level = target.level;

  const reward = Number(state.settings.upgradeReward || 0);
  state.points[studentId] = (Number(state.points[studentId]) || 0) + reward;
  state.pointLogs.push({
    id:makeId(),
    studentId,
    amount:reward,
    reason:"升級獎勵",
    date:new Date().toISOString()
  });

  state.examLogs.push({
    id:makeId(),
    studentId,
    type:"pass",
    from,
    to:target,
    comment,
    date:new Date().toISOString()
  });
  recordActivity("exam", `${student.name} 升級：${levelStageName(from.stageId)}${from.level} → ${levelStageName(target.stageId)}${target.level}`, {studentId,from,to:target,comment});

  saveState();
  render();
  alert(`升級成功，已加 ${reward} 點`);
}

function failExam(studentId,comment){
  if(!studentId) return;
  state.examLogs.push({
    id:makeId(),
    studentId,
    type:"fail",
    comment,
    date:new Date().toISOString()
  });
  const student = findById(state.students,studentId);
  recordActivity("exam", `${student?.name || "學生"} 升級未通過`, {studentId,comment});
  saveState();
  render();
}

function downgradeStudent(studentId,comment){
  const student = findById(state.students,studentId);
  if(!student) return alert("找不到學生");

  const target = previousLevel(student);
  if(!target) return alert("已經是最低等級");

  const from = {stageId:student.stageId,level:Number(student.level)};
  student.stageId = target.stageId;
  student.level = target.level;
  state.examLogs.push({
    id:makeId(),
    studentId,
    type:"down",
    from,
    to:target,
    comment,
    date:new Date().toISOString()
  });

  saveState();
  render();
}

function toggleEnrollment(studentId,classId,checked){
  const exists = state.enrollments.some(e => e.studentId === studentId && e.classId === classId);
  if(checked && !exists){
    state.enrollments.push({studentId,classId});
  }
  if(!checked && exists){
    state.enrollments = state.enrollments.filter(e => !(e.studentId === studentId && e.classId === classId));
  }
  saveState();
  render();
}

/* =========================================================
   3. UI STATE
   ========================================================= */
let currentPage = "classroom";
let settingsTab = "basic";
let historyTab = "points";
let classroomTab = "rollcall";

let classContext = {
  termId:currentAcademicTermId(),
  schoolId:null,
  classId:null,
  date:today()
};

let examContext = {
  termId:currentAcademicTermId(),
  schoolId:null,
  classId:null,
  studentId:null
};

let historyContext = {
  termId:currentAcademicTermId(),
  schoolId:null,
  classId:null,
  studentId:null
};

let rewardTab = "shop";
let rewardContext = {
  termId:currentAcademicTermId(),
  schoolId:null,
  classId:null,
  studentId:null
};
let rewardImageDraft = "";

function ensureClassContext(){
  if(!classContext.date) classContext.date = today();
  if(!classContext.termId || !activeTerms().some(t=>t.id===classContext.termId)){
    classContext.termId = currentAcademicTermId();
  }
  const schools = activeSchools();
  const school = schools[0];
  if((!classContext.schoolId || !schools.some(s => s.id === classContext.schoolId)) && school){
    classContext.schoolId = school.id;
    classContext.classId = null;
  }

  const classes = classesBySchool(classContext.schoolId);
  if(!classes.some(c => c.id === classContext.classId)){
    classContext.classId = classes[0]?.id || null;
  }
}

function ensureExamContext(){
  const schools = activeSchools();
  const school = schools[0];
  if((!examContext.schoolId || !schools.some(s => s.id === examContext.schoolId)) && school){
    examContext.schoolId = school.id;
    examContext.classId = null;
    examContext.studentId = null;
  }

  const classes = classesBySchool(examContext.schoolId);
  if(!classes.some(c => c.id === examContext.classId)){
    examContext.classId = classes[0]?.id || null;
    examContext.studentId = null;
  }

  const students = studentsByClass(examContext.classId);
  if(!students.some(s => s.id === examContext.studentId)){
    examContext.studentId = students[0]?.id || null;
  }
}

function ensureHistoryContext(){
  if(!historyContext.termId || !activeTerms().some(t=>t.id===historyContext.termId)){
    historyContext.termId = currentAcademicTermId();
  }
  const schools = activeSchools();
  const school = schools[0];
  if((!historyContext.schoolId || !schools.some(s => s.id === historyContext.schoolId)) && school){
    historyContext.schoolId = school.id;
    historyContext.classId = null;
    historyContext.studentId = null;
  }

  const classes = classesBySchool(historyContext.schoolId);
  if(!classes.some(c => c.id === historyContext.classId)){
    historyContext.classId = classes[0]?.id || null;
    historyContext.studentId = null;
  }

  const students = studentsByClass(historyContext.classId);
  if(!students.some(s => s.id === historyContext.studentId)){
    historyContext.studentId = students[0]?.id || null;
  }
}

function ensureRewardContext(){
  const schools = activeSchools();
  const school = schools[0];
  if((!rewardContext.schoolId || !schools.some(s => s.id === rewardContext.schoolId)) && school){
    rewardContext.schoolId = school.id;
    rewardContext.classId = null;
    rewardContext.studentId = null;
  }

  const classes = classesBySchool(rewardContext.schoolId);
  if(!classes.some(c => c.id === rewardContext.classId)){
    rewardContext.classId = classes[0]?.id || null;
    rewardContext.studentId = null;
  }

  const students = studentsByClass(rewardContext.classId);
  if(!students.some(s => s.id === rewardContext.studentId)){
    rewardContext.studentId = students[0]?.id || null;
  }
}

/* =========================================================
   4. SMALL UI HELPERS
   ========================================================= */
function optionList(items, selectedId, labelFn = item => item.name){
  return items.map(item => `<option value="${item.id}" ${item.id === selectedId ? "selected" : ""}>${labelFn(item)}</option>`).join("");
}
function statusText(status){
  return {present:"出席",absent:"缺席",late:"遲到",leave:"請假"}[status] || "尚未點名";
}
function statusClass(status){
  return {present:"status-present",absent:"status-absent",late:"status-late",leave:"status-leave"}[status] || "";
}
function escapeHtml(value){
  return String(value ?? "").replace(/[&<>"']/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[s]));
}

function formatMultiline(text){
  return escapeHtml(text || "").replace(/\n/g,"<br>");
}

function jsString(value){
  return JSON.stringify(String(value ?? ""));
}
function formatDateTime(value){
  if(!value) return "";
  return String(value).replace("T"," ").slice(0,16);
}

function recordActivity(type,message,meta={}){
  if(!Array.isArray(state.activityLogs)) state.activityLogs = [];
  state.activityLogs.push({
    id:makeId(),
    type,
    message,
    meta,
    date:new Date().toISOString()
  });
  // 完整保留，不在這裡刪除；畫面顯示時只取最近 N 筆，避免變慢。
}

function latestActivities(limit=100){
  return (state.activityLogs || [])
    .slice()
    .sort((a,b)=>String(b.date).localeCompare(String(a.date)))
    .slice(0,limit);
}

function backupAgeDays(){
  const last = state.backupMeta?.lastExportAt;
  if(!last) return null;
  const diff = Date.now() - new Date(last).getTime();
  return Math.floor(diff / 86400000);
}

function activeStudents(){
  return state.students.filter(s => s.active !== false);
}

function attendanceRateForStudent(studentId, termId=null, classId=null){
  const records = state.attendance.filter(a =>
    a.studentId === studentId &&
    (!classId || a.classId === classId) &&
    (!termId || (a.termId || currentAcademicTermId(a.date)) === termId)
  );
  if(!records.length) return {total:0,present:0,rate:0};
  const present = records.filter(a => a.status === "present").length;
  return {total:records.length,present,rate:Math.round(present / records.length * 100)};
}

function rewardRedeemStats(){
  const map = new Map();
  (state.redeemLogs || []).forEach(log=>{
    const key = log.rewardId || log.rewardName || "unknown";
    if(!map.has(key)) map.set(key,{name:log.rewardName || findById(state.rewards,log.rewardId)?.name || "未知獎品",count:0,totalCost:0});
    const item = map.get(key);
    item.count += 1;
    item.totalCost += Number(log.cost || 0);
  });
  return [...map.values()].sort((a,b)=>b.count-a.count);
}

function growthTypes(){
  const list = state.growthSettings?.growthTypes || [];
  return list.filter(t => t.active !== false).slice().sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}

function allGrowthTypes(){
  return (state.growthSettings?.growthTypes || []).slice().sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));
}

function growthTypeName(id){
  return allGrowthTypes().find(t=>t.id===id)?.name || id || "成長";
}

function growthTypeById(id){
  return allGrowthTypes().find(t=>t.id===id) || growthTypes()[0] || {id:"attitude",name:"學習態度",defaultXp:10,defaultFeedback:"今天有明顯進步。"};
}

function growthLogsForStudent(studentId,limit=3){
  return (state.growthLogs || []).filter(log => log.studentId === studentId).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,limit);
}

function allGrowthLogsForStudent(studentId){
  return (state.growthLogs || []).filter(log => log.studentId === studentId).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
}

function growthXpTotal(studentId){
  return (state.growthLogs || []).filter(log => log.studentId === studentId).reduce((sum,log)=>sum + (Number(log.xp)||0),0);
}

function growthLevelInfo(xp){
  const levels = (state.growthSettings?.xpLevels || []).slice().sort((a,b)=>(Number(a.xp)||0)-(Number(b.xp)||0));
  let current = levels[0] || {level:1,xp:0,title:"🌱 排笛幼苗"};
  let next = null;
  for(const item of levels){
    if(Number(xp) >= Number(item.xp || 0)) current = item;
    else { next = item; break; }
  }
  const currentXp = Number(current.xp || 0);
  const nextXp = next ? Number(next.xp || 0) : currentXp;
  const progress = next ? Math.max(0, Math.min(100, Math.round((Number(xp)-currentXp)/(nextXp-currentXp)*100))) : 100;
  return {current,next,progress};
}

function growthTopTypes(studentId,limit=3){
  const map = new Map();
  (state.growthLogs || []).filter(log=>log.studentId===studentId).forEach(log=>{
    const item = map.get(log.type) || {type:log.type,name:growthTypeName(log.type),xp:0,count:0};
    item.xp += Number(log.xp)||0;
    item.count += 1;
    map.set(log.type,item);
  });
  return [...map.values()].sort((a,b)=>b.xp-a.xp).slice(0,limit);
}

function addGrowthLog(studentId,type,xp,feedback){
  const student = findById(state.students,studentId);
  if(!student) return alert("找不到學生資料。");
  const amount = Number(xp) || 0;
  const text = String(feedback || "").trim();
  if(!type) type = growthTypes()[0]?.id || "attitude";
  if(!text && amount === 0) return alert("請輸入回饋，或至少給予 XP。");

  if(!Array.isArray(state.growthLogs)) state.growthLogs = [];
  state.growthLogs.push({
    id:makeId(),
    studentId,
    classId:classContext.classId || "",
    termId:classContext.termId || currentAcademicTermId(),
    date:new Date().toISOString(),
    type,
    xp:amount,
    feedback:text
  });

  recordActivity("growth", `${student.name} 成長日誌：${growthTypeName(type)} ${amount ? "+"+amount+"XP" : ""}`, {studentId,type,xp:amount});
  saveState();
  render();
}

function quickGrowthLog(studentId,type,xp){
  const item = growthTypeById(type);
  addGrowthLog(studentId,item.id,Number(xp)||Number(item.defaultXp)||10,item.defaultFeedback || "今天有明顯進步。");
}

function addCustomGrowthLog(studentId){
  const typeEl = document.getElementById(`growthType_${studentId}`);
  const xpEl = document.getElementById(`growthXp_${studentId}`);
  const textEl = document.getElementById(`growthFeedback_${studentId}`);
  addGrowthLog(studentId,typeEl?.value || "attitude",Number(xpEl?.value)||0,textEl?.value || "");
}

function deleteGrowthLog(logId){
  const log = (state.growthLogs || []).find(x=>x.id===logId);
  if(!log) return alert("找不到這筆成長紀錄。");
  if(!confirm("確定刪除這筆成長日誌？這會直接移除該筆 XP 紀錄。")) return;
  state.growthLogs = (state.growthLogs || []).filter(x=>x.id!==logId);
  recordActivity("growth-delete", `刪除成長日誌：${growthTypeName(log.type)} ${Number(log.xp)||0}XP`, {logId});
  saveState();
  document.querySelector(".modal-backdrop")?.remove();
  if(log.studentId) showGrowthProfile(log.studentId);
  render();
}

function correctGrowthXp(studentId,amount,label){
  const student = findById(state.students,studentId);
  if(!student) return alert("找不到學生資料。");
  const reason = prompt("請輸入修正原因：", label || "誤按修正");
  if(reason === null) return;
  addGrowthLog(studentId,"adjust",Number(amount)||0,reason || "XP 修正");
}

function correctGrowthLog(logId){
  const log = (state.growthLogs || []).find(x=>x.id===logId);
  if(!log) return alert("找不到這筆成長紀錄。");
  const amount = Number(prompt("請輸入要修正的 XP 數值，例如 -10 或 +5：","-" + (Number(log.xp)||0)));
  if(Number.isNaN(amount)) return alert("請輸入數字。");
  const reason = prompt("請輸入修正原因：","修正先前紀錄");
  if(reason === null) return;
  addGrowthLog(log.studentId,"adjust",amount,reason || "XP 修正");
}



/* =========================================================
   5. RENDER ROOT
   ========================================================= */
document.querySelectorAll(".nav button").forEach(button=>{
  button.addEventListener("click",()=>{
    currentPage = button.dataset.page;
    document.querySelectorAll(".nav button").forEach(b=>b.classList.remove("active"));
    button.classList.add("active");
    render();
  });
});



/* =========================================================
   LESSON MODULE: UNFINISHED TASK TRACKING
   ========================================================= */
function unfinishedKey(dateValue=classContext.date){
  return `${classContext.termId || currentAcademicTermId()}__${classContext.classId || ""}__${dateValue || today()}`;
}
function ensureUnfinishedTasks(){
  if(!state.unfinishedTasks) state.unfinishedTasks = {};
  return state.unfinishedTasks;
}
function saveUnfinishedTasksForToday(doneList,undoneList){
  const store = ensureUnfinishedTasks();
  const key = unfinishedKey(classContext.date);
  store[key] = {id:key, termId:classContext.termId || currentAcademicTermId(), classId:classContext.classId, date:classContext.date, done:doneList || [], undone:undoneList || [], updatedAt:localIsoLikeString()};
  saveState();
}
function latestUnfinishedBeforeToday(){
  const store = ensureUnfinishedTasks();
  return Object.values(store)
    .filter(x => x.classId === classContext.classId && x.date < classContext.date && Array.isArray(x.undone) && x.undone.length)
    .sort((a,b)=>String(b.date).localeCompare(String(a.date)))[0] || null;
}
function renderUnfinishedReminder(){
  const last = latestUnfinishedBeforeToday();
  if(!last) return "";
  return `<div class="unfinished-box"><b>⚠️ 上次未完成提醒（${escapeHtml(last.date)}）</b>${last.undone.map(t=>`<div>□ ${escapeHtml(t)}</div>`).join("")}<button class="btn gold" onclick="appendUnfinishedToMainline()">加入本週主線</button></div>`;
}
function appendUnfinishedToMainline(){
  const last = latestUnfinishedBeforeToday();
  if(!last) return alert("沒有找到上次未完成任務。");
  const main = getWeeklyMainline();
  const old = String(main.tasks || "").trim();
  const add = last.undone.join("\n");
  main.tasks = old ? old + "\n" + add : add;
  saveState();
  markDirty?.("加入未完成任務");
  render();
}

/* =========================================================
   QUICK CLASS MODULE
   - 上課專用：今天課堂、任務勾選、XP、提醒、同步
   ========================================================= */
let quickClassMode = false;

function toggleQuickClassMode(){
  /* V7.3.2 quick mode compatibility: 舊入口統一導向「開始上課」 */
  enterStartClassMode();
}

function quickAddGrowthXp(studentId, type="participation", xp=5){
  if(!Array.isArray(state.growthLogs)) state.growthLogs = [];
  state.growthLogs.push({
    id:makeId(),
    studentId,
    type,
    xp:Number(xp)||0,
    feedback: xp > 0 ? "開始上課加分" : "開始上課修正",
    date:new Date().toISOString()
  });
  saveState();
  markDirty?.("開始上課 XP");
  render();
}

function quickSaveLesson(){
  if(typeof saveLinkedCourseNote === "function"){
    saveLinkedCourseNote();
  }else if(typeof saveTodayCourseNoteFixed === "function"){
    saveTodayCourseNoteFixed();
  }else{
    alert("找不到課程儲存函式");
  }
}

function renderQuickClassMode(){
  document.body.classList.add("quick-mode");

  const main = typeof getWeeklyMainline === "function" ? getWeeklyMainline() : {title:"本週主線",tasks:""};
  const tasks = typeof weeklyMainTasks === "function" ? weeklyMainTasks() : [];
  const students = typeof studentsByClass === "function" ? studentsByClass(classContext.classId) : [];

  document.getElementById("app").innerHTML = `
    <div class="quick-topbar">
      <button class="btn red" onclick="toggleQuickClassMode()">退出開始上課</button>
      <button class="btn primary" onclick="guardedFirebaseUpload()">⬆️ 上傳雲端</button>
      <button class="btn gold" onclick="firebaseDownloadAll()">⬇️ 讀取雲端</button>
      <button class="btn" onclick="toggleThemeMode()">🌙 深色</button>
    </div>

    <section class="card">
      <h2>🎺 開始上課模式</h2>
      <div class="note">
        ${escapeHtml(className(classContext.classId))}｜${escapeHtml(classContext.date)}<br>
        本週主線：${escapeHtml(main.title || "尚未設定")}
      </div>
    </section>

    <div class="quick-class-shell">
      <section class="quick-class-card">
        <h3>📒 今天課堂</h3>
        ${renderUnfinishedReminder()}
        <div class="lesson-checklist">
          ${tasks.length ? tasks.map((task,idx)=>`
            <label class="lesson-check-item">
              <input type="checkbox" id="lessonTask_${idx}">
              <span>${escapeHtml(task)}</span>
            </label>
          `).join("") : `<div class="note">尚未設定本週主線任務。</div>`}
        </div>

        <input id="classTagsInput" placeholder="#節奏 #音準 #呼吸 #合奏">
        <textarea id="lessonReminderInput" placeholder="提醒事項"></textarea>
        <textarea id="lessonHomeworkInput" placeholder="回家功課"></textarea>
        <textarea id="courseNoteInput" placeholder="今日課堂補充"></textarea>

        <button class="btn primary" onclick="quickSaveLesson()">儲存今日課程紀錄</button>
      </section>

      <section class="quick-class-card">
        <h3>🌱 快速 XP</h3>
        <div class="quick-student-grid">
          ${students.length ? students.map(s=>`
            <div class="quick-student-card">
              <b>${escapeHtml(s.name)}</b>
              <div class="small-muted">目前 XP：${typeof growthXpTotal === "function" ? growthXpTotal(s.id) : 0}</div>
              <div class="quick-xp-row">
                <button onclick="quickAddGrowthXp('${s.id}','participation',5)">+5</button>
                <button onclick="quickAddGrowthXp('${s.id}','breakthrough',10)">+10</button>
                <button onclick="quickAddGrowthXp('${s.id}','correction',-5)">-5</button>
              </div>
            </div>
          `).join("") : `<div class="note">目前班級沒有學生。</div>

`}
        </div>
      </section>
    </div>
  `;
}



/* =========================================================
   PERFORMANCE WORKBENCH MODULE V2
   - 演出總覽
   - 演出詳情
   - 曲目配置
   - 學校 → 課程 → 學生勾選
   ========================================================= */
























































































/* =========================================================
   PERFORMANCE VISUAL HELPERS
   ========================================================= */





























/* =========================================================
   START CLASS FAST MODE V7.3
   ========================================================= */
let startClassMode = false;
let startClassAttendance = {};
let startClassTasks = {};

function enterStartClassMode(){
  startClassMode = true;
  if(typeof quickClassMode !== "undefined") quickClassMode = false;
  document.body.classList.remove("quick-mode");
  document.body.classList.add("start-class-mode");
  prepareStartClassData();
  render();
}

function exitStartClassMode(){
  startClassMode = false;
  document.body.classList.remove("start-class-mode");
  render();
}

function prepareStartClassData(){
  const students = studentsByClass(classContext.classId);
  students.forEach(st=>{
    if(!startClassAttendance[st.id]) startClassAttendance[st.id] = "出席";
  });
  const tasks = typeof weeklyMainTasks === "function" ? weeklyMainTasks() : [];
  tasks.forEach((t,idx)=>{
    const key = `task_${idx}`;
    if(startClassTasks[key] === undefined) startClassTasks[key] = false;
  });
}

function startClassSetAttendance(studentId,status){
  startClassAttendance[studentId] = status;
  renderStartClassMode();
}

function startClassToggleTask(idx,checked){
  startClassTasks[`task_${idx}`] = checked;
}

function startClassTaskSummary(){
  const tasks = typeof weeklyMainTasks === "function" ? weeklyMainTasks() : [];
  const done = [];
  const undone = [];
  tasks.forEach((t,idx)=>{
    if(startClassTasks[`task_${idx}`]) done.push(t);
    else undone.push(t);
  });
  return {done,undone};
}

function startClassBuildCourseNote(){
  const taskSummary = startClassTaskSummary();
  const memo = document.getElementById("startClassMemo")?.value?.trim() || "";
  const reminder = document.getElementById("startClassReminder")?.value?.trim() || "";
  const homework = document.getElementById("startClassHomework")?.value?.trim() || "";

  const att = studentsByClass(classContext.classId).map(st=>{
    const remark = document.getElementById(`startStudentRemark_${st.id}`)?.value?.trim() || "";
    return `${st.name}：${startClassAttendance[st.id] || "出席"}${remark ? "｜" + remark : ""}`;
  }).join("\n");

  return [
    "【已完成】",
    taskSummary.done.length ? taskSummary.done.map(x=>"✓ "+x).join("\n") : "無",
    "",
    "【未完成】",
    taskSummary.undone.length ? taskSummary.undone.map(x=>"□ "+x).join("\n") : "無",
    "",
    "【出席】",
    att || "無學生",
    "",
    reminder ? "【提醒事項】\n" + reminder : "",
    homework ? "【回家功課】\n" + homework : "",
    memo ? "【課堂備註】\n" + memo : ""
  ].filter(Boolean).join("\n");
}

function startClassSaveAttendance(){
  if(!Array.isArray(state.attendanceLogs)) state.attendanceLogs = [];
  const existingKey = `${classContext.classId}_${classContext.date}`;
  state.attendanceLogs = state.attendanceLogs.filter(x=>x.key !== existingKey);

  studentsByClass(classContext.classId).forEach(st=>{
    state.attendanceLogs.push({
      id: makeId(),
      key: existingKey,
      classId: classContext.classId,
      studentId: st.id,
      date: classContext.date,
      status: startClassAttendance[st.id] || "出席",
      createdAt: localIsoLikeString()
    });
  });
}

async function finishStartClass(){
  const content = startClassBuildCourseNote();
  const taskSummary = startClassTaskSummary();

  if(typeof saveUnfinishedTasksForToday === "function"){
    saveUnfinishedTasksForToday(taskSummary.done, taskSummary.undone);
  }

  if(typeof saveCourseNote === "function"){
    saveCourseNote(classContext.classId, classContext.date, content, classContext.termId);
  }else{
    if(!Array.isArray(state.courseNotes)) state.courseNotes = [];
    state.courseNotes.push({
      id: makeId(),
      classId: classContext.classId,
      date: classContext.date,
      content,
      termId: classContext.termId,
      createdAt: localIsoLikeString()
    });
  }

  startClassSaveAttendance();
  markDirty?.("開始上課極速模式儲存");
  saveState();

  try{ await guardedFirebaseUpload(false); }catch(err){ console.warn("finishStartClass sync failed", err); }

  alert("已儲存這堂課。");
  exitStartClassMode();
}


function startClassStudentPhotoHtml(st){
  const url = st.photoUrl || st.photo || st.imageUrl || "";
  if(url){
    return `<img class="start-student-photo" src="${escapeHtml(url)}" onerror="this.outerHTML='<div class=&quot;start-student-photo&quot;>👤</div>'">`;
  }
  return `<div class="start-student-photo">👤</div>`;
}

function startClassAddXp(studentId,type,xp){
  if(!Array.isArray(state.growthLogs)) state.growthLogs = [];
  const remark = document.getElementById(`startStudentRemark_${studentId}`)?.value?.trim() || "";
  const labelMap = {
    participation:"課堂參與",
    breakthrough:"成長亮點",
    teamwork:"幫助同學"
  };
  state.growthLogs.push({
    id:makeId(),
    studentId,
    type,
    xp:Number(xp)||0,
    feedback: remark || `開始上課快速紀錄：${labelMap[type] || type}`,
    date:localIsoLikeString()
  });
  markDirty?.("開始上課快速XP");
  saveState();
  alert(`已新增 XP +${xp}`);
  renderStartClassMode();
}

function startClassStudentXp(studentId){
  return typeof growthXpTotal === "function" ? growthXpTotal(studentId) : 0;
}

function renderStartClassMode(){
  document.body.classList.add("start-class-mode");
  prepareStartClassData();

  const cls = findById(state.classes, classContext.classId);
  const school = findById(state.schools, classContext.schoolId || cls?.schoolId);
  const students = studentsByClass(classContext.classId);
  const main = typeof getWeeklyMainline === "function" ? getWeeklyMainline() : {title:"本週主線"};
  const tasks = typeof weeklyMainTasks === "function" ? weeklyMainTasks() : [];

  document.getElementById("app").innerHTML = `
    <div class="start-class-header">
      <div>
        <div class="start-class-title">🎺 開始上課</div>
        <div class="start-class-sub">
          ${escapeHtml(school?.name || "未指定學校")}｜${escapeHtml(cls?.name || "未指定課程")}｜${escapeHtml(classContext.date)}
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" onclick="toggleThemeMode()">🌙 深色</button>
        <button class="btn red" onclick="exitStartClassMode()">退出</button>
      </div>
    </div>

    <div class="start-class-grid">
      <section class="start-class-card">
        <h2>📒 今天課堂</h2>
        <div class="note">本週主線：${escapeHtml(main.title || "尚未設定")}</div>

        <h3>任務勾選</h3>
        ${tasks.length ? tasks.map((task,idx)=>`
          <label class="start-task">
            <input type="checkbox" ${startClassTasks[`task_${idx}`] ? "checked" : ""} onchange="startClassToggleTask(${idx},this.checked)">
            <span>${escapeHtml(task)}</span>
          </label>
        `).join("") : `<div class="note">尚未設定本週主線任務，可先回上課介面設定。</div>`}

        <div class="start-note-area">
          <h3>提醒事項</h3>
          <textarea id="startClassReminder" placeholder="例如：下次先檢查高音 Sol、某學生需要看指法。"></textarea>

          <h3>回家功課</h3>
          <textarea id="startClassHomework" placeholder="例如：長音4拍每天3次、練習第8-16小節。"></textarea>

          <h3>課堂備註</h3>
          <textarea id="startClassMemo" placeholder="例如：今天節奏反應很好，但合奏速度還不穩。"></textarea>
        </div>
      </section>

      <section class="start-class-card">
        <h2>🧑‍🎓 點名</h2>
        <div class="start-att-panel">
          <div class="start-att-grid">
          ${students.length ? students.map(st=>`
            <div class="start-student">
              ${startClassStudentPhotoHtml(st)}
              <div class="start-student-main">
                <div class="start-student-name">${escapeHtml(st.name)}</div>
                <div class="start-xp-line">XP：${startClassStudentXp(st.id)}</div>
                <div class="start-card-summary">${escapeHtml(startClassAttendance[st.id] || "出席")}</div>
              </div>

              <div class="start-student-controls">
                <div class="start-att-row">
                  ${["出席","請假","缺席"].map(status=>`
                    <button class="${(startClassAttendance[st.id]||"出席")===status ? "active" : ""}"
                      onclick="startClassSetAttendance('${st.id}','${status}')">${status}</button>
                  `).join("")}
                </div>
                <div class="start-xp-actions">
                  <button onclick="startClassAddXp('${st.id}','participation',5)">+5</button>
                  <button onclick="startClassAddXp('${st.id}','breakthrough',10)">+10</button>
                  <button onclick="startClassAddXp('${st.id}','teamwork',15)">+15</button>
                </div>
              </div>

              <textarea id="startStudentRemark_${st.id}" class="start-student-remark" placeholder="個別備註 / 成長亮點"></textarea>
            </div>
          `).join("") : `<div class="note">這個課程目前沒有學生。</div>`}
          </div>
        </div>
      </section>
    </div>

    <div class="start-class-bottom">
      <button class="btn" onclick="guardedFirebaseUpload()">☁️ 先同步</button>
      <button class="btn gold" onclick="exitStartClassMode()">稍後儲存</button>
      <button class="btn primary" onclick="finishStartClass()">✅ 下課儲存並同步</button>
    </div>
  `;
}


/* =========================================================
   V7.3.2 START CLASS FORMAL ENTRY
   ========================================================= */
function ensureStartClassEntryButton(){
  /* v7.3.3：開始上課入口只保留左上主按鈕，避免重複入口。 */
}


/* =========================================================
   REWARD CLEAN CORE V7.5
   ---------------------------------------------------------
   統一處理：
   - 分類
   - 效期折扣
   - 圖片
   - 商店
   - 兌換
   - 兌換紀錄
   ========================================================= */
let rewardTabMode = "shop";
let currentRewardCategoryId = "all";
var rewardRedeemContext = window.rewardRedeemContext || {schoolId:"", classId:"", studentId:""};
window.rewardRedeemContext = rewardRedeemContext;

const RewardCore = {
  defaultCategories(){
    return [
      {id:"cat_snack", name:"零食區"},
      {id:"cat_toy", name:"玩具區"},
      {id:"cat_stationery", name:"文具區"}
    ];
  },

  defaultDiscount(){
    return {twoWeeksDays:14, twoWeeksRate:0.75, oneWeekDays:7, oneWeekRate:0.5};
  },

  ensure(){
    if(!Array.isArray(state.rewards)) state.rewards = [];
    if(!Array.isArray(state.rewardCategories) || !state.rewardCategories.length){
      state.rewardCategories = this.defaultCategories();
    }
    if(!state.rewardDiscountSettings){
      state.rewardDiscountSettings = this.defaultDiscount();
    }
    state.rewards.forEach(r=>{
      if(!r.id) r.id = makeId();
      if(r.name === undefined) r.name = "未命名獎品";
      if(r.categoryId === undefined) r.categoryId = "";
      if(r.expiryDate === undefined) r.expiryDate = "";
      if(r.stock === undefined) r.stock = 0;
      if(r.cost === undefined && r.price !== undefined) r.cost = r.price;
      if(r.cost === undefined) r.cost = 0;
      if(r.imageUrl === undefined) r.imageUrl = r.imgUrl || r.image || r.photoUrl || r.photo || "";
    });
    if(!Array.isArray(state.redeemLogs)) state.redeemLogs = [];
  },

  imageUrl(reward){
    return reward?.imageUrl || reward?.imgUrl || reward?.image || reward?.photoUrl || reward?.photo || "";
  },

  setImage(rewardId,url){
    const r = state.rewards.find(x=>x.id===rewardId);
    if(!r) return;
    r.imageUrl = url;
    r.imgUrl = url;
    r.image = url;
    saveState();
    markDirty?.("修改獎品圖片");
    renderRewards();
  },

  daysUntilExpiry(reward){
    if(!reward?.expiryDate) return null;
    const now = new Date(today() + "T00:00:00");
    const end = new Date(reward.expiryDate + "T00:00:00");
    const diff = Math.ceil((end - now) / (1000*60*60*24));
    return Number.isNaN(diff) ? null : diff;
  },

  discountInfo(reward){
    this.ensure();
    const days = this.daysUntilExpiry(reward);
    const s = state.rewardDiscountSettings || this.defaultDiscount();
    const original = Number(reward?.cost ?? reward?.price ?? 0) || 0;

    if(days === null || days < 0) return {price:original, original, rate:1, label:"", days};

    if(days <= Number(s.oneWeekDays || 7)){
      const rate = Number(s.oneWeekRate || 0.5);
      return {price:Math.round(original * rate), original, rate, label:`${Math.round(rate*100)}折`, days};
    }

    if(days <= Number(s.twoWeeksDays || 14)){
      const rate = Number(s.twoWeeksRate || 0.75);
      return {price:Math.round(original * rate), original, rate, label:`${Math.round(rate*100)}折`, days};
    }

    return {price:original, original, rate:1, label:"", days};
  },

  categoryName(id){
    this.ensure();
    return state.rewardCategories.find(c=>c.id===id)?.name || "未分類";
  },

  filteredRewards(){
    this.ensure();
    if(currentRewardCategoryId === "all") return state.rewards;
    if(currentRewardCategoryId === "uncat") return state.rewards.filter(r=>!r.categoryId);
    return state.rewards.filter(r=>r.categoryId === currentRewardCategoryId);
  },

  selectedSchoolId(){
    if(rewardRedeemContext.schoolId) return rewardRedeemContext.schoolId;
    return classContext?.schoolId || activeSchools()[0]?.id || "";
  },

  selectedClassId(){
    if(rewardRedeemContext.classId) return rewardRedeemContext.classId;
    const sid = this.selectedSchoolId();
    return classContext?.classId || activeClasses().find(c=>c.schoolId===sid)?.id || activeClasses()[0]?.id || "";
  },

  selectedStudentId(){
    if(rewardRedeemContext.studentId) return rewardRedeemContext.studentId;
    return studentsByClass(this.selectedClassId())[0]?.id || "";
  },

  setRedeemContext(field,value){
    rewardRedeemContext[field] = value;
    if(field === "schoolId"){
      const cls = activeClasses().find(c=>c.schoolId===value);
      rewardRedeemContext.classId = cls?.id || "";
      rewardRedeemContext.studentId = studentsByClass(rewardRedeemContext.classId)[0]?.id || "";
    }
    if(field === "classId"){
      rewardRedeemContext.studentId = studentsByClass(value)[0]?.id || "";
    }
    window.rewardRedeemContext = rewardRedeemContext;
    renderRewards();
  },

  studentPoints(studentId){
    if(typeof studentPoints === "function") return Number(studentPoints(studentId)) || 0;
    if(typeof getStudentPoints === "function") return Number(getStudentPoints(studentId)) || 0;

    const earned = (state.pointLogs || [])
      .filter(l=>l.studentId===studentId)
      .reduce((sum,l)=>sum+(Number(l.points ?? l.amount ?? 0)||0),0);

    const spent = (state.redeemLogs || [])
      .filter(l=>l.studentId===studentId)
      .reduce((sum,l)=>sum+(Number(l.cost ?? l.points ?? 0)||0),0);

    return earned - spent;
  },

  canRedeem(reward){
    const sid = this.selectedStudentId();
    const price = this.discountInfo(reward).price;
    return Boolean(sid) && this.studentPoints(sid) >= price && Number(reward.stock ?? 0) > 0;
  },

  redeem(rewardId){
    this.ensure();
    const reward = state.rewards.find(r=>r.id===rewardId);
    const studentId = this.selectedStudentId();
    if(!reward || !studentId) return alert("請先選擇學生。");

    const info = this.discountInfo(reward);
    const price = info.price;
    const points = this.studentPoints(studentId);
    const student = findById(state.students, studentId);

    if(Number(reward.stock ?? 0) <= 0) return alert("庫存不足，無法兌換。");
    if(points < price) return alert(`點數不足，目前 ${points} 點，需要 ${price} 點。`);

    if(!confirm(`確定讓「${student?.name || "學生"}」兌換「${reward.name}」？\n將扣除 ${price} 點。`)) return;

    state.redeemLogs.push({
      id:makeId(),
      studentId,
      rewardId,
      rewardName:reward.name,
      cost:price,
      originalCost:Number(reward.cost ?? reward.price ?? 0)||0,
      date:localIsoLikeString(),
      categoryId:reward.categoryId || "",
      discountLabel:info.label || ""
    });

    reward.stock = Math.max(0, Number(reward.stock ?? 0) - 1);
    saveState();
    markDirty?.("獎品兌換");
    alert("兌換完成。");
    renderRewards();
  },

  cancelRedeem(logId){
    this.ensure();
    const log = state.redeemLogs.find(x=>x.id===logId);
    if(!log) return alert("找不到這筆兌換紀錄。");
    const studentName = findById(state.students || [], log.studentId)?.name || "未知學生";

    if(!confirm(`確定取消「${studentName}」兌換「${log.rewardName || "獎品"}」？\n會移除這筆扣點紀錄，並嘗試把庫存加回。`)) return;

    const reward = state.rewards.find(r=>r.id===log.rewardId);
    if(reward) reward.stock = Number(reward.stock || 0) + 1;

    state.redeemLogs = state.redeemLogs.filter(x=>x.id!==logId);
    saveState();
    markDirty?.("取消獎品兌換");
    alert("已取消兌換。");
    renderRewards();
  }
};

/* Compatibility wrappers：避免舊按鈕或資料呼叫失效 */
function ensureRewardSystemV74(){ RewardCore.ensure(); }
function rewardImageUrl(r){ return RewardCore.imageUrl(r); }
function rewardDiscountInfo(r){ return RewardCore.discountInfo(r); }
function rewardCategoryName(id){ return RewardCore.categoryName(id); }
function rewardFilteredList(){ return RewardCore.filteredRewards(); }
function rewardStudentPoints(id){ return RewardCore.studentPoints(id); }
function rewardCanRedeem(r){ return RewardCore.canRedeem(r); }
function redeemRewardV742(id){ return RewardCore.redeem(id); }
function cancelRewardRedeem(id){ return RewardCore.cancelRedeem(id); }
function rewardSelectedSchoolId(){ return RewardCore.selectedSchoolId(); }
function rewardSelectedClassId(){ return RewardCore.selectedClassId(); }
function rewardSelectedStudentId(){ return RewardCore.selectedStudentId(); }
function setRewardRedeemContext(field,value){ return RewardCore.setRedeemContext(field,value); }

function addRewardCategory(){
  RewardCore.ensure();
  const name = prompt("請輸入分類名稱，例如：零食區、玩具區");
  if(!name) return;
  state.rewardCategories.push({id:makeId(), name:name.trim()});
  saveState();
  markDirty?.("新增獎品分類");
  renderRewards();
}

function updateRewardCategory(id,value){
  RewardCore.ensure();
  const c = state.rewardCategories.find(x=>x.id===id);
  if(!c) return;
  c.name = value;
  saveState();
  markDirty?.("修改獎品分類");
}

function deleteRewardCategory(id){
  RewardCore.ensure();
  const c = state.rewardCategories.find(x=>x.id===id);
  if(!c) return;
  if(!confirm(`確定刪除分類「${c.name}」？分類內獎品會改成未分類。`)) return;
  state.rewards.forEach(r=>{ if(r.categoryId===id) r.categoryId=""; });
  state.rewardCategories = state.rewardCategories.filter(x=>x.id!==id);
  if(currentRewardCategoryId === id) currentRewardCategoryId = "all";
  saveState();
  markDirty?.("刪除獎品分類");
  renderRewards();
}

function updateRewardDiscountSetting(field,value){
  RewardCore.ensure();
  if(field.includes("Rate")) state.rewardDiscountSettings[field] = Number(value) / 100;
  else state.rewardDiscountSettings[field] = Number(value);
  saveState();
  markDirty?.("修改獎品折扣設定");
}

function addRewardV74(){
  RewardCore.ensure();
  state.rewards.unshift({
    id:makeId(),
    name:"新獎品",
    cost:10,
    stock:1,
    categoryId: currentRewardCategoryId && !["all","uncat"].includes(currentRewardCategoryId) ? currentRewardCategoryId : "",
    expiryDate:"",
    imageUrl:"",
    imgUrl:"",
    image:"",
    createdAt:localIsoLikeString()
  });
  saveState();
  markDirty?.("新增獎品");
  renderRewards();
}

function updateRewardV74(id,field,value){
  RewardCore.ensure();
  const r = state.rewards.find(x=>x.id===id);
  if(!r) return;
  if(field==="cost" || field==="price" || field==="stock") r[field] = Number(value)||0;
  else r[field] = value;
  saveState();
  markDirty?.("修改獎品");
}

function deleteRewardV74(id){
  RewardCore.ensure();
  const r = state.rewards.find(x=>x.id===id);
  if(!r) return;
  if(!confirm(`刪除獎品「${r.name}」？`)) return;
  state.rewards = state.rewards.filter(x=>x.id!==id);
  saveState();
  markDirty?.("刪除獎品");
  renderRewards();
}

function updateRewardImageAll(id,value){
  const r = state.rewards.find(x=>x.id===id);
  if(!r) return;
  r.imageUrl = value;
  r.imgUrl = value;
  r.image = value;
  saveState();
  markDirty?.("修改獎品圖片");
}

function setRewardImageData(id,url){
  RewardCore.setImage(id,url);
}

function rewardImageFileToDataUrl(file){
  return new Promise((resolve,reject)=>{
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function handleRewardImageFile(id,input){
  const file = input.files?.[0];
  if(!file) return;

  try{
    if(typeof uploadImageToImgBB === "function"){
      const url = await uploadImageToImgBB(file);
      if(url) return RewardCore.setImage(id,url);
    }

    if(typeof uploadToImgBB === "function"){
      const url = await uploadToImgBB(file);
      if(url) return RewardCore.setImage(id,url);
    }

    const dataUrl = await rewardImageFileToDataUrl(file);
    RewardCore.setImage(id,dataUrl);
  }catch(err){
    console.error("handleRewardImageFile failed", err);
    alert("圖片讀取失敗，請再試一次。");
  }finally{
    input.value = "";
  }
}

function renderRewardPriceForShop(r){
  const d = RewardCore.discountInfo(r);
  if(d.rate < 1){
    return `<span class="reward-price-original">${d.original}</span><span class="reward-price-sale">${d.price}</span><span class="reward-discount-badge">${escapeHtml(d.label)}</span>`;
  }
  return `<b>${d.price}</b>`;
}

function renderRewardExpiryAdmin(r){
  const d = RewardCore.discountInfo(r);
  if(!r.expiryDate) return `<div class="small-muted">未設定食用期限</div>`;
  if(d.days < 0) return `<div class="reward-expiry-note">⚠️ 已過期 ${Math.abs(d.days)} 天｜${escapeHtml(r.expiryDate)}</div>`;
  if(d.rate < 1) return `<div class="reward-expiry-note">⏰ 距期限 ${d.days} 天，自動 ${escapeHtml(d.label)}｜${escapeHtml(r.expiryDate)}</div>`;
  return `<div class="small-muted">期限：${escapeHtml(r.expiryDate)}｜剩 ${d.days} 天</div>`;
}

function rewardLogStudentName(studentId){
  return findById(state.students || [], studentId)?.name || "未知學生";
}

function rewardLogClassNameByStudent(studentId){
  const enroll = (state.enrollments || []).find(e=>e.studentId===studentId);
  const cls = findById(state.classes || [], enroll?.classId);
  const school = findById(state.schools || [], cls?.schoolId);
  return `${school?.name || "未指定學校"}｜${cls?.name || "未指定課程"}`;
}

function renderRewards(){
  RewardCore.ensure();
  const categories = state.rewardCategories || [];
  const rewards = RewardCore.filteredRewards();

  document.getElementById("app").innerHTML = `
    <section class="card">
      <h2>🎁 獎品兌換</h2>
      <div class="reward-clean-core-note">v7.5：獎品分類、效期折扣、圖片、兌換流程與兌換紀錄已整理成同一套 RewardCore。</div>
      <div class="note">可依分類管理獎品；食用期限只在老師管理端顯示，學生商店不顯示期限。</div>
      <div class="tabs">
        <button class="${rewardTabMode==='shop'?'active':''}" onclick="rewardTabMode='shop'; renderRewards()">獎品商店</button>
        <button class="${rewardTabMode==='admin'?'active':''}" onclick="rewardTabMode='admin'; renderRewards()">老師管理</button>
        <button class="${rewardTabMode==='settings'?'active':''}" onclick="rewardTabMode='settings'; renderRewards()">分類與折扣</button>
        <button class="${rewardTabMode==='logs'?'active':''}" onclick="rewardTabMode='logs'; renderRewards()">兌換紀錄</button>
      </div>
    </section>
    ${rewardTabMode === "shop" ? renderRewardShopV75(rewards,categories) : ""}
    ${rewardTabMode === "admin" ? renderRewardAdminV75(rewards,categories) : ""}
    ${rewardTabMode === "settings" ? renderRewardSettingsV75(categories) : ""}
    ${rewardTabMode === "logs" ? renderRewardLogsV75() : ""}
  `;
}

function renderRewardCategoryTabsV75(categories){
  return `
    <div class="reward-shop-tabs">
      <button class="${currentRewardCategoryId==='all'?'active':''}" onclick="currentRewardCategoryId='all'; renderRewards()">全部</button>
      ${categories.map(c=>`<button class="${currentRewardCategoryId===c.id?'active':''}" onclick="currentRewardCategoryId='${c.id}'; renderRewards()">${escapeHtml(c.name)}</button>`).join("")}
      <button class="${currentRewardCategoryId==='uncat'?'active':''}" onclick="currentRewardCategoryId='uncat'; renderRewards()">未分類</button>
    </div>
  `;
}

function renderRewardShopV75(rewards,categories){
  const schoolId = RewardCore.selectedSchoolId();
  const classId = RewardCore.selectedClassId();
  const studentId = RewardCore.selectedStudentId();
  const schoolOptions = activeSchools();
  const classOptions = activeClasses().filter(c=>!schoolId || c.schoolId===schoolId);
  const studentOptions = studentsByClass(classId);
  const points = studentId ? RewardCore.studentPoints(studentId) : 0;

  return `
    <section class="card">
      <h3>🛒 獎品商店 <span class="reward-student-points">目前點數：${points}</span></h3>

      <div class="reward-redeem-selector">
        <div>
          <label>學校</label>
          <select onchange="RewardCore.setRedeemContext('schoolId',this.value)">
            ${schoolOptions.map(s=>`<option value="${s.id}" ${schoolId===s.id?'selected':''}>${escapeHtml(s.name)}</option>`).join("")}
          </select>
        </div>
        <div>
          <label>課程／班級</label>
          <select onchange="RewardCore.setRedeemContext('classId',this.value)">
            ${classOptions.map(c=>`<option value="${c.id}" ${classId===c.id?'selected':''}>${escapeHtml(c.name)}</option>`).join("")}
          </select>
        </div>
        <div>
          <label>學生</label>
          <select onchange="RewardCore.setRedeemContext('studentId',this.value); renderRewards()">
            ${studentOptions.map(st=>`<option value="${st.id}" ${studentId===st.id?'selected':''}>${escapeHtml(st.name)}</option>`).join("")}
          </select>
        </div>
      </div>

      ${renderRewardCategoryTabsV75(categories)}

      <div class="reward-shop-grid">
        ${rewards.length ? rewards.map(r=>{
          const can = RewardCore.canRedeem(r);
          const price = RewardCore.discountInfo(r).price;
          return `
            <div class="reward-shop-card">
              ${RewardCore.imageUrl(r) ? `<img class="reward-shop-img" src="${escapeHtml(RewardCore.imageUrl(r))}">` : `<div class="reward-shop-img" style="display:flex;align-items:center;justify-content:center;font-size:42px">🎁</div>`}
              <div class="reward-card-body">
                <h3>${escapeHtml(r.name || "未命名獎品")}</h3>
                <div class="small-muted">${escapeHtml(RewardCore.categoryName(r.categoryId))}</div>
                <div>需要點數：${renderRewardPriceForShop(r)}</div>
                <div>庫存：${Number(r.stock ?? 0)}</div>
              </div>
              <button class="reward-redeem-button ${can?'can':'cannot'}" onclick="RewardCore.redeem('${r.id}')">
                ${can ? `兌換（${price}點）` : `點數不足／不可兌換`}
              </button>
            </div>
          `;
        }).join("") : `<div class="note">目前沒有獎品。</div>`}
      </div>
    </section>
  `;
}

function renderRewardAdminV75(rewards,categories){
  return `
    <section class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <h3>🧑‍🏫 老師獎品管理</h3>
        <button class="btn primary" onclick="addRewardV74()">＋ 新增獎品</button>
      </div>
      ${renderRewardCategoryTabsV75(categories)}

      <div class="reward-admin-list">
        ${rewards.length ? rewards.map(r=>`
          <div class="reward-admin-card">
            <div>
              ${RewardCore.imageUrl(r) ? `<img class="reward-admin-img" src="${escapeHtml(RewardCore.imageUrl(r))}">` : `<div class="reward-admin-img">🎁</div>`}
            </div>

            <div class="reward-admin-fields">
              <div class="reward-admin-field">
                <label>獎品名稱</label>
                <input value="${escapeHtml(r.name || "")}" oninput="updateRewardV74('${r.id}','name',this.value)">
              </div>

              <div class="reward-admin-field">
                <label>分類</label>
                <select onchange="updateRewardV74('${r.id}','categoryId',this.value); renderRewards()">
                  <option value="" ${!r.categoryId?'selected':''}>未分類</option>
                  ${categories.map(c=>`<option value="${c.id}" ${r.categoryId===c.id?'selected':''}>${escapeHtml(c.name)}</option>`).join("")}
                </select>
              </div>

              <div class="reward-admin-field">
                <label>原價點數</label>
                <input type="number" value="${Number(r.cost ?? r.price ?? 0)}" oninput="updateRewardV74('${r.id}','cost',this.value)">
              </div>

              <div class="reward-admin-field">
                <label>庫存</label>
                <input type="number" value="${Number(r.stock ?? 0)}" oninput="updateRewardV74('${r.id}','stock',this.value)">
              </div>

              <div class="reward-admin-field">
                <label>食用期限／有效期限（學生商店不顯示）</label>
                <input type="date" value="${escapeHtml(r.expiryDate || "")}" onchange="updateRewardV74('${r.id}','expiryDate',this.value); renderRewards()">
                ${renderRewardExpiryAdmin(r)}
              </div>

              <div class="reward-admin-field">
                <label>圖片</label>
                <input value="${escapeHtml(RewardCore.imageUrl(r))}" placeholder="圖片網址，或使用下方拍照／選圖" oninput="updateRewardImageAll('${r.id}',this.value)">
                <div class="reward-image-actions">
                  <label class="btn gold">📷 拍照／選擇圖片<input type="file" accept="image/*" capture="environment" onchange="handleRewardImageFile('${r.id}',this)"></label>
                  <label class="btn">🖼️ 從相簿選圖<input type="file" accept="image/*" onchange="handleRewardImageFile('${r.id}',this)"></label>
                </div>
                <div class="reward-upload-status">手機／iPad 可直接拍照；若 ImgBB 設定可用會上傳雲端，否則先存在本機資料。</div>
              </div>
            </div>

            <div class="reward-admin-actions">
              <button class="btn red" onclick="deleteRewardV74('${r.id}')">刪除獎品</button>
            </div>
          </div>
        `).join("") : `<div class="note">目前沒有獎品。</div>`}
      </div>
    </section>
  `;
}

function renderRewardSettingsV75(categories){
  const s = state.rewardDiscountSettings;
  return `
    <div class="reward-admin-grid">
      <section class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
          <h3>🏷️ 分類管理</h3>
          <button class="btn primary" onclick="addRewardCategory()">＋ 新增分類</button>
        </div>
        ${categories.length ? categories.map(c=>`
          <div class="reward-category-card">
            <input value="${escapeHtml(c.name)}" oninput="updateRewardCategory('${c.id}',this.value)">
            <button class="btn red" onclick="deleteRewardCategory('${c.id}')">刪除</button>
          </div>
        `).join("") : `<div class="note">尚未建立分類。</div>`}
      </section>

      <section class="card">
        <h3>⏰ 效期折扣設定</h3>
        <div class="note">折扣會套用在商店價格，計算到個位數；食用期限只在老師管理端顯示。</div>
        <div class="reward-settings-row"><label>前幾天啟用第一段折扣</label><input type="number" value="${Number(s.twoWeeksDays || 14)}" onchange="updateRewardDiscountSetting('twoWeeksDays',this.value)"></div>
        <div class="reward-settings-row"><label>第一段折扣百分比（預設75）</label><input type="number" value="${Math.round(Number(s.twoWeeksRate || 0.75)*100)}" onchange="updateRewardDiscountSetting('twoWeeksRate',this.value)"></div>
        <div class="reward-settings-row"><label>前幾天啟用第二段折扣</label><input type="number" value="${Number(s.oneWeekDays || 7)}" onchange="updateRewardDiscountSetting('oneWeekDays',this.value)"></div>
        <div class="reward-settings-row"><label>第二段折扣百分比（預設50）</label><input type="number" value="${Math.round(Number(s.oneWeekRate || 0.5)*100)}" onchange="updateRewardDiscountSetting('oneWeekRate',this.value)"></div>
      </section>
    </div>
  `;
}

function renderRewardLogsV75(){
  RewardCore.ensure();
  const logs = [...state.redeemLogs].sort((a,b)=>String(b.date||"").localeCompare(String(a.date||"")));

  return `
    <section class="card">
      <h3>📒 兌換紀錄</h3>
      <div class="note">這裡是獎品兌換帳本。若兌換錯誤，可以按「取消兌換」，系統會移除扣點紀錄並嘗試把庫存加回。</div>
      <div class="reward-log-list">
        ${logs.length ? logs.map(log=>`
          <div class="reward-log-item">
            <div>
              <div class="reward-log-meta">${escapeHtml(rewardLogStudentName(log.studentId))} 兌換 ${escapeHtml(log.rewardName || "獎品")}</div>
              <div class="reward-log-sub">
                ${escapeHtml(rewardLogClassNameByStudent(log.studentId))}<br>
                ${escapeHtml(safeFormatDateTime(log.date || ""))}｜扣除 ${Number(log.cost ?? log.points ?? 0)} 點
                ${log.discountLabel ? `｜${escapeHtml(log.discountLabel)}` : ""}
              </div>
            </div>
            <button class="btn red" onclick="RewardCore.cancelRedeem('${log.id}')">取消兌換</button>
          </div>
        `).join("") : `<div class="note">目前沒有兌換紀錄。</div>`}
      </div>
    </section>
  `;
}

/* 舊函式名相容 */
function renderRewardCategoryTabsV74(c){ return renderRewardCategoryTabsV75(c); }
function renderRewardShopV74(r,c){ return renderRewardShopV75(r,c); }
function renderRewardAdminV74(r,c){ return renderRewardAdminV75(r,c); }
function renderRewardSettingsV74(c){ return renderRewardSettingsV75(c); }
function renderRewardLogsV744(){ return renderRewardLogsV75(); }


/* =========================================================
   PERFORMANCE WORKSPACE CLEAN CORE V8.0
   ========================================================= */
let performanceViewMode = "overview";
let performanceDetailTab = "dashboard";

const PerformanceCore = {
  ensure(){
    if(!Array.isArray(state.performances)) state.performances = [];
    state.performances.forEach(p=>{
      if(!p.id) p.id = makeId();
      if(!Array.isArray(p.songs)) p.songs = [];
      if(!Array.isArray(p.tasks)) p.tasks = [];
      if(!Array.isArray(p.flow)) p.flow = [];
      if(!p.status) p.status = "籌備中";
      p.songs.forEach(song=>{
        if(!song.id) song.id = makeId();
        if(!Array.isArray(song.assignments)) song.assignments = [];
        if(!song.status) song.status = "待加強";
        if(song.issue === undefined) song.issue = "";
        song.assignments.forEach(a=>{
          if(!a.id) a.id = makeId();
          if(!Array.isArray(a.studentIds)) a.studentIds = [];
          if(!a.studentParts) a.studentParts = {};
          if(a.part === undefined) a.part = "";
        });
      });
    });
  },
  current(){ this.ensure(); return state.performances.find(x=>x.id===state.currentPerformanceId) || state.performances[0] || null; },
  daysLeft(dateStr){
    if(!dateStr) return "";
    const todayDate = new Date(today() + "T00:00:00");
    const target = new Date(dateStr + "T00:00:00");
    const diff = Math.ceil((target - todayDate) / (1000*60*60*24));
    if(Number.isNaN(diff)) return "";
    if(diff > 0) return `倒數 ${diff} 天`;
    if(diff === 0) return "今天演出";
    return `已過 ${Math.abs(diff)} 天`;
  },
  statusClass(status){
    if(status === "完成") return "perf-v8-green";
    if(status === "練習中") return "perf-v8-yellow";
    if(status === "待加強") return "perf-v8-red";
    return "perf-v8-blue";
  },
  allAssignments(p){ return (p?.songs || []).flatMap(song => (song.assignments || []).map(a=>({song,a}))); },
  studentCount(p){
    const ids = new Set();
    this.allAssignments(p).forEach(({a})=>(a.studentIds || []).forEach(id=>ids.add(id)));
    return ids.size;
  },
  songCompletion(p){
    const songs = p?.songs || [];
    if(!songs.length) return 0;
    const score = songs.reduce((sum,s)=>{
      if(s.status === "完成") return sum + 1;
      if(s.status === "練習中") return sum + 0.5;
      return sum;
    },0);
    return Math.round(score / songs.length * 100);
  },
  undoneTaskCount(p){ return (p?.tasks || []).filter(t=>!t.done).length; },
  warningList(p){
    const warnings = [];
    (p?.songs || []).forEach(song=>{
      const partCounter = {};
      (song.assignments || []).forEach(a=>{
        (a.studentIds || []).forEach(studentId=>{
          const part = this.studentPart(a, studentId);
          if(part && part !== "未指定聲部") partCounter[part] = (partCounter[part] || 0) + 1;
        });
      });
      Object.entries(partCounter).forEach(([part,count])=>{
        if(count <= 1) warnings.push(`《${song.title || "未命名曲目"}》${part} 只有 ${count} 人`);
      });
      if(!(song.assignments || []).some(a=>(a.studentIds || []).length)) warnings.push(`《${song.title || "未命名曲目"}》尚未配置學生`);
    });
    return warnings;
  },
  create(){
    this.ensure();
    const item = {
      id: makeId(), title: "新演出", date: today(), location: "", gatherTime: "", costume: "",
      status: "籌備中", notes: "", songs: [],
      tasks: [{id:makeId(), text:"確認曲目順序", done:false},{id:makeId(), text:"確認集合時間", done:false},{id:makeId(), text:"確認服裝", done:false}],
      flow: [{id:makeId(), time:"", title:"集合", note:""},{id:makeId(), time:"", title:"暖身", note:""},{id:makeId(), time:"", title:"上台", note:""}],
      createdAt: localIsoLikeString()
    };
    state.performances.unshift(item);
    state.currentPerformanceId = item.id;
    performanceViewMode = "detail";
    performanceDetailTab = "info";
    saveState(); markDirty?.("新增演出"); renderPerformanceCenter();
  },
  select(id){ state.currentPerformanceId = id; performanceViewMode = "detail"; performanceDetailTab = "dashboard"; saveState(); renderPerformanceCenter(); },
  saveField(field,value){ const p=this.current(); if(!p) return; p[field]=value; saveState(); markDirty?.("演出資料"); },
  deleteCurrent(){
    const p=this.current(); if(!p) return;
    if(!confirm(`確定刪除「${p.title || "未命名演出"}」？`)) return;
    state.performances = state.performances.filter(x=>x.id!==p.id);
    state.currentPerformanceId = state.performances[0]?.id || "";
    performanceViewMode = "overview"; saveState(); markDirty?.("刪除演出"); renderPerformanceCenter();
  },
  addSong(){ const p=this.current(); if(!p) return; p.songs.push({id:makeId(), title:"新曲目", status:"待加強", issue:"", rehearsalFocus:"", assignments:[]}); saveState(); markDirty?.("新增演出曲目"); renderPerformanceCenter(); },
  updateSong(songId,field,value,rerender=false){ const song=this.current()?.songs.find(s=>s.id===songId); if(!song) return; song[field]=value; saveState(); markDirty?.("曲目資料"); if(rerender) renderPerformanceCenter(); },
  deleteSong(songId){ const p=this.current(); if(!p) return; p.songs=p.songs.filter(s=>s.id!==songId); saveState(); markDirty?.("刪除曲目"); renderPerformanceCenter(); },
  addAssignment(songId){
    const song=this.current()?.songs.find(s=>s.id===songId); if(!song) return;
    const firstSchool = activeSchools()[0]?.id || "";
    const firstClass = activeClasses().find(c=>c.schoolId===firstSchool)?.id || activeClasses()[0]?.id || "";
    song.assignments.push({id:makeId(), schoolId:firstSchool, classId:firstClass, part:"", studentIds:[], studentParts:{}});
    saveState(); markDirty?.("新增曲目配置"); renderPerformanceCenter();
  },
  updateAssignment(songId,assignmentId,field,value){
    const song=this.current()?.songs.find(s=>s.id===songId);
    const a=song?.assignments.find(x=>x.id===assignmentId); if(!a) return;
    a[field]=value;
    if(field==="schoolId"){ a.classId=activeClasses().find(c=>c.schoolId===value)?.id || ""; a.studentIds=[]; a.studentParts={}; }
    if(field==="classId"){ a.studentIds=[]; a.studentParts={}; }
    saveState(); markDirty?.("修改曲目配置"); renderPerformanceCenter();
  },
  toggleStudent(songId,assignmentId,studentId,checked){
    const song=this.current()?.songs.find(s=>s.id===songId);
    const a=song?.assignments.find(x=>x.id===assignmentId); if(!a) return;
    if(!Array.isArray(a.studentIds)) a.studentIds=[]; if(!a.studentParts) a.studentParts={};
    if(checked){ if(!a.studentIds.includes(studentId)) a.studentIds.push(studentId); if(!a.studentParts[studentId]) a.studentParts[studentId]=a.part||""; }
    else{ a.studentIds=a.studentIds.filter(id=>id!==studentId); delete a.studentParts[studentId]; }
    saveState(); markDirty?.("修改演出學生"); renderPerformanceCenter();
  },
  deleteAssignment(songId,assignmentId){
    const song=this.current()?.songs.find(s=>s.id===songId); if(!song) return;
    song.assignments=song.assignments.filter(a=>a.id!==assignmentId); saveState(); markDirty?.("刪除曲目配置"); renderPerformanceCenter();
  },
  studentPart(a,studentId){ if(!a.studentParts) a.studentParts={}; return a.studentParts[studentId] || a.part || "未指定聲部"; },
  updateStudentPart(songId,assignmentId,studentId,value){
    const song=this.current()?.songs.find(s=>s.id===songId);
    const a=song?.assignments.find(x=>x.id===assignmentId); if(!a) return;
    if(!a.studentParts) a.studentParts={}; a.studentParts[studentId]=value; saveState(); markDirty?.("修改學生聲部");
  },
  selectedStudents(a){ return studentsByClass(a.classId).filter(st=>a.studentIds?.includes(st.id)); },
  groupedSong(song){
    const groups = {};
    (song.assignments || []).forEach(a=>{
      const school = activeSchools().find(s=>s.id===a.schoolId);
      const cls = activeClasses().find(c=>c.id===a.classId);
      const schoolName = school?.name || "未指定學校";
      const className = cls?.name || "未指定班級";
      if(!groups[schoolName]) groups[schoolName] = {};
      if(!groups[schoolName][className]) groups[schoolName][className] = [];
      (a.studentIds || []).forEach(studentId=>{
        const st = (state.students || []).find(x=>x.id===studentId);
        if(st) groups[schoolName][className].push({id:st.id, name:st.name, part:this.studentPart(a, studentId)});
      });
    });
    return groups;
  },
  addTask(){ const p=this.current(); if(!p) return; if(!Array.isArray(p.tasks)) p.tasks=[]; p.tasks.push({id:makeId(), text:"新任務", done:false}); saveState(); markDirty?.("新增演出任務"); renderPerformanceCenter(); },
  updateTask(taskId,field,value){ const task=this.current()?.tasks.find(t=>t.id===taskId); if(!task) return; task[field]=value; saveState(); markDirty?.("修改演出任務"); },
  deleteTask(taskId){ const p=this.current(); if(!p) return; p.tasks=p.tasks.filter(t=>t.id!==taskId); saveState(); markDirty?.("刪除演出任務"); renderPerformanceCenter(); },
  addFlow(){ const p=this.current(); if(!p) return; if(!Array.isArray(p.flow)) p.flow=[]; p.flow.push({id:makeId(), time:"", title:"新流程", note:""}); saveState(); markDirty?.("新增演出流程"); renderPerformanceCenter(); },
  updateFlow(flowId,field,value){ const item=this.current()?.flow.find(f=>f.id===flowId); if(!item) return; item[field]=value; saveState(); markDirty?.("修改演出流程"); },
  deleteFlow(flowId){ const p=this.current(); if(!p) return; p.flow=p.flow.filter(f=>f.id!==flowId); saveState(); markDirty?.("刪除演出流程"); renderPerformanceCenter(); }
};

function ensurePerformanceCenter(){ PerformanceCore.ensure(); }
function currentPerformance(){ return PerformanceCore.current(); }
function perfDaysLeft(d){ return PerformanceCore.daysLeft(d); }
function perfStatusClass(s){ return PerformanceCore.statusClass(s); }
function performanceStudentCount(p){ return PerformanceCore.studentCount(p); }
function performanceSongCompletion(p){ return PerformanceCore.songCompletion(p); }
function performanceTaskUndoneCount(p){ return PerformanceCore.undoneTaskCount(p); }

function renderPerformanceCenter(){
  PerformanceCore.ensure();
  if(performanceViewMode === "detail" && PerformanceCore.current()) renderPerformanceWorkspace();
  else renderPerformanceHome();
}

function renderPerformanceHome(){
  const events = [...(state.performances || [])].sort((a,b)=>String(a.date||"").localeCompare(String(b.date||"")));
  const upcoming = events.filter(e=>!e.date || e.date >= today()).length;
  const songCount = events.reduce((sum,e)=>sum+(e.songs?.length||0),0);
  const warningCount = events.reduce((sum,e)=>sum+PerformanceCore.warningList(e).length,0);
  document.getElementById("app").innerHTML = `
    <section class="card">
      <h2>🎭 演出工作台</h2>
      <div class="note">v8.0：演出中心已整理為演出工作台。首頁看總覽，點進去才編輯與配置。</div>
      <button class="btn gold" onclick="PerformanceCore.create()">＋ 新增演出</button>
    </section>
    <div class="perf-v8-dashboard">
      <div class="perf-v8-stat"><b>近期演出</b><div class="num">${upcoming}</div></div>
      <div class="perf-v8-stat"><b>總曲目</b><div class="num">${songCount}</div></div>
      <div class="perf-v8-stat"><b>待處理提醒</b><div class="num">${warningCount}</div></div>
    </div>
    <section class="card">
      <h3>📅 演出總覽</h3>
      <div class="perf-v8-event-list">
        ${events.length ? events.map(e=>{
          const warnings = PerformanceCore.warningList(e);
          return `
            <div class="perf-v8-event-card">
              <h3>${escapeHtml(e.title || "未命名演出")}</h3>
              <div class="note">${escapeHtml(e.date || "未設定日期")}｜${escapeHtml(PerformanceCore.daysLeft(e.date))}<br>地點：${escapeHtml(e.location || "未設定")}<br>集合：${escapeHtml(e.gatherTime || "未設定")}</div>
              <div><span class="perf-v8-pill perf-v8-blue">曲目 ${e.songs?.length || 0}</span><span class="perf-v8-pill perf-v8-green">完成度 ${PerformanceCore.songCompletion(e)}%</span><span class="perf-v8-pill perf-v8-yellow">學生 ${PerformanceCore.studentCount(e)}</span><span class="perf-v8-pill perf-v8-red">提醒 ${warnings.length}</span></div>
              ${warnings.length ? `<div class="perf-v8-warning">${warnings.slice(0,3).map(escapeHtml).join("<br>")}</div>` : ""}
              <button class="btn primary" onclick="PerformanceCore.select('${e.id}')">打開工作台</button>
            </div>`;
        }).join("") : `<div class="note">尚未建立演出。</div>`}
      </div>
    </section>`;
}

function renderPerformanceWorkspace(){
  const p = PerformanceCore.current();
  if(!p) return renderPerformanceHome();
  document.getElementById("app").innerHTML = `
    <section class="card">
      <button class="btn" onclick="performanceViewMode='overview'; renderPerformanceCenter()">← 回演出總覽</button>
      <h2>🎭 ${escapeHtml(p.title || "未命名演出")}</h2>
      <div class="note">${escapeHtml(p.date || "未設定日期")}｜${escapeHtml(PerformanceCore.daysLeft(p.date))}｜${escapeHtml(p.location || "未設定地點")}</div>
      <div class="perf-v8-dashboard">
        <div class="perf-v8-stat"><b>曲目完成度</b><div class="num">${PerformanceCore.songCompletion(p)}%</div></div>
        <div class="perf-v8-stat"><b>演出學生</b><div class="num">${PerformanceCore.studentCount(p)}</div></div>
        <div class="perf-v8-stat"><b>未完成任務</b><div class="num">${PerformanceCore.undoneTaskCount(p)}</div></div>
      </div>
      <div class="perf-v8-tabs">
        ${[["dashboard","儀表板"],["info","演出資訊"],["songs","曲目配置"],["tasks","排練任務"],["flow","演出流程"],["export","匯出"]].map(([id,name])=>`<button class="${performanceDetailTab===id?'active':''}" onclick="performanceDetailTab='${id}'; renderPerformanceCenter()">${name}</button>`).join("")}
      </div>
    </section>
    ${performanceDetailTab === "dashboard" ? renderPerformanceDashboardV8(p) : ""}
    ${performanceDetailTab === "info" ? renderPerformanceInfoV8(p) : ""}
    ${performanceDetailTab === "songs" ? renderPerformanceSongsV8(p) : ""}
    ${performanceDetailTab === "tasks" ? renderPerformanceTasksV8(p) : ""}
    ${performanceDetailTab === "flow" ? renderPerformanceFlowV8(p) : ""}
    ${performanceDetailTab === "export" ? renderPerformanceExportV8(p) : ""}`;
}

function renderPerformanceDashboardV8(p){
  const warnings = PerformanceCore.warningList(p);
  return `<section class="card"><h3>📌 今日工作重點</h3>${warnings.length ? `<div class="perf-v8-warning">${warnings.map(escapeHtml).join("<br>")}</div>` : `<div class="note">目前沒有明顯配置警示。</div>`}
  <div class="perf-v8-layout"><div class="perf-v8-card"><h3>🎼 曲目狀態</h3>${(p.songs||[]).length ? p.songs.map(s=>`<div class="perf-v8-song"><b>${escapeHtml(s.title||"未命名曲目")}</b> <span class="perf-v8-pill ${PerformanceCore.statusClass(s.status)}">${escapeHtml(s.status||"待加強")}</span><div class="small-muted">${escapeHtml(s.issue||"尚無危險段落")}</div></div>`).join("") : `<div class="note">尚未建立曲目。</div>`}</div>
  <div class="perf-v8-card"><h3>✅ 未完成任務</h3>${(p.tasks||[]).filter(t=>!t.done).length ? (p.tasks||[]).filter(t=>!t.done).map(t=>`<div>□ ${escapeHtml(t.text||"未命名任務")}</div>`).join("") : `<div class="note">任務都完成了。</div>`}</div></div></section>`;
}

function renderPerformanceInfoV8(p){
  return `<section class="card"><h3>✏️ 演出資訊</h3>
  <label>演出名稱</label><input value="${escapeHtml(p.title||"")}" oninput="PerformanceCore.saveField('title',this.value)">
  <label>日期</label><input type="date" value="${escapeHtml(p.date||"")}" onchange="PerformanceCore.saveField('date',this.value)">
  <label>地點</label><input value="${escapeHtml(p.location||"")}" oninput="PerformanceCore.saveField('location',this.value)">
  <label>集合時間</label><input value="${escapeHtml(p.gatherTime||"")}" oninput="PerformanceCore.saveField('gatherTime',this.value)">
  <label>服裝</label><input value="${escapeHtml(p.costume||"")}" oninput="PerformanceCore.saveField('costume',this.value)">
  <label>狀態</label><select onchange="PerformanceCore.saveField('status',this.value)">${["籌備中","排練中","完成","已結束"].map(s=>`<option ${p.status===s?'selected':''}>${s}</option>`).join("")}</select>
  <label>注意事項</label><textarea oninput="PerformanceCore.saveField('notes',this.value)">${escapeHtml(p.notes||"")}</textarea>
  <button class="btn red" onclick="PerformanceCore.deleteCurrent()">刪除這場演出</button></section>`;
}

function renderPerformanceSongsV8(p){
  return `<section class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h3>🎼 曲目配置</h3><button class="btn primary" onclick="PerformanceCore.addSong()">＋ 新增曲目</button></div>
  ${(p.songs||[]).length ? p.songs.map(song=>`<div class="perf-v8-song">
    <label>曲目名稱</label><input value="${escapeHtml(song.title||"")}" oninput="PerformanceCore.updateSong('${song.id}','title',this.value)">
    <label>排練狀態</label><select onchange="PerformanceCore.updateSong('${song.id}','status',this.value,true)">${["待加強","練習中","完成"].map(s=>`<option ${song.status===s?'selected':''}>${s}</option>`).join("")}</select>
    <label>本次排練重點</label><textarea oninput="PerformanceCore.updateSong('${song.id}','rehearsalFocus',this.value)">${escapeHtml(song.rehearsalFocus||"")}</textarea>
    <label>危險段落 / 目前問題</label><textarea oninput="PerformanceCore.updateSong('${song.id}','issue',this.value)">${escapeHtml(song.issue||"")}</textarea>
    <h4>👀 配置視覺化</h4>${renderSongVisualTreeV8(song)}
    <h4>⚙️ 配置編輯</h4><button class="btn gold" onclick="PerformanceCore.addAssignment('${song.id}')">＋ 新增學校 / 課程 / 學生配置</button> <button class="btn red" onclick="PerformanceCore.deleteSong('${song.id}')">刪除曲目</button>
    ${(song.assignments||[]).map(a=>renderSongAssignmentV8(song,a)).join("")}</div>`).join("") : `<div class="note">尚未建立曲目。</div>`}</section>`;
}

function renderSongVisualTreeV8(song){
  const groups = PerformanceCore.groupedSong(song);
  const schoolNames = Object.keys(groups);
  if(!schoolNames.length) return `<div class="note">尚未配置學生。</div>`;
  const partCounter = {}; let total = 0;
  Object.values(groups).forEach(classes=>Object.values(classes).forEach(students=>{ total += students.length; students.forEach(st=>partCounter[st.part]=(partCounter[st.part]||0)+1); }));
  return `<div class="perf-v8-card"><div><span class="perf-v8-pill perf-v8-blue">學校 ${schoolNames.length}</span><span class="perf-v8-pill perf-v8-yellow">學生 ${total}</span>${Object.entries(partCounter).map(([part,count])=>`<span class="perf-v8-pill perf-v8-green">${escapeHtml(part)} ${count}</span>`).join("")}</div>
  ${schoolNames.map(schoolName=>`<div class="perf-v8-part-card"><b>🏫 ${escapeHtml(schoolName)}</b>${Object.keys(groups[schoolName]).map(className=>`<details open><summary>📚 ${escapeHtml(className)}（${groups[schoolName][className].length}人）</summary>${groups[schoolName][className].map(st=>`<div class="perf-v8-student-chip"><span>👤 ${escapeHtml(st.name)}</span><span class="perf-v8-pill perf-v8-blue">${escapeHtml(st.part)}</span></div>`).join("")}</details>`).join("")}</div>`).join("")}</div>`;
}

function renderSongAssignmentV8(song,a){
  const schools = activeSchools();
  const classes = activeClasses().filter(c=>!a.schoolId || c.schoolId===a.schoolId);
  const students = studentsByClass(a.classId);
  return `<div class="perf-v8-assignment"><h4>🎒 演出學生配置</h4><div class="row">
  <div class="f4"><label>學校</label><select onchange="PerformanceCore.updateAssignment('${song.id}','${a.id}','schoolId',this.value)">${schools.map(s=>`<option value="${s.id}" ${a.schoolId===s.id?'selected':''}>${escapeHtml(s.name)}</option>`).join("")}</select></div>
  <div class="f4"><label>課程／班級</label><select onchange="PerformanceCore.updateAssignment('${song.id}','${a.id}','classId',this.value)">${classes.map(c=>`<option value="${c.id}" ${a.classId===c.id?'selected':''}>${escapeHtml(c.name)}</option>`).join("")}</select></div>
  <div class="f4"><label>預設聲部／樂器</label><input value="${escapeHtml(a.part||"")}" oninput="PerformanceCore.updateAssignment('${song.id}','${a.id}','part',this.value)" placeholder="例如：第一部 / 高音笛"></div></div>
  <label>勾選學生</label><div class="perf-v8-check-grid">${students.length ? students.map(st=>`<label class="perf-v8-check"><input type="checkbox" ${a.studentIds?.includes(st.id)?'checked':''} onchange="PerformanceCore.toggleStudent('${song.id}','${a.id}','${st.id}',this.checked)"><span>${escapeHtml(st.name)}</span></label>`).join("") : `<div class="note">這個課程目前沒有學生。</div>`}</div>
  ${(a.studentIds||[]).length ? `<h4>🎺 個別聲部設定</h4>${PerformanceCore.selectedStudents(a).map(st=>`<div class="perf-v8-student-chip"><b>👤 ${escapeHtml(st.name)}</b><input value="${escapeHtml(PerformanceCore.studentPart(a,st.id)||"")}" placeholder="例如：第一部 / 高音笛" oninput="PerformanceCore.updateStudentPart('${song.id}','${a.id}','${st.id}',this.value)"></div>`).join("")}` : `<div class="small-muted">勾選學生後，可在這裡設定每位學生聲部。</div>`}
  <button class="btn red" onclick="PerformanceCore.deleteAssignment('${song.id}','${a.id}')">刪除這組配置</button></div>`;
}

function renderPerformanceTasksV8(p){
  return `<section class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h3>✅ 排練任務</h3><button class="btn primary" onclick="PerformanceCore.addTask()">＋ 新增任務</button></div>
  ${(p.tasks||[]).length ? p.tasks.map(t=>`<div class="perf-v8-task"><input type="checkbox" ${t.done?'checked':''} onchange="PerformanceCore.updateTask('${t.id}','done',this.checked); renderPerformanceCenter()"><input value="${escapeHtml(t.text||"")}" oninput="PerformanceCore.updateTask('${t.id}','text',this.value)"><button class="btn red" onclick="PerformanceCore.deleteTask('${t.id}')">刪除</button></div>`).join("") : `<div class="note">尚未新增任務。</div>`}</section>`;
}

function renderPerformanceFlowV8(p){
  if(!Array.isArray(p.flow)) p.flow = [];
  return `<section class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h3>🕒 演出流程</h3><button class="btn primary" onclick="PerformanceCore.addFlow()">＋ 新增流程</button></div>
  ${p.flow.length ? p.flow.map(f=>`<div class="perf-v8-flow-item"><input value="${escapeHtml(f.time||"")}" placeholder="時間" oninput="PerformanceCore.updateFlow('${f.id}','time',this.value)"><div><input value="${escapeHtml(f.title||"")}" placeholder="流程名稱" oninput="PerformanceCore.updateFlow('${f.id}','title',this.value)"><textarea placeholder="備註，例如：Bass 先上台、服裝確認" oninput="PerformanceCore.updateFlow('${f.id}','note',this.value)">${escapeHtml(f.note||"")}</textarea></div><button class="btn red" onclick="PerformanceCore.deleteFlow('${f.id}')">刪除</button></div>`).join("") : `<div class="note">尚未新增流程。</div>`}</section>`;
}

function renderPerformanceExportV8(p){
  const songs = (p.songs || []).map(s=>`・${s.title || "未命名曲目"}（${s.status || "待加強"}）`).join("\n");
  const tasks = (p.tasks || []).filter(t=>!t.done).map(t=>`□ ${t.text}`).join("\n");
  const flow = (p.flow || []).map(f=>`${f.time ? f.time + " " : ""}${f.title || ""}${f.note ? "｜" + f.note : ""}`).join("\n");
  const text = `【${p.title || "演出"}】\n日期：${p.date || ""}\n地點：${p.location || ""}\n集合時間：${p.gatherTime || ""}\n服裝：${p.costume || ""}\n\n曲目：\n${songs || "尚未設定"}\n\n流程：\n${flow || "尚未設定"}\n\n注意事項：\n${p.notes || "尚無"}\n\n未完成任務：\n${tasks || "無"}`;
  return `<section class="card"><h3>📤 匯出公告 / 行政資料</h3><textarea style="min-height:360px">${escapeHtml(text)}</textarea><button class="btn primary" onclick="navigator.clipboard?.writeText(this.previousElementSibling.value); alert('已複製')">複製內容</button></section>`;
}

function render(){
  if(typeof startClassMode !== 'undefined' && startClassMode){ renderStartClassMode(); setTimeout(renderSyncStatus,0); return; }
  if(typeof quickClassMode !== "undefined" && quickClassMode){
    renderQuickClassMode();
    setTimeout(renderSyncStatus,0);
    return;
  }

  v7NormalizeState();
  safeCurrentPage();

  setTimeout(applyThemeMode,0);
  setTimeout(renderSyncStatus,0);

  const logo = document.getElementById("logoTitle");
  if(logo) logo.textContent = "🎵 " + (state.settings?.systemName || "教學管理系統");

  const title = document.getElementById("pageTitle");
  if(title) title.textContent = v7PageTitle(currentPage);

  v7SafeRender();
  setTimeout(ensureStartClassEntryButton,0);
}

/* =========================================================
   6. CLASSROOM
   ========================================================= */

function showGrowthProfile(studentId){
  const student = findById(state.students,studentId);
  if(!student) return;
  const xp = growthXpTotal(studentId);
  const level = growthLevelInfo(xp);
  const logs = allGrowthLogsForStudent(studentId);
  const topTypes = growthTopTypes(studentId,5);
  const modal = document.createElement("div");
  modal.className = "modal-backdrop";
  modal.innerHTML = `
    <div class="modal-panel">
      <button class="modal-close" onclick="this.closest('.modal-backdrop').remove()">×</button>
      <h2>🌱 ${escapeHtml(student.name)} 的成長檔案</h2>
      <div class="growth-profile-grid">
        <div class="growth-profile-card">
          <h3>冒險等級</h3>
          <div style="font-size:24px;font-weight:900">${escapeHtml(level.current.title)}｜LV${level.current.level}</div>
          <div class="note">累積 XP：${xp}<br>${level.next ? `距離 LV${level.next.level} 還需要 ${Number(level.next.xp)-xp} XP` : "已達目前最高等級"}</div>
          <div class="growth-progress"><span style="width:${level.progress}%"></span></div>
        </div>
        <div class="growth-profile-card">
          <h3>主要成長方向</h3>
          ${topTypes.map(t=>`<div class="growth-log-item"><b>${escapeHtml(t.name)}</b>｜${t.count} 次｜${t.xp} XP</div>`).join("") || `<div class="small-muted">尚無資料。</div>`}
        </div>
      </div>
      <h3>全部成長日誌</h3>
      <div style="max-height:45vh;overflow:auto">
        ${logs.map(log=>`
          <div class="growth-log-item">
            <b>${escapeHtml(growthTypeName(log.type))}</b>
            <span class="growth-xp">${Number(log.xp)||0 ? `+${Number(log.xp)||0} XP` : ""}</span><br>
            ${escapeHtml(log.feedback || "")}<br>
            <span class="small-muted">${formatDateTime(log.date)}</span>
                    <div class="log-actions">
                      <button class="btn small ghost" onclick="correctGrowthLog('${log.id}')">修正XP</button>
                      <button class="btn small danger-soft" onclick="deleteGrowthLog('${log.id}')">刪除</button>
                    </div>
          </div>
        `).join("") || `<div class="note">尚無成長日誌。</div>`}
      </div>
    </div>
  `;
  document.body.appendChild(modal);
}


function currentAdventureChapter(){
  const chapters = (state.curriculumChapters || [])
    .filter(ch => ch.active !== false)
    .slice()
    .sort((a,b)=>(Number(a.week)||0)-(Number(b.week)||0) || (Number(a.order)||0)-(Number(b.order)||0));

  if(chapters.length) {
    const dates = getClassDates(classContext.termId,classContext.classId);
    const idx = dates.indexOf(classContext.date);
    const week = idx >= 0 ? idx + 1 : 1;
    return chapters.find(ch => Number(ch.week) === week) || chapters[0];
  }

  return {
    title:"第 7 章｜節奏森林",
    week:7,
    goal:"用節奏接龍與小組挑戰建立穩定拍感。",
    tasks:["四分音符","二分音符","節奏接龍","小組挑戰"]
  };
}

function chapterTaskList(chapter){
  if(!chapter) return [];
  if(Array.isArray(chapter.tasks)) return chapter.tasks;
  return String(chapter.tasks || "").split(/[,\n，、]/).map(s=>s.trim()).filter(Boolean);
}

function renderClassroom(){
  ensureClassContext();

  const note = state.courseNotes.find(n => n.classId === classContext.classId && n.date === classContext.date && (n.termId || currentAcademicTermId(n.date)) === classContext.termId)?.content || "";
  const previousNotes = state.courseNotes
    .filter(n => n.classId === classContext.classId && n.date < classContext.date && (n.termId || currentAcademicTermId(n.date)) === classContext.termId)
    .sort((a,b)=>b.date.localeCompare(a.date))
    .slice(0,5);
  const students = studentsByClass(classContext.classId);

  document.getElementById("app").innerHTML = `
    <div class="grid">
      <section class="card col-12">
        <div class="row">
          <div class="f3">
            <label>學年 / 學期</label>
            <select onchange="classContext.termId=this.value; render()">
              ${optionList(activeTerms(),classContext.termId)}
            </select>
          </div>
          <div class="f3">
            <label>學校</label>
            <select onchange="classContext.schoolId=this.value; classContext.classId=null; render()">
              ${optionList(activeSchools(),classContext.schoolId)}
            </select>
          </div>
          <div class="f3">
            <label>課程單位</label>
            <select onchange="classContext.classId=this.value; render()">
              ${optionList(classesBySchool(classContext.schoolId),classContext.classId)}
            </select>
          </div>
          <div class="f3">
            <label>日期</label>
            <input type="date" value="${classContext.date}" onchange="classContext.date=this.value; addClassDate(classContext.termId,classContext.classId,this.value)">
          </div>
        </div>
      </section>

      <section class="card col-12">
        <div class="tabs classroom-tabs">
          <button class="${classroomTab==='rollcall'?'active':''}" onclick="classroomTab='rollcall'; render()">點名操作</button>
          <button class="${classroomTab==='attendance'?'active':''}" onclick="classroomTab='attendance'; render()">出席表</button>
          <button class="${classroomTab==='notes'?'active':''}" onclick="classroomTab='notes'; render()">課程紀錄</button>
        </div>
        <div id="classroomBody"></div>
      </section>
    </div>
  `;

  if(classroomTab === "rollcall") renderClassroomRollcall(students);
  if(classroomTab === "attendance") renderClassroomAttendanceTable(students);
  if(classroomTab === "notes") renderClassroomNotes(note, previousNotes);
}

function renderClassroomRollcall(students){
  const container = document.getElementById("classroomBody");
  if(!students.length){
    container.innerHTML = `<div class="note">這個課程目前沒有學生。請到「設定中心 → 學生設定」新增學生並勾選課程。</div>`;
    return;
  }

  container.innerHTML = `
    <section id="studentCards">
      ${students.map(student => {
        const status = attendanceStatus(student.id,classContext.classId,classContext.date);
        const point = Number(state.points[student.id] || 0);
        return `
          <article class="card student-card">
            <div class="student-head">
              ${student.photo ? `<img class="student-avatar" src="${student.photo}" alt="${escapeHtml(student.name)}">` : `<div class="student-avatar" style="display:flex;align-items:center;justify-content:center;font-size:24px">👦</div>`}
              <div>
                <div class="student-name">${escapeHtml(student.name)}</div>
                <div class="student-meta">
                  ${escapeHtml(studentLine(student,classContext.classId))}<br>
                  <span class="status-pill ${statusClass(status)}">${statusText(status)}</span>
                </div>
              </div>
            </div>

            <div class="point-box">
              <div class="star">⭐</div>
              <div class="num">${point}</div>
              <div class="label">目前點數</div>
            </div>

            <div class="actions">
              <button class="btn primary" onclick="setAttendance('${student.id}','${classContext.classId}','${classContext.date}','present')">出席 +${state.settings.attendPoint}</button>
              <button class="btn ghost" onclick="setAttendance('${student.id}','${classContext.classId}','${classContext.date}','leave')">請假</button>
              <button class="btn blue" onclick="setAttendance('${student.id}','${classContext.classId}','${classContext.date}','late')">遲到</button>
              <button class="btn red" onclick="setAttendance('${student.id}','${classContext.classId}','${classContext.date}','absent')">缺席</button>
              ${activePointActions().map(action=>`
                <button class="btn ${Number(action.amount)>=0 ? "gold" : "ghost"}" onclick='addPoints("${student.id}",${Number(action.amount)||0},${jsString(action.name)})'>${escapeHtml(action.name)}</button>
              `).join("")}
            </div>

            <details class="growth-box">
              <summary>🌱 成長日誌｜${growthLevelInfo(growthXpTotal(student.id)).current.title}｜累積 ${growthXpTotal(student.id)} XP</summary>
              <div class="note">
                冒險等級：LV${growthLevelInfo(growthXpTotal(student.id)).current.level}　
                ${growthLevelInfo(growthXpTotal(student.id)).next ? `距離 LV${growthLevelInfo(growthXpTotal(student.id)).next.level} 還需要 ${Number(growthLevelInfo(growthXpTotal(student.id)).next.xp)-growthXpTotal(student.id)} XP` : "已達目前最高冒險等級"}
                <div class="growth-progress"><span style="width:${growthLevelInfo(growthXpTotal(student.id)).progress}%"></span></div>
              </div>
              <div class="growth-quick">
                ${growthTypes().slice(0,6).map(t=>`
                  <button class="btn small ${Number(t.defaultXp)>=15 ? "gold" : "primary"}" onclick="quickGrowthLog('${student.id}','${t.id}',${Number(t.defaultXp)||10})">${escapeHtml(t.name)} +${Number(t.defaultXp)||10}</button>
                `).join("")}
              </div>
              <div class="growth-quick">
                <button class="btn small danger-soft" onclick="correctGrowthXp('${student.id}',-5,'誤按修正 -5 XP')">修正 -5</button>
                <button class="btn small danger-soft" onclick="correctGrowthXp('${student.id}',-10,'誤按修正 -10 XP')">修正 -10</button>
                <button class="btn small ghost" onclick="correctGrowthXp('${student.id}',5,'補登 +5 XP')">補登 +5</button>
              </div>
              <div class="row">
                <div class="f4">
                  <label>類型</label>
                  <select id="growthType_${student.id}">
                    ${growthTypes().map(t=>`<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("")}
                  </select>
                </div>
                <div class="f3">
                  <label>XP</label>
                  <input id="growthXp_${student.id}" type="number" value="10">
                </div>
                <div class="f12">
                  <label>回饋</label>
                  <textarea id="growthFeedback_${student.id}" placeholder="例：今天長音更穩，能保持氣息不中斷。"></textarea>
                </div>
                <div class="f12">
                  <button class="btn primary" onclick="addCustomGrowthLog('${student.id}')">新增成長日誌</button>
                </div>
              </div>
              <div><button class="btn ghost small" onclick="showGrowthProfile(\'${student.id}\')">查看完整成長檔案</button></div>
              <div>
                ${growthLogsForStudent(student.id,3).map(log=>`
                  <div class="growth-log-item">
                    <b>${escapeHtml(growthTypeName(log.type))}</b>
                    <span class="growth-xp">${Number(log.xp)||0 ? `+${Number(log.xp)||0} XP` : ""}</span><br>
                    ${escapeHtml(log.feedback || "")}<br>
                    <span class="small-muted">${formatDateTime(log.date)}</span>
                    <div class="log-actions">
                      <button class="btn small ghost" onclick="correctGrowthLog('${log.id}')">修正XP</button>
                      <button class="btn small danger-soft" onclick="deleteGrowthLog('${log.id}')">刪除</button>
                    </div>
                  </div>
                `).join("") || `<div class="small-muted">尚無成長日誌。</div>`}
              </div>
            </details>
          </article>
        `;
      }).join("")}
    </section>
  `;
}

function renderClassroomAttendanceTable(students){
  const dates = getClassDates(classContext.termId,classContext.classId);
  const presentToday = students.filter(s => attendanceStatus(s.id,classContext.classId,classContext.date) === "present").length;
  const leaveToday = students.filter(s => attendanceStatus(s.id,classContext.classId,classContext.date) === "leave").length;
  const lateToday = students.filter(s => attendanceStatus(s.id,classContext.classId,classContext.date) === "late").length;
  const absentToday = students.filter(s => attendanceStatus(s.id,classContext.classId,classContext.date) === "absent").length;
  const unsetToday = students.length - presentToday - leaveToday - lateToday - absentToday;

  document.getElementById("classroomBody").innerHTML = `
    <div class="attendance-summary">
      <span class="summary-chip">${escapeHtml(termName(classContext.termId))}</span>
      <span class="summary-chip">今日總人數 ${students.length}</span>
      <span class="summary-chip">出席 ${presentToday}</span>
      <span class="summary-chip">請假 ${leaveToday}</span>
      <span class="summary-chip">遲到 ${lateToday}</span>
      <span class="summary-chip">缺席 ${absentToday}</span>
      <span class="summary-chip">未點名 ${unsetToday}</span>
    </div>

    <div class="note">
      這裡是「整學期出席表」。先用下方產生每週上課日，也可手動新增/刪除日期。表格中的格子可直接點擊切換：尚未點名 → 出席 → 請假 → 遲到 → 缺席 → 尚未點名。
    </div>

    <div class="card" style="margin:12px 0">
      <h3>📅 點名日期</h3>
      <div class="row">
        <div class="f4"><label>起始日期</label><input id="attendanceStartDate" type="date" value="${classContext.date}"></div>
        <div class="f3"><label>週數</label><input id="attendanceWeeks" type="number" value="20"></div>
        <div class="f5">
          <button class="btn primary" onclick="generateWeeklyClassDates(classContext.termId,classContext.classId,document.getElementById('attendanceStartDate').value,document.getElementById('attendanceWeeks').value)">產生每週日期</button>
          <button class="btn ghost" onclick="addClassDate(classContext.termId,classContext.classId,classContext.date)">加入目前日期</button>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        ${dates.map(d=>`<span class="summary-chip">${escapeHtml(d)} <button class="btn red small" onclick="removeClassDate(classContext.termId,classContext.classId,'${d}')">×</button></span>`).join("") || `<span class="small-muted">尚未建立點名日期。</span>`}
      </div>
    </div>

    ${students.length && dates.length ? `
      <div style="overflow:auto;max-width:100%">
        <table class="table attendance-table attendance-grid">
          <tr>
            <th style="min-width:130px">姓名 / 出席率</th>
            ${dates.map(d=>`<th style="min-width:86px">${escapeHtml(d.slice(5))}</th>`).join("")}
          </tr>
          ${students.map(student=>{
            const presentCount = dates.filter(d => attendanceStatus(student.id,classContext.classId,d) === "present").length;
            const rate = dates.length ? Math.round(presentCount / dates.length * 100) : 0;
            return `
              <tr>
                <td>
                  <b>${escapeHtml(student.name)}</b><br>
                  <span class="small-muted">${escapeHtml(student.seat || "-")}號｜出席率 ${rate}%</span>
                </td>
                ${dates.map(d=>{
                  const status = attendanceStatus(student.id,classContext.classId,d);
                  return `<td style="text-align:center">
                    <button class="btn small ${statusClass(status)} attendance-cell" onclick="cycleAttendance('${student.id}','${classContext.classId}','${d}')">${attendanceShortText(status)}</button>
                  </td>`;
                }).join("")}
              </tr>
            `;
          }).join("")}
        </table>
      </div>
    ` : `<div class="note">請先建立日期，或確認此課程有學生。</div>`}
  `;
}

function attendanceShortText(status){
  return {present:"✓",leave:"假",late:"遲",absent:"缺"}[status] || "—";
}




/* =========================================================
   CURRICULUM MASTER TEMPLATE
   - 固定課綱母版獨立於今日課程紀錄
   - 上課介面只讀取當週內容，不直接編輯母版
   ========================================================= */

/* =========================================================
   CLEAN CORE: CURRICULUM TEMPLATE SELECTION
   - 課綱母版獨立管理
   - 課程/班級可以指定使用哪一份課綱
   - 上課介面只讀取母版，不直接改母版
   ========================================================= */
function ensureCurriculumUiState(){
  if(!state.curriculumUi) state.curriculumUi = {};
  const templates = ensureCurriculumTemplates();
  if(!state.curriculumUi.selectedTemplateId && templates[0]){
    state.curriculumUi.selectedTemplateId = templates[0].id;
  }
  return state.curriculumUi;
}

function selectedCurriculumTemplate(){
  const ui = ensureCurriculumUiState();
  const templates = ensureCurriculumTemplates();
  return templates.find(t => t.id === ui.selectedTemplateId) || templates[0];
}

function setSelectedCurriculumTemplate(templateId){
  ensureCurriculumUiState().selectedTemplateId = templateId;
  saveState();
  render();
}

function classAssignedCurriculumId(classId){
  const cls = findById(state.classes || [], classId);
  return cls?.curriculumTemplateId || "";
}

function setClassCurriculumTemplate(classId, templateId){
  const cls = findById(state.classes || [], classId);
  if(!cls) return;
  cls.curriculumTemplateId = templateId;
  saveState();
  markDirty?.("課綱指派");
  render();
}

function curriculumTemplateForCurrentClass(){
  const templates = ensureCurriculumTemplates();
  const assignedId = classAssignedCurriculumId(classContext.classId);
  return templates.find(t => t.id === assignedId) || templates[0];
}

function currentTeachingWeekNumber(){
  const dates = getClassDates(classContext.termId, classContext.classId);
  const idx = dates.indexOf(classContext.date);
  return idx >= 0 ? idx + 1 : 1;
}

function currentCurriculumWeek(){
  const template = curriculumTemplateForCurrentClass();
  const weekNo = currentTeachingWeekNumber();
  const weeks = template?.weeks || [];
  return weeks.find(w => Number(w.week) === weekNo) || weeks[weekNo-1] || weeks[0] || {week:weekNo,title:"尚未設定",goal:"",items:""};
}

function curriculumWeekItems(week){
  return String(week?.items || "").split(/\n/).map(s=>s.trim()).filter(Boolean);
}

function createCurriculumTemplate(name){
  const templates = ensureCurriculumTemplates();
  templates.push({
    id: makeId(),
    name: name || "新課綱",
    active: true,
    weeks: Array.from({length:20},(_,i)=>({
      week:i+1,
      title:`第${i+1}週`,
      goal:"",
      items:""
    }))
  });
  state.curriculumUi = state.curriculumUi || {};
  state.curriculumUi.selectedTemplateId = templates[templates.length-1].id;
  saveState();
  markDirty?.("新增課綱母版");
  render();
}

function updateCurriculumTemplateName(templateId,value){
  const t = ensureCurriculumTemplates().find(x=>x.id===templateId);
  if(!t) return;
  t.name = value;
  saveState();
  markDirty?.("修改課綱名稱");
}

function updateCurriculumWeekField(templateId,index,field,value){
  const t = ensureCurriculumTemplates().find(x=>x.id===templateId);
  if(!t) return;
  if(!Array.isArray(t.weeks)) t.weeks = [];
  if(!t.weeks[index]) t.weeks[index] = {week:index+1,title:"",goal:"",items:""};
  t.weeks[index][field] = value;
  saveState();
  markDirty?.("修改課綱內容");
}

function deleteSelectedCurriculumTemplate(){
  const selected = selectedCurriculumTemplate();
  if(!selected) return;
  if(!confirm(`確定刪除「${selected.name}」？`)) return;
  state.curriculumTemplates = ensureCurriculumTemplates().filter(t=>t.id!==selected.id);
  if(state.curriculumUi) state.curriculumUi.selectedTemplateId = state.curriculumTemplates[0]?.id || "";
  saveState();
  markDirty?.("刪除課綱母版");
  render();
}


function ensureCurriculumTemplates(){
  if(!Array.isArray(state.curriculumTemplates)){
    const seed = [
      ["認識排笛與呼吸探索","認識樂器、吹氣方向、穩定發聲。","認識排笛\n呼吸遊戲\n吹出穩定聲音"],
      ["長音與穩定氣息","建立長音與均勻氣息。","長音4拍\n長音6拍\n氣息不中斷"],
      ["節奏森林 I","建立四分音符與二分音符拍感。","四分音符\n二分音符\n節奏模仿"],
      ["音符小徑 I","建立基本音高與短句模仿。","Do Re Mi\n短句接龍\n音高模仿"],
      ["音色魔法","改善音色集中與發聲穩定。","音色集中\n避免雜音\n穩定起音"],
      ["節奏森林 II","加入節奏接龍與小組拍手。","節奏接龍\n小組拍手\n固定速度"],
      ["視譜符文 I","建立五線譜與音名連結。","音名辨認\n節奏視讀\n短句視譜"],
      ["高音之塔 I","嘗試高音區與氣息控制。","高音Sol\n高音穩定\n換氣位置"],
      ["合奏之門 I","建立二重奏與聆聽習慣。","聽同伴\n簡單二重奏\n一起收尾"],
      ["期中整理","複習前半學期能力並調整進度。","節奏複習\n音高複習\n個別檢核"],
      ["旋律小徑 II","把音高與節奏合成完整短旋律。","短旋律\n樂句呼吸\n句尾收音"],
      ["節奏森林 III","加入較複雜節奏與反應訓練。","附點概念\n節奏問答\n小組挑戰"],
      ["視譜符文 II","提升視譜反應速度。","音符閃卡\n節奏視讀\n旋律視譜"],
      ["合奏之門 II","提高合奏穩定度與配合。","進出整齊\n聲部聆聽\n速度穩定"],
      ["小曲挑戰 I","完成一首短曲或段落。","A段\n呼吸位置\n完整演奏"],
      ["小曲挑戰 II","整理音樂表情與流暢度。","樂句表情\n強弱\n速度控制"],
      ["舞台練習","建立上台流程與表演穩定度。","站姿\n開始結尾\n舞台禮儀"],
      ["總複習 I","整理本學期主要能力。","氣息\n節奏\n視譜\n合奏"],
      ["總複習 II","完成期末檢核與補強。","個別補強\n小組驗收\n成長回顧"],
      ["期末冒險紀錄","整理學生進步與下學期目標。","成長日誌\n能力回顧\n下學期目標"]
    ];
    state.curriculumTemplates = [{
      id:"cur_default_20",
      name:"三年級上學期 20 週",
      active:true,
      weeks:seed.map((row,i)=>({week:i+1,title:row[0],goal:row[1],items:row[2]}))
    }];
  }
  return state.curriculumTemplates;
}
function currentCurriculumTemplate(){
  const list = ensureCurriculumTemplates().filter(t=>t.active!==false);
  return list[0] || ensureCurriculumTemplates()[0];
}
function currentClassWeekNumber(){
  const dates = getClassDates(classContext.termId,classContext.classId);
  const idx = dates.indexOf(classContext.date);
  return idx >= 0 ? idx + 1 : 1;
}
function getCurrentCurriculumWeek(){
  const template = currentCurriculumTemplate();
  const weekNo = currentClassWeekNumber();
  const weeks = template?.weeks || [];
  return weeks.find(w=>Number(w.week)===weekNo) || weeks[weekNo-1] || weeks[0] || {week:weekNo,title:"尚未設定",goal:"",items:""};
}
function curriculumItems(week){
  return String(week?.items || "").split(/\n/).map(s=>s.trim()).filter(Boolean);
}
function addCurriculumTemplate(){
  const name = document.getElementById("newCurriculumName")?.value?.trim() || "新課綱母版";
  ensureCurriculumTemplates().push({
    id:makeId(),
    name,
    active:true,
    weeks:Array.from({length:20},(_,i)=>({week:i+1,title:`第${i+1}週`,goal:"",items:""}))
  });
  markDirty("課綱母版");
  render();
}
function updateCurriculumName(templateId,value){
  const t = ensureCurriculumTemplates().find(x=>x.id===templateId);
  if(!t) return;
  t.name = value;
  markDirty("課綱母版");
}
function updateCurriculumWeek(templateId,index,field,value){
  const t = ensureCurriculumTemplates().find(x=>x.id===templateId);
  if(!t) return;
  if(!Array.isArray(t.weeks)) t.weeks=[];
  if(!t.weeks[index]) t.weeks[index]={week:index+1,title:"",goal:"",items:""};
  t.weeks[index][field]=value;
  markDirty("課綱母版");
}
function deleteCurriculumTemplate(templateId){
  if(!confirm("確定刪除這份課綱母版？")) return;
  state.curriculumTemplates = ensureCurriculumTemplates().filter(t=>t.id!==templateId);
  markDirty("課綱母版");
  render();
}
function textWithBlankLines(value){
  return `<div class="preline">${escapeHtml(value || "")}</div>`;
}
function getEditableAdventureChapter(){
  if(!state.editableAdventureChapter){
    state.editableAdventureChapter = {
      title:"第7章｜節奏森林",
      goal:"用節奏接龍與小組挑戰建立穩定拍感。",
      tasks:"四分音符\n二分音符\n節奏接龍\n小組挑戰"
    };
  }
  return state.editableAdventureChapter;
}

function saveAdventureChapter(){
  const title = document.getElementById("chapterTitleInput")?.value || "";
  const goal = document.getElementById("chapterGoalInput")?.value || "";
  const tasks = document.getElementById("chapterTasksInput")?.value || "";

  state.editableAdventureChapter = {
    title,
    goal,
    tasks
  };

  markDirty("本週主線");
  render();

  alert("🗺️ 主線章節已儲存");
}

/* =========================================================
   CLEAN CORE: WEEKLY MAINLINE → DAILY LESSON LINK
   - 本週主線是預計上課流程
   - 今天課堂勾選實際完成項目
   - 儲存時自動整理已完成 / 未完成 / 提醒 / 回家功課
   ========================================================= */

/* =========================================================
   PHASE 2: TEACHING MODE / COPY PREVIOUS / WEEK REPORT
   ========================================================= */
function weekDateOffset(dateStr,days){
  const d = new Date(dateStr || today());
  d.setDate(d.getDate()+days);
  const y = d.getFullYear();
  const m = String(d.getMonth()+1).padStart(2,"0");
  const dd = String(d.getDate()).padStart(2,"0");
  return `${y}-${m}-${dd}`;
}

function weeklyMainlineKey(dateValue=classContext.date){
  return `${classContext.termId || currentAcademicTermId()}__${classContext.classId || ""}__${dateValue || today()}`;
}

function getWeeklyMainlineByDate(dateValue){
  if(!state.weeklyMainline) state.weeklyMainline = {};
  return state.weeklyMainline[weeklyMainlineKey(dateValue)];
}


/* LESSON MODULE: Mode Templates */
function ensureModeTemplates(){
  if(!Array.isArray(state.modeTemplates)){
    state.modeTemplates = [
      {
        id:"normal",
        name:"一般教學模式",
        title:"一般教學模式",
        goal:"依固定課綱推進，保留現場彈性。",
        sideQuest:"",
        tasks:"暖身\n本週主線\n個別檢查\n收尾回饋"
      },
      {
        id:"concert",
        name:"音樂會模式",
        title:"音樂會模式｜曲目特訓",
        goal:"以演出曲目、隊形、進出場、伴奏同步為主。",
        sideQuest:"本週因音樂會或成果發表調整課程。",
        tasks:"曲目段落練習\n進出場與隊形\n伴奏同步\n舞台禮儀\n容易出錯段落修正"
      },
      {
        id:"competition",
        name:"比賽模式",
        title:"比賽模式｜穩定度訓練",
        goal:"提升音準、節奏、穩定度與完整度。",
        sideQuest:"本週以比賽曲目精修為主。",
        tasks:"慢速精修\n音準檢查\n節奏穩定\n段落銜接\n完整演奏"
      },
      {
        id:"sightreading",
        name:"視譜加強週",
        title:"視譜加強週",
        goal:"強化音符辨識、節奏視讀與反應速度。",
        sideQuest:"",
        tasks:"音符閃卡\n節奏視讀\n旋律視譜\n分組挑戰"
      },
      {
        id:"rhythm",
        name:"節奏特訓週",
        title:"節奏特訓週",
        goal:"提升拍感、節奏穩定與小組同步。",
        sideQuest:"",
        tasks:"拍手暖身\n節奏模仿\n節奏接龍\n節拍器同步\n小組挑戰"
      }
    ];
  }
  return state.modeTemplates;
}

function teachingModeOptions(){
  return ensureModeTemplates().filter(t=>t.active !== false);
}

function addModeTemplate(){
  const name = document.getElementById("newModeTemplateName")?.value?.trim() || "新模式模板";
  ensureModeTemplates().push({
    id:makeId(),
    name,
    title:name,
    goal:"",
    sideQuest:"",
    tasks:"",
    active:true
  });
  saveState();
  markDirty?.("新增模式模板");
  render();
}

function updateModeTemplate(id,field,value){
  const t = ensureModeTemplates().find(x=>x.id===id);
  if(!t) return;
  t[field] = value;
  saveState();
  markDirty?.("修改模式模板");
}

function deleteModeTemplate(id){
  const t = ensureModeTemplates().find(x=>x.id===id);
  if(!t) return;
  if(!confirm(`確定刪除「${t.name}」？`)) return;
  state.modeTemplates = ensureModeTemplates().filter(x=>x.id!==id);
  saveState();
  markDirty?.("刪除模式模板");
  render();
}

function setTeachingMode(mode){
  const template = teachingModeOptions().find(t=>t.id===mode);
  const main = getWeeklyMainline();
  main.mode = mode;
  if(template){
    main.title = template.title || template.name || "";
    main.goal = template.goal || "";
    main.sideQuest = template.sideQuest || "";
    main.tasks = template.tasks || "";
  }
  saveState();
  markDirty?.("套用教學模式模板");
  render();
}

function clearWeeklyMainline(){
  const key = weeklyMainlineKey(classContext.date);
  if(state.weeklyMainline && state.weeklyMainline[key]){
    state.weeklyMainline[key] = {title:"",goal:"",tasks:"",sideQuest:"",mode:"normal"};
    saveState();
    markDirty?.("清空本週主線");
    render();
  }
}

function copyPreviousWeekMainline(){
  const prevDate = weekDateOffset(classContext.date,-7);
  const prev = getWeeklyMainlineByDate(prevDate);
  if(!prev) return alert("找不到上週主線。你可以先到上週日期建立主線，或直接手動輸入。");
  const current = getWeeklyMainline();
  current.title = prev.title || "";
  current.goal = prev.goal || "";
  current.tasks = prev.tasks || "";
  current.sideQuest = prev.sideQuest || "";
  current.mode = prev.mode || "normal";
  saveState();
  markDirty?.("複製上週主線");
  render();
  alert("已複製上週主線。");
}

function applyCurriculumToMainline(){
  const week = currentCurriculumWeek ? currentCurriculumWeek() : null;
  if(!week) return alert("找不到固定課綱。");
  const main = getWeeklyMainline();
  main.title = `依固定課綱｜${week.title || ""}`;
  main.goal = week.goal || "";
  main.tasks = week.items || "";
  if(!main.mode) main.mode = "normal";
  saveState();
  markDirty?.("套用固定課綱");
  render();
  alert("已套用本週固定課綱到本週主線。");
}

function notesForCurrentWeek(){
  const start = new Date(classContext.date || today());
  const day = start.getDay();
  const mondayOffset = day === 0 ? -6 : 1 - day;
  start.setDate(start.getDate()+mondayOffset);
  const dates = Array.from({length:7},(_,i)=>{
    const d = new Date(start);
    d.setDate(start.getDate()+i);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  });
  return (state.courseNotes || [])
    .filter(n=>n.classId===classContext.classId && dates.includes(n.date))
    .sort((a,b)=>String(a.date).localeCompare(String(b.date)));
}

function generateWeeklyReportText(){
  const main = getWeeklyMainline();
  const week = currentCurriculumWeek ? currentCurriculumWeek() : null;
  const notes = notesForCurrentWeek();
  const growth = (state.growthLogs || [])
    .filter(log => studentsByClass(classContext.classId).some(s=>s.id===log.studentId))
    .slice()
    .sort((a,b)=>String(b.date).localeCompare(String(a.date)))
    .slice(0,5);

  const parts = [];
  parts.push(`【本週教學摘要】`);
  parts.push(`課程：${className(classContext.classId)}`);
  parts.push(`日期：${classContext.date}`);
  parts.push(`模式：${teachingModeOptions().find(m=>m.id===(main.mode||"normal"))?.name || "一般教學模式"}`);
  parts.push("");
  parts.push(`【固定課綱】`);
  parts.push(`${week ? `第${week.week || ""}週｜${week.title || ""}` : "尚未設定"}`);
  if(week?.goal) parts.push(week.goal);
  parts.push("");
  parts.push(`【本週主線】`);
  parts.push(main.title || "尚未設定");
  if(main.goal) parts.push(main.goal);
  if(main.sideQuest) parts.push(`支線：${main.sideQuest}`);
  parts.push("");
  parts.push(`【本週課堂紀錄】`);
  parts.push(notes.length ? notes.map(n=>`${n.date}\n${n.content || ""}`).join("\n\n") : "尚無課堂紀錄。");
  parts.push("");
  parts.push(`【成長亮點】`);
  parts.push(growth.length ? growth.map(g=>`- ${findById(state.students,g.studentId)?.name || "學生"}：${g.feedback || growthTypeName(g.type)}（XP ${Number(g.xp)||0}）`).join("\n") : "尚無成長紀錄。");
  return parts.join("\n");
}


function hideWeeklyReport(){
  const old = document.getElementById("weeklyReportBox");
  if(old) old.remove();
}

function copyWeeklyReport(){
  const box = document.getElementById("weeklyReportText");
  if(!box) return;
  navigator.clipboard?.writeText(box.textContent || "");
  alert("週報已複製");
}

/* REPORT MODULE: Weekly Report */
function showWeeklyReport(){
  const text = generateWeeklyReportText();
  const target = document.getElementById("weeklyReportTarget");
  if(!target){
    alert(text);
    return;
  }

  target.innerHTML = `
    <div id="weeklyReportBox" class="week-report">
      <div class="week-report-toolbar">
        <button class="btn" onclick="copyWeeklyReport()">複製週報</button>
        <button class="btn red" onclick="hideWeeklyReport()">收起週報</button>
      </div>
      <div id="weeklyReportText">${escapeHtml(text)}</div>
    </div>
  `;
}

function weekdayName(dateStr){
  const d = new Date(dateStr);
  return ["日","一","二","三","四","五","六"][d.getDay()];
}

function csvEscape(value){
  return `"${String(value ?? "").replace(/"/g,'""')}"`;
}

/* REPORT MODULE: Export Course CSV */
function exportCourseContentCsv(){
  const notes = (state.courseNotes || [])
    .filter(n => n.classId === classContext.classId && (n.termId || currentAcademicTermId(n.date)) === (classContext.termId || currentAcademicTermId()))
    .sort((a,b)=>String(a.date).localeCompare(String(b.date)));

  if(!notes.length) return alert("目前這個課程／學期沒有課程紀錄可匯出。");

  const rows = [["日期（月/日）","星期","第幾週（堂）","課程內容","簽名欄"]];
  notes.forEach((n,idx)=>{
    const d = new Date(n.date);
    const md = `${d.getMonth()+1}/${d.getDate()}`;
    rows.push([
      md,
      `星期${weekdayName(n.date)}`,
      `第${idx+1}堂`,
      n.content || "",
      ""
    ]);
  });

  const csv = "\ufeff" + rows.map(row=>row.map(csvEscape).join(",")).join("\n");
  const blob = new Blob([csv],{type:"text/csv;charset=utf-8"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${className(classContext.classId)}_課程內容_${localIsoLikeString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

function getWeeklyMainline(){
  if(!state.weeklyMainline) state.weeklyMainline = {};
  const key = weeklyMainlineKey(classContext.date);
  if(!state.weeklyMainline[key]){
    state.weeklyMainline[key] = {title:"",goal:"",tasks:"",sideQuest:"",mode:"normal"};
  }
  return state.weeklyMainline[key];
}

function saveWeeklyMainline(){
  const main = getWeeklyMainline();
  main.title = document.getElementById("weeklyMainTitleInput")?.value || "";
  main.goal = document.getElementById("weeklyMainGoalInput")?.value || "";
  main.tasks = document.getElementById("weeklyMainTasksInput")?.value || "";
  main.sideQuest = document.getElementById("weeklyMainSideQuestInput")?.value || "";
  saveState();
  markDirty?.("本週主線");
  render();
  alert("本週主線已儲存，今天課堂會同步更新勾選清單。");
}

function weeklyMainTasks(){
  const main = getWeeklyMainline();
  return String(main.tasks || "").split(/\n/).map(s=>s.trim()).filter(Boolean);
}

function collectLessonTaskSummary(){
  const tasks = weeklyMainTasks();
  const done = [];
  const undone = [];
  tasks.forEach((task,idx)=>{
    const checked = document.getElementById(`lessonTask_${idx}`)?.checked;
    (checked ? done : undone).push(task);
  });
  return {done,undone};
}

function buildLinkedCourseNote(){
  const tags = document.getElementById("classTagsInput")?.value?.trim() || "";
  const reminder = document.getElementById("lessonReminderInput")?.value?.trim() || "";
  const homework = document.getElementById("lessonHomeworkInput")?.value?.trim() || "";
  const note = document.getElementById("courseNoteInput")?.value?.trim() || "";
  const summary = collectLessonTaskSummary();

  const sections = [];
  if(summary.done.length){
    sections.push("【已完成】\n" + summary.done.map(x=>"✓ "+x).join("\n"));
  }
  if(summary.undone.length){
    sections.push("【未完成】\n" + summary.undone.map(x=>"□ "+x).join("\n"));
  }
  if(tags) sections.push("【教學標籤】\n" + tags);
  if(reminder) sections.push("【提醒事項】\n" + reminder);
  if(homework) sections.push("【回家功課】\n" + homework);
  if(note) sections.push("【今日課堂】\n" + note);

  return sections.join("\n\n");
}

/* LESSON MODULE: Save Linked Course Note */
function saveLinkedCourseNote(){
  if(!classContext.classId) return alert("請先選擇課程單位。");
  if(!classContext.date) classContext.date = today();
  if(!classContext.termId) classContext.termId = currentAcademicTermId();

  const content = buildLinkedCourseNote();
  const existingIndex = (state.courseNotes || []).findIndex(n =>
    n.classId === classContext.classId &&
    n.date === classContext.date &&
    (n.termId || currentAcademicTermId(n.date)) === classContext.termId
  );

  if(!content.trim()){
    if(existingIndex >= 0){
      state.courseNotes.splice(existingIndex,1);
      saveUnfinishedTasksForToday([],[]);
      saveState();
      markDirty?.("清空課程紀錄");
      render();
      alert("今日課程紀錄已清空。");
    }else{
      alert("目前沒有可儲存的內容。");
    }
    return;
  }

  const taskSummary = collectLessonTaskSummary();
  saveUnfinishedTasksForToday(taskSummary.done, taskSummary.undone);

  saveCourseNote(classContext.classId,classContext.date,content,classContext.termId);
  recordActivity("course-note", `儲存課程紀錄：${className(classContext.classId)} ${classContext.date}`, {
    classId:classContext.classId,
    date:classContext.date,
    termId:classContext.termId
  });
  markDirty?.("課程紀錄");
  render();
  alert("課程紀錄已儲存，已自動整理完成與未完成項目。");
}




/* LESSON MODULE: Classroom Dashboard */
function renderClassroomNotes(note, previousNotes){
  const curriculumTemplate = curriculumTemplateForCurrentClass ? curriculumTemplateForCurrentClass() : null;
  const curriculumWeek = currentCurriculumWeek ? currentCurriculumWeek() : {week:1,title:"尚未設定",goal:"",items:""};
  const curriculumItems = curriculumWeekItems ? curriculumWeekItems(curriculumWeek) : [];
  const teachingWeekNo = currentTeachingWeekNumber ? currentTeachingWeekNumber() : 1;

  const main = getWeeklyMainline();
  const tasks = weeklyMainTasks();

  const classStudentIds = new Set(studentsByClass(classContext.classId).map(s => s.id));
  const sameClassGrowth = (state.growthLogs || []).filter(log => classStudentIds.has(log.studentId));

  const todayGrowth = sameClassGrowth
    .filter(log => String(log.date || "").slice(0,10) === classContext.date)
    .slice()
    .sort((a,b)=>String(b.date).localeCompare(String(a.date)))
    .slice(0,6);

  const recentGrowth = todayGrowth.length ? todayGrowth : sameClassGrowth
    .slice()
    .sort((a,b)=>String(b.date).localeCompare(String(a.date)))
    .slice(0,6);

  document.getElementById("classroomBody").innerHTML = `
    <div class="adventure-board">

      <!-- 左上：本週主線 -->
      <section class="story-card">
        <h3>🗺️ 左上（本週主線）</h3>
        <div class="note">這裡寫「這週打算怎麼上」。任務會同步到右上「今天課堂」變成勾選清單。</div>
        <div class="mode-pill-row">
          ${teachingModeOptions().map(m=>`<button class="mode-pill ${(main.mode||"normal")===m.id?'active':''}" onclick="setTeachingMode('${m.id}')">${m.name}</button>`).join("")}
        </div>
        <div class="row">
          <div class="f4"><button class="btn" onclick="copyPreviousWeekMainline()">一鍵複製上週</button></div>
          <div class="f4"><button class="btn" onclick="applyCurriculumToMainline()">套用固定課綱</button></div>
          <div class="f4"><button class="btn red" onclick="clearWeeklyMainline()">清空本週主線</button></div>
        </div>

        <div class="story-title">${escapeHtml(main.title || "本週主線")}</div>
        <div class="note">
          <b>本週目標</b><br>
          ${escapeHtml(main.goal || "尚未設定")}
        </div>

        ${main.sideQuest ? `
          <div class="note">
            <b>🎵 支線 / 臨時任務</b><br>
            ${formatMultiline ? formatMultiline(main.sideQuest) : escapeHtml(main.sideQuest)}
          </div>
        ` : ""}

        ${tasks.length ? tasks.map(t=>`<div class="story-task">□ ${escapeHtml(t)}</div>`).join("") : `<div class="story-task">尚未設定任務。</div>`}

        <div class="chapter-editor">
          <b>✏️ 編輯本週主線</b>
          <input id="weeklyMainTitleInput" placeholder="例如：節奏森林第二層 / 音樂會特訓週" value="${escapeHtml(main.title || "")}">
          <textarea id="weeklyMainGoalInput" placeholder="本週目標">${escapeHtml(main.goal || "")}</textarea>
          <textarea id="weeklyMainSideQuestInput" placeholder="支線 / 臨時任務：例如本週因音樂會改練《天空之城》。">${escapeHtml(main.sideQuest || "")}</textarea>
          <textarea id="weeklyMainTasksInput" placeholder="一行一個任務，會同步到今天課堂勾選">${escapeHtml(main.tasks || "")}</textarea>
          <button class="btn primary" onclick="saveWeeklyMainline()">儲存本週主線</button>
        </div>
      </section>

      <!-- 右上：今天課堂 -->
      <section class="story-card">
        <h3>📒 右上（今天課堂）</h3>
        <div class="note">上課時勾選實際完成項目，儲存後系統會自動整理「已完成 / 未完成」。</div>${renderUnfinishedReminder()}

        <div class="lesson-checklist">
          ${tasks.length ? tasks.map((task,idx)=>`
            <label class="lesson-check-item">
              <input type="checkbox" id="lessonTask_${idx}">
              <span>${escapeHtml(task)}</span>
            </label>
          `).join("") : `<div class="note">左上「本週主線」尚未設定任務。</div>`}
        </div>

        <input id="classTagsInput" placeholder="#節奏 #音準 #呼吸 #合奏">

        <textarea id="lessonReminderInput" placeholder="提醒事項：&#10;例如：下次先檢查高音Sol、某某學生要補看指法。"></textarea>

        <textarea id="lessonHomeworkInput" placeholder="回家功課：&#10;例如：長音4拍每天3次、練習第8小節到第16小節。"></textarea>

        <textarea id="courseNoteInput" placeholder="今日課堂補充：&#10;例如：學生對節奏接龍反應很好，但小組同步還不穩。">${escapeHtml(note || "")}</textarea>

        <button class="btn primary" onclick="saveLinkedCourseNote()">儲存今日課程紀錄</button>
        <button class="btn gold" onclick="showWeeklyReport()">生成本週週報</button>
        <button class="btn" onclick="exportCourseContentCsv()">匯出課程內容 CSV</button>
        <div id="weeklyReportTarget"></div>

        <div class="note recent-scroll" style="margin-top:16px;">
          <b>最近課堂回顧</b><br><br>
          ${previousNotes.length ? previousNotes.slice(0,2).map(n=>`
            <div style="margin-bottom:12px;">
              <b>${escapeHtml(n.date)}</b><br>
              ${formatMultiline ? formatMultiline(n.content || "") : escapeHtml(n.content || "")}
            </div>
          `).join("") : "尚無前次紀錄。"}
        </div>
      </section>

      <!-- 左下：固定課綱 -->
      <section class="story-card">
        <h3>📚 左下（固定課綱）</h3>
        <div class="story-progress">${escapeHtml(curriculumTemplate?.name || "課綱母版")}｜第 ${teachingWeekNo} 週</div>
        <div class="story-title">第 ${Number(curriculumWeek.week)||teachingWeekNo} 週｜${escapeHtml(curriculumWeek.title || "尚未設定")}</div>
        <div class="note">
          <b>本週課綱目標</b><br>
          ${escapeHtml(curriculumWeek.goal || "尚未設定")}
        </div>

        ${curriculumItems.length ? curriculumItems.map(item=>`
          <div class="story-task">□ ${escapeHtml(item)}</div>
        `).join("") : `<div class="note">這一週尚未設定課綱內容。請到「設定中心 → 課綱母版」編輯。</div>`}

        <div class="small-muted" style="margin-top:auto;">
          固定課綱請到「設定中心 → 課綱母版」編輯；課程使用哪份課綱，請到「設定中心 → 課程」指定。
        </div>
      </section>

      <!-- 右下：成長亮點 -->
      <section class="story-card">
        <h3>🌱 右下（成長亮點）</h3>
        <div class="small-muted" style="margin-bottom:10px;">只顯示目前班級學生；優先顯示今天的紀錄。</div>
        <div class="recent-scroll">
          ${recentGrowth.length ? recentGrowth.map(log=>`
            <div class="story-growth-item">
              <b>${escapeHtml(findById(state.students,log.studentId)?.name || "學生")}</b><br>
              ${escapeHtml(log.feedback || growthTypeName(log.type))}
              <div class="story-growth-xp">${escapeHtml(growthTypeName(log.type))} XP ${Number(log.xp)>=0?"+":""}${Number(log.xp)||0}</div>
            </div>
          `).join("") : `
            <div class="note">今天還沒有成長紀錄。可以在學生卡的「成長日誌」新增 XP 與回饋。</div>
          `}
        </div>
      </section>

    </div>
  `;
}





function saveCurrentCourseNote(){
  saveTodayCourseNoteFixed();
}


function saveStateAndMarkDirty(reason="資料異動"){ saveState(); markDirty(reason); }

/* Backward-compatible aliases */
function saveTodayCourseNote(){
  saveTodayCourseNoteFixed();
}

/* =========================================================
   7. EXAM
   ========================================================= */
function renderExam(){
  ensureExamContext();

  const students = studentsByClass(examContext.classId);
  const student = findById(state.students,examContext.studentId) || students[0];
  if(student && examContext.studentId !== student.id) examContext.studentId = student.id;

  const next = student ? nextLevel(student) : null;
  const targetStage = next ? findById(state.levelStages,next.stageId) : null;
  const content = next ? levelContent(next.stageId,next.level) : {};
  const summary = student && next ? examChecklistSummary(student.id,next.stageId,next.level,content) : {total:0,checked:0,pass:false};

  document.getElementById("app").innerHTML = `
    <div class="grid">
      <section class="card col-6">
        <h3>🎓 升級考試</h3>
        <div class="note">學生從 0 級開始。這裡檢核「目標等級」能力內容；全部勾選後，才可通過升級。</div>
        <div class="row">
          <div class="f6">
            <label>學校</label>
            <select onchange="examContext.schoolId=this.value; examContext.classId=null; examContext.studentId=null; render()">
              ${optionList(activeSchools(),examContext.schoolId)}
            </select>
          </div>
          <div class="f6">
            <label>課程單位</label>
            <select onchange="examContext.classId=this.value; examContext.studentId=null; render()">
              ${optionList(classesBySchool(examContext.schoolId),examContext.classId)}
            </select>
          </div>
          <div class="f12">
            <label>學生</label>
            <select onchange="examContext.studentId=this.value; render()">
              ${students.map(s=>`<option value="${s.id}" ${student?.id===s.id?"selected":""}>${escapeHtml(s.name)}（${escapeHtml(s.seat || "")}號）</option>`).join("")}
            </select>
          </div>
        </div>

        ${student ? `<div class="note">
          <b>${escapeHtml(student.name)}</b><br>
          目前：${escapeHtml(displayLevelPlain(student))}<br>
          本次檢核：${next ? `${escapeHtml(targetStage?.name || "")}第${next.level}${escapeHtml(targetStage?.unit || "級")}` : "已達最高等級"}<br>
          勾選進度：${summary.checked} / ${summary.total}
        </div>` : `<div class="note">這個課程目前沒有學生。</div>`}

        <label>老師評註 / 考試紀錄</label>
        <textarea id="examComment" placeholder="例：節奏穩定，音準可再集中。"></textarea>

        <div style="margin-top:12px">
          <button class="btn primary" ${student && next && summary.pass ? "" : "disabled"} onclick="passExam('${student?.id || ""}',document.getElementById('examComment').value)">通過升級</button>
          <button class="btn" onclick="failExam('${student?.id || ""}',document.getElementById('examComment').value)">未通過</button>
          <button class="btn red" onclick="downgradeStudent('${student?.id || ""}',document.getElementById('examComment').value)">降級</button>
        </div>
        ${student && next && !summary.pass ? `<div class="small-muted" style="margin-top:8px">請先完成右側檢核項目，才能通過升級。</div>` : ""}
      </section>

      <section class="card col-6">
        <h3>📘 目標等級能力檢核</h3>
        ${student && next ? `
          <div class="note">請依照目標等級內容逐項檢核。全部完成後，左側「通過升級」按鈕才會開啟。</div>
          ${renderLevelContentChecklist(student.id,next.stageId,next.level,content)}
        ` : `<div class="note">已達最高等級或尚未選擇學生。</div>`}
      </section>

      <section class="card col-12">
        <h3>📒 考試紀錄</h3>
        ${renderExamLogs(student?.id)}
      </section>
    </div>
  `;
}

function renderLevelContentPreview(content){
  return state.levelFields
    .filter(field => field.active !== false)
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0))
    .map(field => `
      <div style="margin-bottom:12px">
        <span class="status-pill">${escapeHtml(field.name)}</span>
        <div class="note">${escapeHtml(content[field.id] || "尚未設定")}</div>
      </div>
    `).join("");
}

function renderLevelContentChecklist(studentId,stageId,level,content){
  const list = examChecklist(studentId,stageId,level);
  const fields = examRelevantFields(content);
  if(!fields.length){
    return `<div class="note">這個目標等級尚未設定任何檢核內容。請先到「設定中心 → 分級制度 → 等級內容設定」填寫。</div>`;
  }

  return fields.map(field => {
      const checked = !!list[field.id];
      return `
        <div class="exam-check-card ${checked ? "checked" : ""}">
          <label class="exam-check-label">
            <input type="checkbox" ${checked ? "checked" : ""} onchange="setExamChecklistItem('${studentId}','${stageId}',${level},'${field.id}',this.checked)">
            <span class="exam-check-content">
              <b>${escapeHtml(field.name)}</b>
              <span>${escapeHtml(content[field.id])}</span>
            </span>
          </label>
        </div>
      `;
    }).join("");
}

function renderExamLogs(studentId){
  const logs = state.examLogs
    .filter(log => !studentId || log.studentId === studentId)
    .slice()
    .reverse();

  if(!logs.length) return `<div class="note">尚無考試紀錄。</div>`;

  return `
    <table class="table">
      <tr><th>日期</th><th>學生</th><th>結果</th><th>評語</th></tr>
      ${logs.map(log=>{
        const student = findById(state.students,log.studentId);
        const text = log.type === "pass" ? "通過升級" : log.type === "down" ? "降級" : "未通過";
        return `<tr>
          <td>${escapeHtml(log.date.slice(0,10))}</td>
          <td>${escapeHtml(student?.name || "")}</td>
          <td>${text}</td>
          <td>${escapeHtml(log.comment || "")}</td>
        </tr>`;
      }).join("")}
    </table>
  `;
}


/* =========================================================
   8. REWARDS
   ========================================================= */

/* =========================================================
   REWARD MODULE V7.4
   ========================================================= */













































































/* =========================================================
   REWARD IMAGE MODULE V7.4.3
   ========================================================= */









/* =========================================================
   REWARD LOG MODULE V7.4.4
   ========================================================= */



























function renderRewardStudentFilters(){
  const students = studentsByClass(rewardContext.classId);
  return `
    <section class="card">
      <div class="row">
        <div class="f4">
          <label>學校</label>
          <select onchange="rewardContext.schoolId=this.value; rewardContext.classId=null; rewardContext.studentId=null; render()">${optionList(activeSchools(),rewardContext.schoolId)}</select>
        </div>
        <div class="f4">
          <label>課程</label>
          <select onchange="rewardContext.classId=this.value; rewardContext.studentId=null; render()">${optionList(classesBySchool(rewardContext.schoolId),rewardContext.classId)}</select>
        </div>
        <div class="f4">
          <label>學生</label>
          <select onchange="rewardContext.studentId=this.value; render()">${optionList(students,rewardContext.studentId,s=>`${s.name}（${s.seat||"-"}號）`)}</select>
        </div>
      </div>
    </section>
  `;
}

function renderRewardShop(){
  const student = findById(state.students,rewardContext.studentId);
  const points = student ? Number(state.points[student.id] || 0) : 0;
  const rewards = activeRewards();
  document.getElementById("rewardBody").innerHTML = `
    ${renderRewardStudentFilters()}
    <section class="card">
      <h3>🎁 獎品商店</h3>
      ${student ? `<div class="note"><b>${escapeHtml(student.name)}</b> 目前有 ⭐ ${points} 點</div>` : `<div class="note">請先選擇學生。</div>`}
      <div class="reward-grid">
        ${rewards.length ? rewards.map(reward => renderRewardCard(reward, student, points)).join("") : `<div class="note">尚未建立獎品，請到「獎品管理」新增。</div>`}
      </div>
    </section>
  `;
}

function renderRewardCard(reward, student, points){
  const canRedeem = student && points >= Number(reward.cost || 0) && (reward.stock === "" || reward.stock === null || typeof reward.stock === "undefined" || Number(reward.stock) > 0);
  return `
    <div class="reward-card">
      ${reward.image ? `<img class="reward-img" src="${reward.image}" alt="${escapeHtml(reward.name)}">` : `<div class="reward-img" style="display:flex;align-items:center;justify-content:center;font-size:44px">🎁</div>`}
      <div class="reward-name">${escapeHtml(reward.name)}</div>
      <div class="reward-cost">⭐ ${Number(reward.cost||0)} 點</div>
      <div class="reward-meta">庫存：${reward.stock === "" || reward.stock === null || typeof reward.stock === "undefined" ? "不限" : Number(reward.stock)}</div>
      <button class="btn ${canRedeem ? "redeem-available" : "redeem-disabled"}" ${canRedeem ? "" : "disabled"} onclick="redeemReward('${student?.id || ""}','${reward.id}')">
        ${canRedeem ? "兌換" : "不可兌換"}
      </button>
    </div>
  `;
}

function renderRewardManage(){
  document.getElementById("rewardBody").innerHTML = `
    <section class="card">
      <h3>🛍️ 獎品管理</h3>
      <div class="note">圖片會上傳到 ImgBB 雲端，系統只保存圖片網址，不再佔用瀏覽器儲存空間。</div>
      <div class="row">
        <div class="f4"><label>獎品名稱</label><input id="newRewardName" placeholder="例如：星星貼紙"></div>
        <div class="f2"><label>所需點數</label><input type="number" id="newRewardCost" value="5"></div>
        <div class="f2"><label>庫存</label><input type="number" id="newRewardStock" value="10"></div>
        <div class="f4">
          <label>獎品圖片</label>
          <input type="file" accept="image/*" onchange="handleRewardImage(this.files[0])">
          <input id="newRewardImageUrl" placeholder="或直接貼圖片網址 https://..." onchange="rewardImageDraft=this.value.trim()">
          <img id="rewardPreview" class="preview-img" style="display:none">
          <div class="small-muted" id="rewardUploadStatus"></div>
        </div>
        <div class="f12"><button class="btn primary" onclick="addReward()">新增獎品</button></div>
      </div>
    </section>
    <section class="card">
      <h3>獎品列表</h3>
      <div class="reward-grid">
        ${state.rewards.length ? state.rewards.map(reward => `
          <div class="reward-card ${reward.active===false ? "inactive-row" : ""}">
            ${reward.image ? `<img class="reward-img" src="${reward.image}" alt="${escapeHtml(reward.name)}">` : `<div class="reward-img" style="display:flex;align-items:center;justify-content:center;font-size:44px">🎁</div>`}
            <label>名稱</label><input value="${escapeHtml(reward.name)}" onchange="findById(state.rewards,'${reward.id}').name=this.value; saveState()">
            <label>點數</label><input type="number" value="${Number(reward.cost||0)}" onchange="findById(state.rewards,'${reward.id}').cost=Number(this.value); saveState()">
            <label>庫存</label><input type="number" value="${reward.stock === '' || reward.stock === null || typeof reward.stock === 'undefined' ? '' : Number(reward.stock)}" onchange="findById(state.rewards,'${reward.id}').stock=this.value===''?'':Number(this.value); saveState()">
            <label>圖片網址</label><input value="${escapeHtml(reward.image||"")}" placeholder="https://..." onchange="findById(state.rewards,'${reward.id}').image=this.value.trim(); saveState(); render()">
            <label>更換圖片</label><input type="file" accept="image/*" onchange="handleRewardImage(this.files[0],'${reward.id}')">
            <div style="margin-top:10px">
              <button class="btn ${reward.active===false?'primary':'red'} small" onclick="toggleReward('${reward.id}')">${reward.active===false ? "上架" : "下架"}</button>
              <button class="btn ghost small" onclick="removeRewardImage('${reward.id}')">移除圖片</button>
              <button class="btn red small" onclick="deleteReward('${reward.id}')">刪除獎品</button>
            </div>
          </div>
        `).join("") : `<div class="note">尚無獎品。</div>`}
      </div>
    </section>
  `;
}

function renderRewardLogs(){
  const logs = state.redeemLogs.slice().reverse();
  document.getElementById("rewardBody").innerHTML = `
    <section class="card">
      <h3>🎟️ 兌換紀錄</h3>
      ${logs.length ? `<table class="table"><tr><th>時間</th><th>學生</th><th>獎品</th><th>點數</th><th>操作</th></tr>${logs.map(log=>{
        const student = findById(state.students,log.studentId);
        const reward = findById(state.rewards,log.rewardId);
        return `<tr>
          <td>${formatDateTime(log.date)}</td>
          <td>${escapeHtml(student?.name||"")}</td>
          <td>${escapeHtml(log.rewardName || reward?.name || "")}</td>
          <td>${log.cost}</td>
          <td><button class="btn red small" onclick="undoRedeem('${log.id}')">取消兌換</button></td>
        </tr>`;
      }).join("")}</table>` : `<div class="note">尚無兌換紀錄。</div>`}
    </section>
  `;
}

function setRewardUploadStatus(text){
  const el = document.getElementById("rewardUploadStatus");
  if(el) el.textContent = text || "";
}

function resizeImageForUpload(file, maxSize=1200, quality=.82){
  return new Promise((resolve,reject)=>{
    if(!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width,img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img,0,0,canvas.width,canvas.height);
        const base64 = canvas.toDataURL("image/jpeg", quality).split(",")[1];
        resolve(base64);
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function uploadImageToImgBB(file){
  const imageBase64 = await resizeImageForUpload(file,1200,.82);
  const formData = new FormData();
  formData.append("key", IMGBB_API_KEY);
  formData.append("image", imageBase64);
  const res = await fetch("https://api.imgbb.com/1/upload", {method:"POST", body:formData});
  const data = await res.json();
  if(!data || !data.success){
    throw new Error(data?.error?.message || "ImgBB 上傳失敗");
  }
  return data.data.url;
}

async function handleRewardImage(file, rewardId=null){
  if(!file) return;
  try{
    setRewardUploadStatus("圖片上傳中...");
    const url = await uploadImageToImgBB(file);
    rewardImageDraft = url;

    const preview = document.getElementById("rewardPreview");
    if(preview){
      preview.src = url;
      preview.style.display = "block";
    }
    const urlInput = document.getElementById("newRewardImageUrl");
    if(urlInput) urlInput.value = url;

    if(rewardId){
      const reward = findById(state.rewards,rewardId);
      if(reward){
        reward.image = url;
        saveState();
      }
    }
    setRewardUploadStatus("圖片已上傳到雲端");
    if(rewardId) render();
  }catch(err){
    console.error(err);
    setRewardUploadStatus("");
    alert("圖片上傳失敗，請確認網路或改用手動貼圖片網址。");
  }
}

async function handleStudentPhoto(file, studentId=null){
  if(!file) return;
  try{
    const url = await uploadImageToImgBB(file);
    if(studentId){
      const student = findById(state.students,studentId);
      if(student){
        student.photo = url;
        saveState();
        render();
      }
    }else{
      const input = document.getElementById("newStudentPhotoUrl");
      const preview = document.getElementById("newStudentPhotoPreview");
      if(input) input.value = url;
      if(preview){
        preview.src = url;
        preview.style.display = "block";
      }
    }
  }catch(err){
    console.error(err);
    alert("學生照片上傳失敗，請確認網路或改用手動貼圖片網址。");
  }
}

function addReward(){
  const name = document.getElementById("newRewardName").value.trim();
  const cost = Number(document.getElementById("newRewardCost").value) || 0;
  const stockRaw = document.getElementById("newRewardStock").value;
  if(!name) return alert("請輸入獎品名稱");
  state.rewards.push({
    id:makeId(),
    name,
    cost,
    stock:stockRaw === "" ? "" : Number(stockRaw),
    image:(document.getElementById("newRewardImageUrl")?.value.trim() || rewardImageDraft || ""),
    active:true
  });
  rewardImageDraft = "";
  saveState();
  render();
}

function toggleReward(id){
  const reward = findById(state.rewards,id);
  if(!reward) return;
  reward.active = reward.active === false ? true : false;
  saveState();
  render();
}

function removeRewardImage(id){
  const reward = findById(state.rewards,id);
  if(!reward) return;
  reward.image = "";
  saveState();
  render();
}

function deleteReward(id){
  const reward = findById(state.rewards,id);
  if(!reward) return;
  const msg = "確定要刪除「" + reward.name + "」嗎？\n\n注意：這只會從系統刪除獎品，ImgBB 上的圖片不會自動刪除。";
  if(!confirm(msg)) return;
  state.rewards = state.rewards.filter(r => r.id !== id);
  saveState();
  render();
}

function undoRedeem(logId){
  const log = findById(state.redeemLogs,logId);
  if(!log) return alert("找不到兌換紀錄");

  const student = findById(state.students,log.studentId);
  const reward = findById(state.rewards,log.rewardId);

  if(!student) return alert("找不到學生，無法取消兌換");
  if(!confirm(`確定取消「${student.name}」兌換「${log.rewardName || reward?.name || "獎品"}」嗎？\n\n系統會還原點數與庫存。`)) return;

  const cost = Number(log.cost || 0);
  state.points[student.id] = (Number(state.points[student.id]) || 0) + cost;

  if(reward && reward.stock !== "" && reward.stock !== null && typeof reward.stock !== "undefined"){
    reward.stock = Number(reward.stock || 0) + 1;
  }

  state.redeemLogs = state.redeemLogs.filter(item => item.id !== logId);
  state.pointLogs.push({
    id:makeId(),
    studentId:student.id,
    amount:cost,
    reason:`取消兌換：${log.rewardName || reward?.name || "獎品"}`,
    date:new Date().toISOString()
  });
  recordActivity("redeem", `${student.name} 取消兌換：${log.rewardName || reward?.name || "獎品"}（+${cost}）`, {studentId:student.id,rewardId:log.rewardId,cost});

  saveState();
  render();
}

function redeemReward(studentId,rewardId){
  const student = findById(state.students,studentId);
  const reward = findById(state.rewards,rewardId);
  if(!student || !reward) return;

  const cost = Number(reward.cost || 0);
  const points = Number(state.points[studentId] || 0);

  if(points < cost) return alert("點數不足");
  if(reward.stock !== "" && reward.stock !== null && typeof reward.stock !== "undefined" && Number(reward.stock) <= 0){
    return alert("庫存不足");
  }

  if(!confirm(`確定讓 ${student.name} 兌換「${reward.name}」？`)) return;

  state.points[studentId] = points - cost;
  if(reward.stock !== "" && reward.stock !== null && typeof reward.stock !== "undefined"){
    reward.stock = Number(reward.stock) - 1;
  }

  state.redeemLogs.push({
    id:makeId(),
    studentId,
    rewardId,
    rewardName:reward.name,
    cost,
    date:new Date().toISOString()
  });

  state.pointLogs.push({
    id:makeId(),
    studentId,
    amount:-cost,
    reason:`兌換：${reward.name}`,
    date:new Date().toISOString()
  });
  recordActivity("redeem", `${student.name} 兌換：${reward.name}（-${cost}）`, {studentId,rewardId,cost});

  saveState();
  render();
}


/* =========================================================
   9. STATS / RANKINGS
   ========================================================= */
let statsTab = "points";
var statsScope = window.statsScope || "all";
var statsSchoolId = window.statsSchoolId || "";
var statsClassId = window.statsClassId || "";
var statsSchoolId = window.statsSchoolId || "";
var statsClassId = window.statsClassId || "";
function statsFilteredStudents(){
  let students = activeStudents();

  if(statsScope === "school"){
    if(!statsSchoolId) statsSchoolId = activeSchools()[0]?.id || "";
    const classIds = state.classes
      .filter(c => c.schoolId === statsSchoolId && c.active !== false)
      .map(c => c.id);
    const studentIds = new Set(state.enrollments
      .filter(e => classIds.includes(e.classId))
      .map(e => e.studentId));
    students = students.filter(s => studentIds.has(s.id));
  }

  if(statsScope === "class"){
    if(!statsClassId) statsClassId = activeClasses()[0]?.id || "";
    const studentIds = new Set(state.enrollments
      .filter(e => e.classId === statsClassId)
      .map(e => e.studentId));
    students = students.filter(s => studentIds.has(s.id));
  }

  return students;
}

function studentSchoolNames(studentId){
  const classIds = state.enrollments.filter(e => e.studentId === studentId).map(e => e.classId);
  const schoolIds = [...new Set(state.classes.filter(c => classIds.includes(c.id)).map(c => c.schoolId))];
  return schoolIds.map(id => schoolName(id)).join("、");
}

function numericLevelValue(student){
  const stage = stageOfStudent(student);
  const stageOrder = Number(stage?.order) || 0;
  return stageOrder * 100 + Number(student.level || 0);
}

function renderStats(){
  const students = statsFilteredStudents();

  const pointRows = students
    .map(s => ({student:s, points:Number(state.points[s.id] || 0)}))
    .sort((a,b) => b.points - a.points);

  const xpRows = students
    .map(s => {
      const xp = growthXpTotal(s.id);
      return {student:s, xp, level:growthLevelInfo(xp).current};
    })
    .sort((a,b) => b.xp - a.xp);

  const levelRows = students
    .map(s => ({student:s, value:numericLevelValue(s), label:levelLabel(s)}))
    .sort((a,b) => b.value - a.value);

  const attendanceRows = students
    .map(s => ({student:s, ...attendanceRateForStudent(s.id, classContext.termId || currentAcademicTermId())}))
    .sort((a,b) => b.rate - a.rate || b.present - a.present);

  const rewardRows = rewardRedeemStats();
  const logs = latestActivities(100);
  const scopeLabel = statsScope === "all" ? "全部我學生" : statsScope === "school" ? `同校：${schoolName(statsSchoolId)}` : `同班：${className(statsClassId)}`;

  document.getElementById("app").innerHTML = `
    <section class="card">
      <h3>📊 排名範圍</h3>
      <div class="row">
        <div class="f3">
          <label>排行榜範圍</label>
          <select onchange="statsScope=this.value; render()">
            <option value="all" ${statsScope==='all'?'selected':''}>全部我學生（所有學校）</option>
            <option value="school" ${statsScope==='school'?'selected':''}>同一間學校</option>
            <option value="class" ${statsScope==='class'?'selected':''}>同一班 / 課程</option>
          </select>
        </div>
        <div class="f4">
          <label>選擇學校</label>
          <select onchange="statsSchoolId=this.value; statsScope='school'; render()">
            ${optionList(activeSchools(), statsSchoolId || activeSchools()[0]?.id)}
          </select>
        </div>
        <div class="f5">
          <label>選擇班級 / 課程</label>
          <select onchange="statsClassId=this.value; statsScope='class'; render()">
            ${optionList(activeClasses(), statsClassId || activeClasses()[0]?.id)}
          </select>
        </div>
      </div>
      <div class="note">目前顯示：${escapeHtml(scopeLabel)}｜共 ${students.length} 位學生</div>
    </section>

    <div class="tabs">
      <button class="${statsTab==='points'?'active':''}" onclick="statsTab='points'; render()">點數排名</button>
      <button class="${statsTab==='xp'?'active':''}" onclick="statsTab='xp'; render()">XP 經驗值排名</button>
      <button class="${statsTab==='level'?'active':''}" onclick="statsTab='level'; render()">排笛等級排名</button>
      <button class="${statsTab==='attendance'?'active':''}" onclick="statsTab='attendance'; render()">出席率排名</button>
      <button class="${statsTab==='rewards'?'active':''}" onclick="statsTab='rewards'; render()">兌換統計</button>
      <button class="${statsTab==='logs'?'active':''}" onclick="statsTab='logs'; render()">操作紀錄</button>
    </div>

    <div class="grid">
      ${statsTab==='points' ? `
        <section class="card col-12">
          <h3>⭐ 點數排名｜${escapeHtml(scopeLabel)}</h3>
          <table class="table">
            <tr><th>排名</th><th>學生</th><th>目前點數</th><th>學校</th><th>課程</th></tr>
            ${pointRows.map((row,index)=>`
              <tr>
                <td>${index+1}</td>
                <td><b>${escapeHtml(row.student.name)}</b></td>
                <td>⭐ ${row.points}</td>
                <td>${escapeHtml(studentSchoolNames(row.student.id))}</td>
                <td>${escapeHtml(studentClassNames(row.student.id))}</td>
              </tr>
            `).join("") || `<tr><td colspan="5">目前沒有學生。</td></tr>`}
          </table>
        </section>
      ` : ""}

      ${statsTab==='xp' ? `
        <section class="card col-12">
          <h3>✨ XP 經驗值排名｜${escapeHtml(scopeLabel)}</h3>
          <table class="table">
            <tr><th>排名</th><th>學生</th><th>XP</th><th>冒險等級</th><th>主要成長</th></tr>
            ${xpRows.map((row,index)=>`
              <tr>
                <td>${index+1}</td>
                <td><b>${escapeHtml(row.student.name)}</b></td>
                <td>✨ ${row.xp}</td>
                <td>LV${Number(row.level.level)||1}｜${escapeHtml(row.level.title || "")}</td>
                <td>${growthTopTypes(row.student.id,2).map(t=>`${escapeHtml(t.name)} ${t.xp}XP`).join("、") || "尚無"}</td>
              </tr>
            `).join("") || `<tr><td colspan="5">目前沒有 XP 紀錄。</td></tr>`}
          </table>
        </section>
      ` : ""}

      ${statsTab==='level' ? `
        <section class="card col-12">
          <h3>🎵 排笛等級排名｜${escapeHtml(scopeLabel)}</h3>
          <table class="table">
            <tr><th>排名</th><th>學生</th><th>排笛等級</th><th>學校</th><th>課程</th></tr>
            ${levelRows.map((row,index)=>`
              <tr>
                <td>${index+1}</td>
                <td><b>${escapeHtml(row.student.name)}</b></td>
                <td>${escapeHtml(row.label)}</td>
                <td>${escapeHtml(studentSchoolNames(row.student.id))}</td>
                <td>${escapeHtml(studentClassNames(row.student.id))}</td>
              </tr>
            `).join("") || `<tr><td colspan="5">目前沒有學生。</td></tr>`}
          </table>
        </section>
      ` : ""}

      ${statsTab==='attendance' ? `
        <section class="card col-12">
          <h3>📅 出席率排名｜${escapeHtml(scopeLabel)}</h3>
          <table class="table">
            <tr><th>排名</th><th>學生</th><th>出席率</th><th>出席 / 已點名</th><th>課程</th></tr>
            ${attendanceRows.map((row,index)=>`
              <tr>
                <td>${index+1}</td>
                <td><b>${escapeHtml(row.student.name)}</b></td>
                <td>${row.rate}%</td>
                <td>${row.present} / ${row.total}</td>
                <td>${escapeHtml(studentClassNames(row.student.id))}</td>
              </tr>
            `).join("") || `<tr><td colspan="5">目前沒有出席資料。</td></tr>`}
          </table>
        </section>
      ` : ""}

      ${statsTab==='rewards' ? `
        <section class="card col-12">
          <h3>🎁 兌換統計</h3>
          <table class="table">
            <tr><th>獎品</th><th>兌換次數</th><th>消耗點數</th></tr>
            ${rewardRows.map(row=>`
              <tr>
                <td>${escapeHtml(row.name)}</td>
                <td>${row.count}</td>
                <td>${row.totalCost}</td>
              </tr>
            `).join("") || `<tr><td colspan="3">尚無兌換紀錄。</td></tr>`}
          </table>
        </section>
      ` : ""}

      ${statsTab==='logs' ? `
        <section class="card col-12">
          <h3>📝 最近操作紀錄</h3>
          <table class="table">
            <tr><th>時間</th><th>類型</th><th>內容</th></tr>
            ${logs.map(log=>`
              <tr>
                <td>${formatDateTime(log.date)}</td>
                <td>${escapeHtml(log.type)}</td>
                <td>${escapeHtml(log.message)}</td>
              </tr>
            `).join("")}
          </table>
        </section>
      ` : ""}
    </div>
  `;
}


function studentClassNames(studentId){
  return state.enrollments
    .filter(e=>e.studentId===studentId)
    .map(e=>className(e.classId))
    .join("、");
}

/* =========================================================
   9. HISTORY
   ========================================================= */
function renderHistory(){
  ensureHistoryContext();
  document.getElementById("app").innerHTML = `
    <div class="tabs">
      <button class="${historyTab==='points'?'active':''}" onclick="historyTab='points'; render()">點數紀錄</button>
      <button class="${historyTab==='courses'?'active':''}" onclick="historyTab='courses'; render()">課程紀錄歷史</button>
      <button class="${historyTab==='attendance'?'active':''}" onclick="historyTab='attendance'; render()">點名紀錄</button>
    </div>
    <div id="historyBody"></div>
  `;
  if(historyTab === "points") renderPointHistory();
  if(historyTab === "courses") renderCourseHistory();
  if(historyTab === "attendance") renderAttendanceHistory();
}
function renderHistoryFilters({student=true,course=true}={}){
  const students = studentsByClass(historyContext.classId);
  return `
    <section class="card">
      <div class="row">
        <div class="f4">
          <label>學校</label>
          <select onchange="historyContext.schoolId=this.value; historyContext.classId=null; historyContext.studentId=null; render()">${optionList(activeSchools(),historyContext.schoolId)}</select>
        </div>
        <div class="f4">
          <label>課程</label>
          <select onchange="historyContext.classId=this.value; historyContext.studentId=null; render()">${optionList(classesBySchool(historyContext.schoolId),historyContext.classId)}</select>
        </div>
        ${student ? `<div class="f4"><label>學生</label><select onchange="historyContext.studentId=this.value; render()">${optionList(students,historyContext.studentId,s=>`${s.name}（${s.seat||"-"}號）`)}</select></div>` : ""}
      </div>
    </section>
  `;
}
function renderPointHistory(){
  const logs = state.pointLogs
    .filter(log => !historyContext.studentId || log.studentId === historyContext.studentId)
    .slice()
    .reverse();
  document.getElementById("historyBody").innerHTML = `
    ${renderHistoryFilters({student:true})}
    <section class="card">
      <h3>⭐ 點數紀錄</h3>
      ${logs.length ? `<table class="table"><tr><th>時間</th><th>學生</th><th>變動</th><th>原因</th></tr>${logs.map(log=>{
        const s = findById(state.students,log.studentId);
        return `<tr><td>${formatDateTime(log.date)}</td><td>${escapeHtml(s?.name||"")}</td><td>${Number(log.amount)>0?"+":""}${log.amount}</td><td>${escapeHtml(log.reason||"")}</td></tr>`;
      }).join("")}</table>` : `<div class="note">尚無點數紀錄。</div>`}
    </section>
  `;
}
function renderCourseHistory(){
  const logs = state.courseNotes
    .filter(n => !historyContext.classId || n.classId === historyContext.classId)
    .slice()
    .sort((a,b)=> b.date.localeCompare(a.date));
  document.getElementById("historyBody").innerHTML = `
    ${renderHistoryFilters({student:false})}
    <section class="card">
      <h3>📚 課程紀錄歷史</h3>
      ${logs.length ? `<div class="history-list">${logs.map(n=>{
        const c = findById(state.classes,n.classId);
        return `<div class="history-item"><b>${escapeHtml(n.date)}｜${escapeHtml(schoolName(c?.schoolId))}・${escapeHtml(c?.name||"")}</b><br>${escapeHtml(n.content||"").replace(/\n/g,"<br>")}</div>`;
      }).join("")}</div>` : `<div class="note">尚無課程紀錄。</div>`}
    </section>
  `;
}
function renderAttendanceHistory(){
  const logs = state.attendance
    .filter(a => !historyContext.classId || a.classId === historyContext.classId)
    .slice()
    .sort((a,b)=> b.date.localeCompare(a.date));
  document.getElementById("historyBody").innerHTML = `
    ${renderHistoryFilters({student:false})}
    <section class="card">
      <h3>✅ 點名紀錄</h3>
      ${logs.length ? `<table class="table"><tr><th>日期</th><th>課程</th><th>學生</th><th>狀態</th></tr>${logs.map(a=>{
        const s=findById(state.students,a.studentId);
        return `<tr><td>${escapeHtml(a.date)}</td><td>${escapeHtml(className(a.classId))}</td><td>${escapeHtml(s?.name||"")}</td><td><span class="status-pill ${statusClass(a.status)}">${statusText(a.status)}</span></td></tr>`;
      }).join("")}</table>` : `<div class="note">尚無點名紀錄。</div>`}
    </section>
  `;
}

/* =========================================================
   10. SETTINGS
   ========================================================= */

function renderGuide(){
  document.getElementById("app").innerHTML = `
    <section class="card">
      <h2>📖 排笛魔法師｜系統使用與教學連結</h2>
      <div class="note">
        這套系統的核心不是單純記點數，而是把排笛學習設計成一個「持續成長的音樂冒險」。正式等級負責能力認證，XP 負責看見努力與進步，點數則保留給獎品兌換。
      </div>
    </section>

    <div class="magic-guide-grid">
      <section class="magic-card">
        <h3>🎵 排笛等級＝正式能力</h3>
        <p>升級考代表真正的演奏能力，例如音域、氣息、節奏、視譜、曲目與合奏。這套制度要保持嚴謹，不被 XP 或獎品點數干擾。</p>
      </section>
      <section class="magic-card">
        <h3>✨ XP / 魔力值＝成長歷程</h3>
        <p>XP 不拿來兌換獎品，而是累積成冒險等級與稱號。它代表努力、嘗試、幫助同學與持續練習。</p>
      </section>
      <section class="magic-card">
        <h3>💰 點數＝可消耗金幣</h3>
        <p>點數可以兌換獎品；XP 不會被花掉。這樣學生即使換了獎品，也不會覺得自己的成長被扣掉。</p>
      </section>
      <section class="magic-card">
        <h3>🌱 成長日誌＝魔法修行紀錄</h3>
        <p>老師快速記錄氣息、音色、節奏、視譜、合奏、幫助同學等進步，讓學生知道「我今天哪裡變好了」。</p>
      </section>
      <section class="magic-card">
        <h3>🛠 XP 修正原則
<div class="card">
<h3>🧭 課程紀錄進階教學法</h3>

<div class="note">
<b>1. 教學標籤系統</b><br>
建議每次課程加入教學標籤，例如：<br>
#節奏 #音準 #呼吸 #視譜 #合奏 #高音<br><br>

目的不是分類而已，而是讓老師未來能搜尋自己的教學問題與模式。
</div>

<div class="note">
<b>2. 下次追蹤</b><br>
若今天課堂有未完成內容，可以在紀錄最後加入：<br><br>

📌 下次追蹤：<br>
- 小組同步<br>
- 高音穩定度<br><br>

下次上課時可快速回想上次卡住的地方。
</div>

<div class="note">
<b>3. 教學快照（推薦）</b><br>
如果今天的課程流程很成功，可以收藏成「教學模板」。<br><br>

例如：<br>
節奏接龍課<br>
呼吸穩定課<br>
高音控制課<br><br>

久了會形成自己的教學資料庫。
</div>

<div class="note">
<b>4. 班級狀態紀錄</b><br>
可簡單記錄：<br>
- 專注度<br>
- 合作度<br>
- 疲勞度<br><br>

例如：<br>
專注度 70%<br>
合作度 90%<br><br>

能幫助老師觀察長期教學狀態。
</div>

<div class="note">
<b>5. 主線世界觀</b><br>
冒險章節不是死課綱，而是「理想主線」。<br><br>

現實課堂可能因：<br>
- 音樂會<br>
- 比賽<br>
- 學校活動<br>
而偏離進度。<br><br>

這是正常的。<br>
因此系統採用：<br><br>

🗺️ 主線章節（理想）<br>
📒 今天課堂（現實）<br>
🌱 成長亮點（學生進步）<br><br>

三層結構。
</div>

<div class="note">
<b>6. 教學劇情化</b><br>
建議不要只寫：<br>
「今天教節奏」<br><br>

而是：<br>
「突破節奏森林第二層」<br><br>

這會讓學生更有參與感，也能讓老師回頭看時像閱讀一整年的冒險故事。
</div>

</div>
</h3>
        <p>誤按時使用「修正 -5 / -10」或刪除該筆紀錄。建議只把負 XP 用於誤按修正，不用來懲罰學生。</p>
      </section>
      <section class="magic-card">
        <h3>🔥 Firebase 使用習慣</h3>
        <p>平常使用 Firebase 上傳/讀取；Google Sheet 每週備份一次即可。Firebase 是主同步，Google Sheet 是保險。</p>
      </section>
    </div>

    <section class="card">
      <h3>40 分鐘課堂流程範例</h3>
      <div class="note">
        5 分鐘｜登入冒險：點名、確認今日任務。<br>
        10 分鐘｜技能修行：長音、音色、運舌或節奏。<br>
        10 分鐘｜任務挑戰：視譜、節奏接龍、小組挑戰。<br>
        10 分鐘｜Boss 合奏：短句、二重奏或曲目段落。<br>
        5 分鐘｜成長回顧：記錄 XP、成長日誌與下次提醒。
      </div>
    </section>

    <section class="card">
      <h3>課綱與課程紀錄建議</h3>
      <div class="note">
        建議未來把課程頁升級為「左邊：理想課綱 / 冒險章節；右邊：實際課程紀錄」。這樣可以看出每個班級與理想進度的落差，進一步形成真正的教學數據。
      </div>
    </section>
  `;
}



function renderDemoGuide(){
  document.getElementById("app").innerHTML = `
    <section class="card"><h2>🧪 示範使用</h2><div class="note">這裡是操作示範，不會真的改動你的學生資料。</div></section>
    <section class="demo-card">
      <h3>示範流程：一堂 30 分鐘排笛課</h3>
      <div class="demo-flow">
        <div class="demo-step"><b>1. 課前</b><br>到「本週主線」選擇模式模板。</div>
        <div class="demo-step"><b>2. 上課中</b><br>切到「開始上課」，勾選完成項目。</div>
        <div class="demo-step"><b>3. 學生表現</b><br>使用快速 XP 記錄成長亮點。</div>
        <div class="demo-step"><b>4. 下課</b><br>儲存今日課程紀錄，系統整理完成與未完成。</div>
        <div class="demo-step"><b>5. 下次</b><br>未完成任務會自動提醒，可加入本週主線。</div>
        <div class="demo-step"><b>6. 行政</b><br>用「匯出課程內容 CSV」交課程資訊。</div>
      </div>
      <button class="btn primary" onclick="view='manual'; render()">回教學手冊</button>
    </section>`;
}
function manualMenuDescriptionHtml(){
  return `
    <section class="manual-section"><h3>🧭 左側主選單</h3>
      <p><b>上課介面：</b>本週主線、今天課堂、固定課綱、成長亮點。</p>
      <p><b>升級考試：</b>登錄學生分級與晉級結果。</p>
      <p><b>獎品兌換：</b>管理點數兌換。</p>
      <p><b>統計排行：</b>查看點數、XP、出席率、等級等資料。</p>
      <p><b>記錄查詢：</b>查詢課程紀錄與成長紀錄。</p>
      <p><b>設定中心：</b>管理學校、課程、學生、課綱母版、模式模板、備份。</p>
      <p><b>教學手冊：</b>說明系統與教學流程。</p>
    </section>
    <section class="manual-section"><h3>📒 上課介面四格</h3>
      <p><b>左上｜本週主線：</b>這週打算怎麼上，是備課計畫。</p>
      <p><b>右上｜今天課堂：</b>今天實際完成哪些，儲存後生成課程紀錄。</p>
      <p><b>左下｜固定課綱：</b>理想課綱，只顯示不直接編輯。</p>
      <p><b>右下｜成長亮點：</b>學生 XP 與成長紀錄。</p>
    </section>
    <section class="manual-section"><h3>⚙️ 設定中心</h3>
      <p><b>學校 / 課程 / 學生：</b>建立基本資料。</p>
      <p><b>課綱母版：</b>建立固定 20 週課綱。</p>
      <p><b>模式模板：</b>建立音樂會、比賽、節奏特訓等模板。</p>
      <p><b>備份：</b>Firebase 主同步、JSON 備份、Google Sheet 進階備份。</p>
    </section>
    <section class="manual-section"><h3>🎺 開始上課模式</h3><p>上課中只保留今天課堂、任務勾選、提醒事項、回家功課、快速 XP、同步。</p></section>
    <section class="manual-section"><h3>☁️ 多裝置同步</h3><p>換裝置時，先「讀取雲端」再編輯；編輯完後「上傳雲端」。</p></section>
    <button class="btn gold" onclick="renderDemoGuide()">🧪 打開示範使用</button>`;
}


/* =========================================================
   PRODUCT MANUAL MODULE
   ========================================================= */
function toggleManualAccordion(id){
  document.getElementById(id)?.classList.toggle("open");
}

function renderFloatingTopButton(){
  let btn = document.getElementById("floatingTopBtn");
  if(!btn){
    btn = document.createElement("button");
    btn.id = "floatingTopBtn";
    btn.className = "btn gold floating-top-btn";
    btn.innerHTML = "⬆️";
    btn.onclick = ()=>window.scrollTo({top:0,behavior:"smooth"});
    document.body.appendChild(btn);
  }
}

function manualAccordion(id,title,body,open=false){
  return `
    <section id="${id}" class="manual-accordion ${open?'open':''}">
      <div class="manual-head" onclick="toggleManualAccordion('${id}')">
        <span>${title}</span>
        <span>▾</span>
      </div>
      <div class="manual-body">${body}</div>
    </section>
  `;
}

function renderStandaloneDemoMode(){
  document.body.classList.remove("quick-mode");
  document.getElementById("app").innerHTML = `
    <section class="demo-banner">
      🧪 示範模式｜這裡是教學流程展示，不會影響真實資料
    </section>

    <section class="card">
      <h2>🎵 一堂排笛課示範</h2>
      <div class="note">模擬情境：三年級上學期｜30分鐘｜節奏森林主題</div>
      <button class="btn" onclick="view='manual'; render()">回教學手冊</button>
    </section>

    <div class="demo-grid">
      <section class="demo-mini">
        <h3>🗺️ 本週主線</h3>
        <div>□ 暖身呼吸</div>
        <div>□ 節奏接龍</div>
        <div>□ 高音 Sol</div>
        <div>□ 合奏練習</div>
      </section>

      <section class="demo-mini">
        <h3>📒 今天課堂</h3>
        <div>☑ 暖身呼吸</div>
        <div>☑ 節奏接龍</div>
        <div>☒ 高音 Sol</div>
        <div>☒ 合奏練習</div>
      </section>

      <section class="demo-mini">
        <h3>⚠️ 未完成追蹤</h3>
        <div>• 高音 Sol</div>
        <div>• 合奏練習</div>
        <div class="note">下次同課程會自動提醒，可一鍵加入本週主線。</div>
      </section>

      <section class="demo-mini">
        <h3>🌱 成長亮點</h3>
        <div>小恩：+10 節奏反應很好</div>
        <div>小芸：+5 主動幫助同學</div>
      </section>
    </div>

    <section class="card">
      <h3>🎺 開始上課模式示範</h3>
      <div class="demo-grid">
        <div class="demo-flow-card"><b>1. 開啟開始上課</b><br>只保留課堂、勾選、XP、同步。</div>
        <div class="demo-flow-card"><b>2. 勾選完成項目</b><br>把預計任務變成實際紀錄。</div>
        <div class="demo-flow-card"><b>3. 快速加 XP</b><br>不用跳頁即可記錄成長亮點。</div>
        <div class="demo-flow-card"><b>4. 下課同步</b><br>儲存後上傳雲端，回家先讀取再編輯。</div>
      </div>
    </section>

    <section class="card">
      <h3>☁️ 多裝置同步示範</h3>
      <div class="note">
        學校電腦編輯 → ⬆️ 上傳雲端<br>
        回家 iPad / 電腦 → ⬇️ 先讀取雲端 → 再繼續編輯<br><br>
        智慧同步會檢查雲端是否比較新，避免舊裝置覆蓋新資料。
      </div>
    </section>
  `;
  renderFloatingTopButton();
}

function productManualHtml(){
  return `
    ${manualAccordion("manual_basic","1️⃣ 基礎操作",`
      <p><b>新增學生：</b>設定中心 → 學生。</p>
      <p><b>建立學校：</b>設定中心 → 學校。</p>
      <p><b>建立課程：</b>設定中心 → 課程，並可指定課綱母版。</p>
      <p><b>同步：</b>換裝置時先「讀取雲端」，編輯完再「上傳雲端」。</p>
    `,true)}

    ${manualAccordion("manual_class","2️⃣ 上課流程",`
      <p><b>本週主線：</b>這週打算怎麼上，是備課與教學計畫。</p>
      <p><b>今天課堂：</b>今天實際完成哪些；勾選後會整理成課程紀錄。</p>
      <p><b>固定課綱：</b>理想的20週課綱，只顯示，不在上課頁直接修改。</p>
      <p><b>成長亮點：</b>學生 XP 與進步紀錄。</p>
      <p><b>未完成追蹤：</b>沒上完的任務會在下次同課程提醒。</p>
    `)}

    ${manualAccordion("manual_idea","3️⃣ 教學理念",`
      <p><b>XP：</b>不是單純獎勵，而是讓學生看見自己的成長。</p>
      <p><b>成長日誌：</b>記錄氣息、節奏、音準、合作、主動性等進步。</p>
      <p><b>內驅力：</b>透過成長感、解鎖感、回饋感，提高學習動機。</p>
      <p><b>排行榜：</b>可以看資料，但教學上建議以成長亮點為核心。</p>
    `)}

    ${manualAccordion("manual_advanced","4️⃣ 進階功能",`
      <p><b>開始上課：</b>上課中只保留今天課堂、任務勾選、XP、提醒事項、同步。</p>
      <p><b>模式模板：</b>音樂會、比賽、視譜、節奏特訓等可編輯模板。</p>
      <p><b>週報：</b>整理本週教學內容與成長亮點。</p>
      <p><b>匯出 CSV：</b>可匯出日期、星期、第幾堂、課程內容、簽名欄。</p>
    `)}

    ${manualAccordion("manual_menu","5️⃣ 左側選單用途",`
      <p><b>上課介面：</b>每天主要使用的教學指揮台。</p>
      <p><b>升級考試：</b>記錄分級、檢定、晉級。</p>
      <p><b>獎品兌換：</b>管理點數兌換。</p>
      <p><b>統計排行：</b>查看 XP、點數、出席率、等級資料。</p>
      <p><b>記錄查詢：</b>查詢課程與學生成長歷程。</p>
      <p><b>設定中心：</b>管理學校、課程、學生、課綱、模式模板、備份。</p>
      <p><b>教學手冊：</b>說明系統與教學流程。</p>
      <p><b>示範模式：</b>展示整套系統如何運作，不影響真實資料。</p>
    `)}

    ${manualAccordion("manual_sync","6️⃣ 多裝置同步",`
      <p><b>在學校：</b>編輯完按「上傳雲端」。</p>
      <p><b>回家：</b>先按「讀取雲端」，確認最新後再編輯。</p>
      <p><b>智慧同步：</b>如果雲端比本機新，系統會提醒你先下載，避免舊資料覆蓋新資料。</p>
    `)}
  `;
}

function renderSettings(){
  document.getElementById("app").innerHTML = `
    <div class="tabs">
      ${[
        ["basic","系統/點數"],
        ["schools","學校"],
        ["terms","學年/學期"],
        ["classes","課程"],
        ["students","學生"],
        ["levels","分級制度"],
        ["fields","能力欄位"],
        ["growth","成長設定"],
        ["curriculum","課綱母版"],
        ["modeTemplates","模式模板"],
        ["backup","備份"]
      ].map(([id,name])=>`<button class="${settingsTab===id ? "active" : ""}" onclick="settingsTab='${id}'; render()">${name}</button>`).join("")}
    </div>
    <div id="settingsBody"></div>
  `;

  if(settingsTab === "basic") renderBasicSettings();
  if(settingsTab === "schools") renderSchoolSettings();
  if(settingsTab === "terms") renderTermSettings();
  if(settingsTab === "classes") renderClassSettings();
  if(settingsTab === "students") renderStudentSettings();
  if(settingsTab === "levels") renderLevelSettings();
  if(settingsTab === "fields") renderFieldSettings();
  if(settingsTab === "growth") renderGrowthSettings();
  if(settingsTab === "curriculum") renderCurriculumSettings();
  if(settingsTab === "modeTemplates") renderModeTemplateSettings();
  if(settingsTab === "backup") renderBackupSettings();
}

function renderBasicSettings(){
  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>⚙️ 系統與點數規則</h3>
      <div class="row">
        <div class="f6"><label>系統名稱</label><input value="${escapeHtml(state.settings.systemName)}" onchange="state.settings.systemName=this.value; saveState(); render()"></div>
        <div class="f3"><label>出席點數</label><input type="number" value="${state.settings.attendPoint}" onchange="state.settings.attendPoint=Number(this.value); saveState()"></div>
        <div class="f3"><label>升級獎勵點數</label><input type="number" value="${state.settings.upgradeReward}" onchange="state.settings.upgradeReward=Number(this.value); saveState()"></div>
      </div>
      <hr>
      <h3>⭐ 上課介面點數按鈕</h3>
      <div class="note">這裡新增的項目，會直接出現在「上課介面」每位學生右側的快速按鈕。例如：認真練習 +2、忘記帶譜 -1、幫忙收樂器 +3。</div>
      <div class="row">
        <div class="f4"><label>按鈕名稱</label><input id="newPointActionName" placeholder="例如：認真練習"></div>
        <div class="f3"><label>點數變化</label><input id="newPointActionAmount" type="number" value="1"></div>
        <div class="f3"><label>排序</label><input id="newPointActionOrder" type="number" value="${(state.pointActions || []).length + 1}"></div>
        <div class="f2"><button class="btn primary" onclick="addPointAction()">新增項目</button></div>
      </div>
      <table class="table">
        <tr><th>名稱</th><th>點數</th><th>排序</th><th>狀態</th><th>操作</th></tr>
        ${(state.pointActions || []).sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0)).map(action=>`
          <tr class="${action.active===false?'inactive-row':''}">
            <td><input value="${escapeHtml(action.name)}" onchange="findById(state.pointActions,'${action.id}').name=this.value; saveState()"></td>
            <td><input type="number" value="${Number(action.amount)||0}" onchange="findById(state.pointActions,'${action.id}').amount=Number(this.value); saveState()"></td>
            <td><input type="number" value="${Number(action.order)||0}" onchange="findById(state.pointActions,'${action.id}').order=Number(this.value); saveState()"></td>
            <td>${action.active===false ? "停用" : "啟用"}</td>
            <td>
              <button class="btn small ${action.active===false?'primary':'ghost'}" onclick="togglePointAction('${action.id}')">${action.active===false ? "啟用" : "停用"}</button>
              <button class="btn red small" onclick="deletePointAction('${action.id}')">刪除</button>
            </td>
          </tr>
        `).join("")}
      </table>
    </section>
  `;
}

function addPointAction(){
  const name = document.getElementById("newPointActionName").value.trim();
  const amount = Number(document.getElementById("newPointActionAmount").value);
  const order = Number(document.getElementById("newPointActionOrder").value) || (state.pointActions || []).length + 1;
  if(!name) return alert("請輸入按鈕名稱");
  if(!state.pointActions) state.pointActions = [];
  state.pointActions.push({id:makeId(),name,amount,order,active:true});
  saveState();
  render();
}

function togglePointAction(id){
  const action = findById(state.pointActions,id);
  if(!action) return;
  action.active = action.active === false ? true : false;
  saveState();
  render();
}

function deletePointAction(id){
  const action = findById(state.pointActions,id);
  if(!action) return;
  if(!confirm("確定刪除「" + action.name + "」這個上課點數按鈕？")) return;
  state.pointActions = state.pointActions.filter(a => a.id !== id);
  saveState();
  render();
}

function renderSchoolSettings(){
  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>🏫 學校設定</h3>
      <div class="row">
        <div class="f9"><label>新增學校</label><input id="newSchoolName" placeholder="例如：康樂國小"></div>
        <div class="f3"><button class="btn primary" onclick="addSchool()">新增學校</button></div>
      </div>
      <hr>
      <table class="table">
        <tr><th>學校名稱</th><th>狀態</th><th>操作</th></tr>
        ${state.schools.map(s=>`
          <tr class="${s.active===false?'inactive-row':''}">
            <td><input value="${escapeHtml(s.name)}" onchange="findById(state.schools,'${s.id}').name=this.value; saveState()"></td>
            <td>${s.active===false ? "停用" : "啟用"}</td>
            <td>
              <button class="btn ${s.active===false?'primary':'ghost'} small" onclick="toggleSchool('${s.id}')">${s.active===false ? "啟用" : "停用"}</button>
              <button class="btn red small" onclick="deleteSchoolForever('${s.id}')">刪除學校</button>
            </td>
          </tr>
        `).join("")}
      </table>
    </section>
  `;
}

function addSchool(){
  const input = document.getElementById("newSchoolName");
  const name = input.value.trim();
  if(!name) return;
  state.schools.push({id:makeId(),name,active:true});
  saveState();
  render();
}
function toggleSchool(id){
  const school = findById(state.schools,id);
  if(!school) return;
  school.active = !school.active;
  saveState();
  render();
}

function deleteSchoolForever(id){
  const school = findById(state.schools,id);
  if(!school) return;
  const relatedClasses = state.classes.filter(c => c.schoolId === id);
  const hasStudents = relatedClasses.some(c => state.enrollments.some(e => e.classId === c.id));
  let msg = "確定要永久刪除「" + school.name + "」嗎？\\n\\n這會一併刪除該學校底下的課程與課程歸屬。";
  if(hasStudents){
    msg += "\\n\\n注意：已有學生加入此學校課程，刪除後學生本身與點數會保留，但會從這些課程名單移除。";
  }
  if(!confirm(msg)) return;

  const classIds = relatedClasses.map(c => c.id);
  state.schools = state.schools.filter(s => s.id !== id);
  state.classes = state.classes.filter(c => c.schoolId !== id);
  state.enrollments = state.enrollments.filter(e => !classIds.includes(e.classId));
  state.attendance = state.attendance.filter(a => !classIds.includes(a.classId));
  state.courseNotes = state.courseNotes.filter(n => !classIds.includes(n.classId));

  if(classContext.schoolId === id){ classContext.schoolId = null; classContext.classId = null; }
  if(examContext.schoolId === id){ examContext.schoolId = null; examContext.classId = null; examContext.studentId = null; }
  if(historyContext.schoolId === id){ historyContext.schoolId = null; historyContext.classId = null; historyContext.studentId = null; }
  if(rewardContext.schoolId === id){ rewardContext.schoolId = null; rewardContext.classId = null; rewardContext.studentId = null; }

  saveState();
  render();
}


function renderTermSettings(){
  const selectedSchool = window.promoteSchoolId && activeSchools().some(s=>s.id===window.promoteSchoolId)
    ? window.promoteSchoolId
    : (activeSchools()[0]?.id || "");
  window.promoteSchoolId = selectedSchool;
  const sourceClasses = classesBySchool(selectedSchool);
  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>📅 學年 / 學期設定</h3>
      <div class="note">學年/學期會用在上課介面、出席表與課程紀錄。系統會預設目前學期，也可以在這裡新增未來學期。</div>
      <div class="row">
        <div class="f3"><label>學年</label><input id="newTermYear" type="number" value="${Number(currentAcademicTermId().split("-")[0])}"></div>
        <div class="f3"><label>學期</label><select id="newTermSemester"><option value="1">上學期</option><option value="2">下學期</option></select></div>
        <div class="f4"><label>顯示名稱</label><input id="newTermName" placeholder="例如：115學年 上學期"></div>
        <div class="f2"><button class="btn primary" onclick="addAcademicTerm()">新增學期</button></div>
      </div>
      <table class="table">
        <tr><th>學期代碼</th><th>顯示名稱</th><th>狀態</th><th>操作</th></tr>
        ${(state.academicTerms || []).sort((a,b)=>a.id.localeCompare(b.id)).map(term=>`
          <tr class="${term.active===false?'inactive-row':''}">
            <td>${escapeHtml(term.id)}</td>
            <td><input value="${escapeHtml(term.name)}" onchange="findById(state.academicTerms,'${term.id}').name=this.value; saveState()"></td>
            <td>${term.active===false ? "停用" : "啟用"}</td>
            <td>
              <button class="btn ${term.active===false?'primary':'ghost'} small" onclick="toggleAcademicTerm('${term.id}')">${term.active===false ? "啟用" : "停用"}</button>
              <button class="btn red small" onclick="deleteAcademicTerm('${term.id}')">刪除</button>
            </td>
          </tr>
        `).join("")}
      </table>
    </section>

    <section class="card">
      <h3>⬆️ 新學年班級升級 / 複製工具</h3>
      <div class="note">例如把「三年級」的學生名單複製到「四年級」。這不會刪除舊資料，也不會移動點數，只是建立新課程名單。</div>
      <div class="row">
        <div class="f3"><label>來源學期</label><select id="promoteFromTerm">${optionList(activeTerms(),currentAcademicTermId())}</select></div>
        <div class="f3"><label>目標學期</label><select id="promoteToTerm">${optionList(activeTerms(),currentAcademicTermId())}</select></div>
        <div class="f3"><label>學校</label><select id="promoteSchool" onchange="window.promoteSchoolId=this.value; render()">${optionList(activeSchools(),selectedSchool)}</select></div>
        <div class="f3"><label>來源課程</label><select id="promoteFromClass">${optionList(sourceClasses,sourceClasses[0]?.id||"")}</select></div>
        <div class="f6"><label>新課程名稱</label><input id="promoteNewClassName" placeholder="例如：四年級"></div>
        <div class="f3"><label>新課程排序</label><input id="promoteNewClassOrder" type="number" value="1"></div>
        <div class="f3"><button class="btn gold" onclick="promoteClassRoster()">建立 / 複製名單</button></div>
      </div>
    </section>
  `;
}

function addAcademicTerm(){
  const year = Number(document.getElementById("newTermYear").value);
  const semester = document.getElementById("newTermSemester").value;
  const customName = document.getElementById("newTermName").value.trim();
  if(!year || !semester) return alert("請輸入學年與學期");
  const id = `${year}-${semester}`;
  if(findById(state.academicTerms,id)) return alert("這個學期已存在");
  state.academicTerms.push({id,name:customName || `${year}學年 ${semester==="1"?"上學期":"下學期"}`,active:true});
  saveState();
  render();
}
function toggleAcademicTerm(id){
  const term = findById(state.academicTerms,id);
  if(!term) return;
  term.active = term.active === false ? true : false;
  saveState();
  render();
}
function deleteAcademicTerm(id){
  if(id === currentAcademicTermId()) return alert("目前學期不建議刪除，可以改為停用。");
  if(!confirm("確定刪除這個學期選項？既有出席與課程紀錄不會被刪除，但選單不再顯示。")) return;
  state.academicTerms = state.academicTerms.filter(t => t.id !== id);
  saveState();
  render();
}
function promoteClassRoster(){
  const fromTerm = document.getElementById("promoteFromTerm").value;
  const toTerm = document.getElementById("promoteToTerm").value;
  const schoolId = document.getElementById("promoteSchool").value;
  const fromClassId = document.getElementById("promoteFromClass").value;
  const newClassName = document.getElementById("promoteNewClassName").value.trim();
  const newOrder = Number(document.getElementById("promoteNewClassOrder").value) || 1;
  if(!schoolId || !fromClassId || !newClassName) return alert("請選擇學校、來源課程，並輸入新課程名稱。");

  let targetClass = state.classes.find(c => c.schoolId === schoolId && c.name === newClassName);
  if(!targetClass){
    targetClass = {id:makeId(),schoolId,name:newClassName,order:newOrder,active:true};
    state.classes.push(targetClass);
  }

  const rosterStudentIds = state.enrollments.filter(e => e.classId === fromClassId).map(e => e.studentId);
  rosterStudentIds.forEach(studentId=>{
    if(!state.enrollments.some(e => e.studentId === studentId && e.classId === targetClass.id)){
      state.enrollments.push({studentId,classId:targetClass.id});
    }
  });

  saveState();
  alert(`已將 ${rosterStudentIds.length} 位學生複製到「${newClassName}」。\\n來源：${termName(fromTerm)}\\n目標：${termName(toTerm)}`);
  settingsTab = "classes";
  window.classSettingSchoolId = schoolId;
  render();
}

function renderClassSettings(){
  const selectedSchoolId = window.classSettingSchoolId && activeSchools().some(s=>s.id===window.classSettingSchoolId)
    ? window.classSettingSchoolId
    : (activeSchools()[0]?.id || "");
  window.classSettingSchoolId = selectedSchoolId;
  const filteredClasses = state.classes
    .filter(c => c.schoolId === selectedSchoolId)
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0));

  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>📚 課程設定</h3>
      <div class="row">
        <div class="f4">
          <label>所屬學校</label>
          <select id="newClassSchool" onchange="window.classSettingSchoolId=this.value; render()">${optionList(activeSchools(),selectedSchoolId)}</select>
        </div>
        <div class="f4"><label>課程名稱</label><input id="newClassName" placeholder="例如：三年級、排笛隊、社團課"></div>
        <div class="f2"><label>排序</label><input type="number" id="newClassOrder" value="1"></div>
        <div class="f2"><button class="btn primary" onclick="addClass()">新增課程</button></div>
      </div>
      <hr>
      <div class="note">目前顯示：${escapeHtml(schoolName(selectedSchoolId))} 的課程。下方不再重複顯示學校名稱，介面會更乾淨。</div>
      <table class="table course-clean-table">
        <tr><th>學校</th><th>課程名稱</th><th>排序</th><th>狀態</th><th>操作</th></tr>
        ${filteredClasses.map(c=>`
          <tr class="${c.active===false?'inactive-row':''}">
            <td>${escapeHtml(schoolName(c.schoolId))}</td>
            <td><input value="${escapeHtml(c.name)}" onchange="findById(state.classes,'${c.id}').name=this.value; saveState()"></td>
            <td><input type="number" value="${c.order || 1}" onchange="findById(state.classes,'${c.id}').order=Number(this.value); saveState()"></td>
            <td>${c.active===false ? "停用" : "啟用"}</td>
            <td>
              <button class="btn ${c.active===false?'primary':'ghost'} small" onclick="toggleClass('${c.id}')">${c.active===false ? "啟用" : "停用"}</button>
              <button class="btn red small" onclick="deleteClassForever('${c.id}')">刪除課程</button>
            </td>
          </tr>
        `).join("") || `<tr><td></td><td colspan="4">此學校尚無課程。</td></tr>`}
      </table>
    </section>
  `;
}

function addClass(){
  const schoolId = document.getElementById("newClassSchool").value;
  const name = document.getElementById("newClassName").value.trim();
  const order = Number(document.getElementById("newClassOrder").value) || 1;
  if(!schoolId || !name) return;
  state.classes.push({id:makeId(),schoolId,name,order,active:true});
  saveState();
  render();
}
function toggleClass(id){
  const cls = findById(state.classes,id);
  if(!cls) return;
  cls.active = !cls.active;
  saveState();
  render();
}

function deleteClassForever(id){
  const cls = findById(state.classes,id);
  if(!cls) return;
  const hasStudents = state.enrollments.some(e => e.classId === id);
  let msg = "確定要永久刪除「" + cls.name + "」嗎？\\n\\n這會刪除該課程、課程歸屬、該課程點名與課程紀錄。";
  if(hasStudents){
    msg += "\\n\\n注意：學生本身與點數會保留，但會從這個課程名單移除。";
  }
  if(!confirm(msg)) return;

  state.classes = state.classes.filter(c => c.id !== id);
  state.enrollments = state.enrollments.filter(e => e.classId !== id);
  state.attendance = state.attendance.filter(a => a.classId !== id);
  state.courseNotes = state.courseNotes.filter(n => n.classId !== id);

  if(classContext.classId === id) classContext.classId = null;
  if(examContext.classId === id){ examContext.classId = null; examContext.studentId = null; }
  if(historyContext.classId === id){ historyContext.classId = null; historyContext.studentId = null; }
  if(rewardContext.classId === id){ rewardContext.classId = null; rewardContext.studentId = null; }

  saveState();
  render();
}

function renderStudentSettings(){
  const selectedSchoolId = window.studentSettingSchoolId && activeSchools().some(s=>s.id===window.studentSettingSchoolId)
    ? window.studentSettingSchoolId
    : (activeSchools()[0]?.id || "");
  window.studentSettingSchoolId = selectedSchoolId;

  const schoolClasses = classesBySchool(selectedSchoolId);
  const selectedClassId = window.studentSettingClassId && schoolClasses.some(c=>c.id===window.studentSettingClassId)
    ? window.studentSettingClassId
    : (schoolClasses[0]?.id || "");
  window.studentSettingClassId = selectedClassId;

  const studentList = state.students.filter(s => {
    if(!selectedClassId){
      return state.enrollments.some(e => e.studentId === s.id && schoolClasses.some(c => c.id === e.classId))
        || !state.enrollments.some(e => e.studentId === s.id);
    }
    return state.enrollments.some(e => e.studentId === s.id && e.classId === selectedClassId);
  });

  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>👦 學生設定</h3>
      <div class="row">
        <div class="f3">
          <label>學校篩選</label>
          <select onchange="window.studentSettingSchoolId=this.value; window.studentSettingClassId=null; render()">
            ${optionList(activeSchools(),selectedSchoolId)}
          </select>
        </div>
        <div class="f3">
          <label>課程 / 年級篩選</label>
          <select onchange="window.studentSettingClassId=this.value; render()">
            ${optionList(schoolClasses,selectedClassId)}
          </select>
        </div>
        <div class="f6">
          <div class="note">目前只顯示「${escapeHtml(schoolName(selectedSchoolId))}｜${escapeHtml(className(selectedClassId))}」的學生，避免不同年級或課程混在一起。</div>
        </div>

        <div class="f4"><label>姓名</label><input id="newStudentName" placeholder="學生姓名"></div>
        <div class="f2"><label>座號</label><input id="newStudentSeat" placeholder="1"></div>
        <div class="f3"><label>初始階段</label><select id="newStudentStage">${optionList(stageList(),"basic")}</select></div>
        <div class="f3"><label>初始等級</label><input type="number" id="newStudentLevel" value="0"></div>
        <div class="f6">
          <label>學生照片</label>
          <input type="file" accept="image/*" onchange="handleStudentPhoto(this.files[0])">
          <input id="newStudentPhotoUrl" placeholder="或直接貼學生照片網址 https://...">
        </div>
        <div class="f3">
          <label>照片預覽</label>
          <img id="newStudentPhotoPreview" class="student-photo-preview" style="display:none">
        </div>
        <div class="f12">
          <label>所屬課程（可複選）</label>
          <div class="check-list">
            ${schoolClasses.map(c=>`
              <label class="check-chip">
                <input type="checkbox" class="newStudentClass" value="${c.id}" ${c.id===selectedClassId ? "checked" : ""}>
                ${escapeHtml(c.name)}
              </label>
            `).join("") || `<span class="small-muted">這個學校尚未建立課程，請先到「課程」設定新增。</span>`}
          </div>
        </div>
        <div class="f12"><button class="btn primary" onclick="addStudent()">新增學生</button></div>
      </div>
    </section>

    <section class="card">
      <h3>學生列表｜${escapeHtml(schoolName(selectedSchoolId))}｜${escapeHtml(className(selectedClassId))}</h3>
      <table class="table">
        <tr><th>照片</th><th>姓名</th><th>座號</th><th>目前等級</th><th>課程歸屬</th><th>點數</th><th>操作</th></tr>
        ${studentList.map(s=>`
          <tr class="${s.active===false?'inactive-row':''}">
            <td>
              ${s.photo ? `<img class="student-avatar" src="${s.photo}" alt="${escapeHtml(s.name)}">` : `<div class="student-avatar" style="display:flex;align-items:center;justify-content:center">👦</div>`}
              <input style="margin-top:6px" value="${escapeHtml(s.photo || "")}" placeholder="照片網址" onchange="findById(state.students,'${s.id}').photo=this.value.trim(); saveState(); render()">
              <input style="margin-top:6px" type="file" accept="image/*" onchange="handleStudentPhoto(this.files[0],'${s.id}')">
            </td>
            <td><input value="${escapeHtml(s.name)}" onchange="findById(state.students,'${s.id}').name=this.value; saveState()"></td>
            <td><input value="${escapeHtml(s.seat || "")}" onchange="findById(state.students,'${s.id}').seat=this.value; saveState()"></td>
            <td>${escapeHtml(levelLabel(s))}</td>
            <td class="two-line">
              <div class="check-list">
                ${schoolClasses.map(c=>`
                  <label class="check-chip">
                    <input type="checkbox" ${studentEnrolledIn(s.id,c.id) ? "checked" : ""} onchange="toggleEnrollment('${s.id}','${c.id}',this.checked)">
                    ${escapeHtml(c.name)}
                  </label>
                `).join("")}
              </div>
            </td>
            <td>⭐ ${Number(state.points[s.id] || 0)}</td>
            <td>
              <button class="btn ${s.active===false?'primary':'ghost'} small" onclick="toggleStudentActive('${s.id}')">${s.active===false ? "啟用" : "停用"}</button>
              <button class="btn red small" onclick="deleteStudent('${s.id}')">刪除</button>
            </td>
          </tr>
        `).join("") || `<tr><td colspan="7">這個課程目前沒有學生。</td></tr>`}
      </table>
    </section>
  `;
}

function addStudent(){
  const name = document.getElementById("newStudentName").value.trim();
  if(!name) return;

  const id = makeId();
  const stageId = document.getElementById("newStudentStage").value;
  const level = Number(document.getElementById("newStudentLevel").value) || 1;

  state.students.push({
    id,
    name,
    seat:document.getElementById("newStudentSeat").value.trim(),
    stageId,
    level,
    photo:(document.getElementById("newStudentPhotoUrl")?.value.trim() || ""),
    active:true
  });
  state.points[id] = 0;

  document.querySelectorAll(".newStudentClass:checked").forEach(input=>{
    state.enrollments.push({studentId:id,classId:input.value});
  });

  saveState();
  render();
}

function deleteStudent(id){
  if(!confirm("確定刪除此學生？")) return;
  state.students = state.students.filter(s=>s.id!==id);
  state.enrollments = state.enrollments.filter(e=>e.studentId!==id);
  state.attendance = state.attendance.filter(a=>a.studentId!==id);
  state.examLogs = state.examLogs.filter(l=>l.studentId!==id);
  delete state.points[id];
  saveState();
  render();
}


function migrateStudentsToZeroLevel(){
  if(!confirm("這會把所有學生目前等級 -1，最低降到 0。只適合從舊版 1級起點轉換到 0級制度時使用一次。確定執行？")) return;
  state.students.forEach(s=>{
    s.level = Math.max(0, Number(s.level || 0) - 1);
  });
  recordActivity("system","已執行 0級制度轉換：全部學生等級 -1", {});
  saveState();
  render();
}

function renderLevelSettings(){
  const firstStage = stageList()[0];
  const selectedKey = window.currentLevelEditKey || (firstStage ? `${firstStage.id}_${firstStage.start}` : "");
  document.getElementById("settingsBody").innerHTML = `
    <div class="grid">
      <section class="card col-6">
        <h3>🎯 分級階段設定</h3>
        <div class="row">
          <div class="f3"><label>名稱</label><input id="stageName" placeholder="初階"></div>
          <div class="f2"><label>起</label><input type="number" id="stageStart" value="1"></div>
          <div class="f2"><label>迄</label><input type="number" id="stageEnd" value="10"></div>
          <div class="f2"><label>單位</label><input id="stageUnit" value="級"></div>
          <div class="f3"><button class="btn primary" onclick="addStage()">新增階段</button></div>
        </div>
        <hr>
        <table class="table">
          <tr><th>名稱</th><th>起</th><th>迄</th><th>單位</th><th>排序</th></tr>
          ${allStageList().map(stage=>`
            <tr class="${stage.active===false?'inactive-row':''}">
              <td><input value="${escapeHtml(stage.name)}" onchange="findById(state.levelStages,'${stage.id}').name=this.value; saveState()"></td>
              <td><input type="number" value="${stage.start}" onchange="findById(state.levelStages,'${stage.id}').start=Number(this.value); saveState()"></td>
              <td><input type="number" value="${stage.end}" onchange="findById(state.levelStages,'${stage.id}').end=Number(this.value); saveState()"></td>
              <td><input value="${escapeHtml(stage.unit)}" onchange="findById(state.levelStages,'${stage.id}').unit=this.value; saveState()"></td>
              <td><input type="number" value="${stage.order}" onchange="findById(state.levelStages,'${stage.id}').order=Number(this.value); saveState()"></td>
            </tr>
          `).join("")}
        </table>
      </section>

      <section class="card col-6">
        <h3>📘 等級內容設定</h3>
        <label>選擇等級</label>
        <select id="levelEditorSelect" onchange="window.currentLevelEditKey=this.value; renderLevelContentEditor()">
          ${buildLevelOptions(selectedKey)}
        </select>
        <div id="levelEditorBody" style="margin-top:12px"></div>
      </section>
    </div>
  `;
  renderLevelContentEditor();
}

function addStage(){
  const name = document.getElementById("stageName").value.trim();
  if(!name) return;
  state.levelStages.push({
    id:makeId(),
    name,
    start:Number(document.getElementById("stageStart").value)||1,
    end:Number(document.getElementById("stageEnd").value)||1,
    unit:document.getElementById("stageUnit").value.trim() || "級",
    order:state.levelStages.length+1,
    active:true
  });
  saveState();
  render();
}

function buildLevelOptions(selectedKey){
  let html = "";
  stageList().forEach(stage=>{
    for(let i=Number(stage.start); i<=Number(stage.end); i++){
      const key = `${stage.id}_${i}`;
      html += `<option value="${key}" ${selectedKey === key ? "selected" : ""}>${escapeHtml(stage.name)}第${i}${escapeHtml(stage.unit || "級")}</option>`;
    }
  });
  return html;
}

function renderLevelContentEditor(){
  const select = document.getElementById("levelEditorSelect");
  const body = document.getElementById("levelEditorBody");
  if(!select || !body) return;
  const [stageId,levelRaw] = select.value.split("_");
  const level = Number(levelRaw);
  const content = levelContent(stageId,level);

  body.innerHTML = state.levelFields
    .filter(field => field.active !== false)
    .sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0))
    .map(field=>`
      <label>${escapeHtml(field.name)}</label>
      <textarea onchange="setLevelFieldContent('${stageId}',${level},'${field.id}',this.value)">${escapeHtml(content[field.id] || "")}</textarea>
    `).join("");
}

function setLevelFieldContent(stageId,level,fieldId,value){
  const key = levelKey(stageId,level);
  if(!state.levelContents[key]) state.levelContents[key] = {};
  state.levelContents[key][fieldId] = value;
  saveState();
}

function renderFieldSettings(){
  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>🧩 能力欄位設定</h3>
      <div class="note">這些欄位會出現在「分級制度 → 等級內容」和「升級考試」裡，例如能力指標、技巧重點、通過標準。</div>
      <div class="row">
        <div class="f6"><label>新增欄位名稱</label><input id="newFieldName" placeholder="例如：呼吸控制"></div>
        <div class="f3"><label>排序</label><input id="newFieldOrder" type="number" value="${state.levelFields.length+1}"></div>
        <div class="f3"><button class="btn primary" onclick="addLevelField()">新增欄位</button></div>
      </div>
      <hr>
      <table class="table">
        <tr><th>欄位名稱</th><th>排序</th><th>狀態</th><th>操作</th></tr>
        ${state.levelFields.sort((a,b)=>(Number(a.order)||0)-(Number(b.order)||0)).map(field=>`
          <tr>
            <td><input value="${escapeHtml(field.name)}" onchange="findById(state.levelFields,'${field.id}').name=this.value; saveState()"></td>
            <td><input type="number" value="${field.order}" onchange="findById(state.levelFields,'${field.id}').order=Number(this.value); saveState()"></td>
            <td>${field.active === false ? "隱藏" : "顯示"}</td>
            <td><button class="btn small" onclick="toggleLevelField('${field.id}')">${field.active === false ? "顯示" : "隱藏"}</button></td>
          </tr>
        `).join("")}
      </table>
    </section>
  `;
}

function addLevelField(){
  const name = document.getElementById("newFieldName").value.trim();
  if(!name) return;
  state.levelFields.push({
    id:makeId(),
    name,
    order:Number(document.getElementById("newFieldOrder").value)||state.levelFields.length+1,
    active:true
  });
  saveState();
  render();
}

function toggleLevelField(id){
  const field = findById(state.levelFields,id);
  if(!field) return;
  field.active = field.active === false ? true : false;
  saveState();
  render();
}




function gasUrl(){
  return (state.cloudConfig?.gasUrl || "").trim();
}
function gasUrlWithParams(params={}){
  const url = gasUrl();
  const query = new URLSearchParams(params).toString();
  return url + (url.includes("?") ? "&" : "?") + query;
}
function sleep(ms){
  return new Promise(resolve => setTimeout(resolve, ms));
}
function gasJsonp(action){
  return new Promise((resolve,reject)=>{
    const url = gasUrl();
    if(!url) return reject(new Error("請先貼上 Google Apps Script Web App URL。"));

    // 強制清除舊 JSONP script，避免 iPhone/iPad 快取或舊回呼卡住。
    document.querySelectorAll("script[data-gas-jsonp='1']").forEach(node=>{
      try{ node.remove(); }catch(e){}
    });

    const callbackName = "jsonp_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2);
    const script = document.createElement("script");
    script.id = callbackName;
    script.async = true;
    script.setAttribute("data-gas-jsonp","1");

    const timer = setTimeout(()=>{
      cleanup();
      reject(new Error("JSONP 讀取逾時：請確認 Apps Script URL、部署權限，或手機網路是否阻擋 Google Script。"));
    }, 45000);

    function cleanup(){
      clearTimeout(timer);
      try{ delete window[callbackName]; }catch(e){ window[callbackName] = undefined; }
      const el = document.getElementById(callbackName);
      if(el) el.remove();
    }

    window[callbackName] = function(response){
      cleanup();
      resolve(response);
    };

    script.onerror = function(){
      cleanup();
      reject(new Error("JSONP script 載入失敗：請確認 URL 是 /exec，且 Apps Script 部署權限為任何人。"));
    };

    // 重要：讀取一律走 GET + callback，不使用 fetch，避免 iPad/iPhone CORS/redirect 問題。
    script.src = gasUrlWithParams({
      action,
      callback: callbackName,
      t: Date.now(),
      r: Math.random().toString(36).slice(2)
    });

    document.body.appendChild(script);
  });
}

async function gasPostNoCors(action,data,version="v4.1.2"){
  const url = gasUrl();
  if(!url) throw new Error("請先貼上 Google Apps Script Web App URL。");

  const form = new FormData();
  form.append("payload", JSON.stringify({
    action,
    data,
    savedAt:localDateTimeString(),
    version
  }));

  await fetch(url,{method:"POST",mode:"no-cors",body:form});
  await sleep(1200);
  return {ok:true};
}


function buildPartitionData(){
  return {
    master:buildMasterDataSnapshot(),
    runtime:{
      points:state.points || {},
      attendance:state.attendance || [],
      pointLogs:state.pointLogs || [],
      courseNotes:state.courseNotes || [],
      examLogs:state.examLogs || [],
      redeemLogs:state.redeemLogs || [],
      growthLogs:state.growthLogs || [],
      activityLogs:state.activityLogs || [],
      classDateLists:state.classDateLists || {},
      hiddenDateLists:state.hiddenDateLists || {},
      examChecklists:state.examChecklists || {}
    }
  };
}

function applyPartitionData(payload){
  if(!payload) return;
  const master = payload.master || {};
  const runtime = payload.runtime || {};
  state = migrateState({
    ...state,
    ...master,
    points:runtime.points || state.points || {},
    attendance:runtime.attendance || [],
    pointLogs:runtime.pointLogs || [],
    courseNotes:runtime.courseNotes || [],
    examLogs:runtime.examLogs || [],
    redeemLogs:runtime.redeemLogs || [],
    growthLogs:runtime.growthLogs || [],
    activityLogs:runtime.activityLogs || [],
    classDateLists:runtime.classDateLists || {},
    hiddenDateLists:runtime.hiddenDateLists || {},
    examChecklists:runtime.examChecklists || {},
    backupMeta:state.backupMeta,
    cloudConfig:state.cloudConfig
  });
}

async function uploadPartitionedToCloud(){
  if(!gasUrl()) return alert("請先貼上 Google Apps Script Web App URL。");
  try{
    const payload = buildPartitionData();
    await gasPostNoCors("savePartitioned", payload, "v4.2");
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastPartitionUploadAt = localIsoLikeString();
    recordActivity("cloud","已送出分表資料到 Google Sheet", {});
    saveState();
    alert("已送出分表資料到 Google Sheet。這會分開存基礎資料、出席、點數、紀錄等資料。");
    render();
  }catch(err){
    console.error(err);
    alert("分表上傳失敗，請確認 app.gs 已更新到 v4.2 並重新部署。");
  }
}

async function downloadPartitionedFromCloud(){
  if(!confirm("從分表雲端讀取會覆蓋目前本機資料。系統會先自動匯出目前資料備份，確定繼續？")) return;
  exportBackup();
  try{
    const result = await gasJsonp("loadPartitioned");
    if(!result.ok) throw new Error(result.error || "讀取分表資料失敗");
    if(!result.data) return alert("雲端尚無分表資料。");
    applyPartitionData(result.data);
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastPartitionDownloadAt = localIsoLikeString();
    saveState();
    alert("已用 JSONP 從 Google Sheet 分表讀取資料。");
    render();
  }catch(err){
    console.error(err);
    alert("分表讀取失敗：" + (err.message || err));
  }
}

function buildMasterDataSnapshot(){
  return {
    settings:state.settings,
    schools:state.schools,
    classes:state.classes,
    students:state.students,
    enrollments:state.enrollments,
    rewards:state.rewards,
    pointActions:state.pointActions,
    academicTerms:state.academicTerms,
    levelStages:state.levelStages,
    levelFields:state.levelFields,
    levelContents:state.levelContents,
    growthSettings:state.growthSettings
  };
}

function applyMasterDataSnapshot(master){
  const keep = {
    points:state.points,
    attendance:state.attendance,
    pointLogs:state.pointLogs,
    courseNotes:state.courseNotes,
    examLogs:state.examLogs,
    redeemLogs:state.redeemLogs,
    activityLogs:state.activityLogs,
    backupMeta:state.backupMeta,
    cloudConfig:state.cloudConfig,
    classDateLists:state.classDateLists,
    hiddenDateLists:state.hiddenDateLists
  };

  state = migrateState({
    ...state,
    ...master,
    ...keep
  });
}

async function uploadMasterToCloud(){
  if(!gasUrl()) return alert("請先貼上 Google Apps Script Web App URL。");
  try{
    await gasPostNoCors("saveMaster", buildMasterDataSnapshot(), "v4.1.2");
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastMasterUploadAt = localIsoLikeString();
    recordActivity("cloud","已送出基礎資料到 Google Sheet", {});
    saveState();
    alert("已送出基礎資料到 Google Sheet。若資料較多，請等 2–3 秒後再讀取確認。");
    render();
  }catch(err){
    console.error(err);
    alert("上傳基礎資料失敗，請確認 Apps Script URL 與部署權限。");
  }
}

async function downloadMasterFromCloud(){
  if(!confirm("讀取雲端基礎資料會覆蓋本機的學生、課程、獎品、分級設定；但不會覆蓋出席、點數、兌換與操作紀錄。繼續前會先自動匯出本機備份。")) return;
  exportBackup();
  try{
    const result = await gasJsonp("loadMaster");
    if(!result.ok) throw new Error(result.error || "讀取基礎資料失敗");
    if(!result.data) return alert("雲端尚無基礎資料。");
    applyMasterDataSnapshot(result.data);
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastMasterDownloadAt = localIsoLikeString();
    saveState();
    alert("已用 JSONP 讀取雲端基礎資料。");
    render();
  }catch(err){
    console.error(err);
    alert("基礎資料讀取失敗：" + (err.message || err));
  }
}

async function uploadToCloud(){
  if(!gasUrl()) return alert("請先貼上 Google Apps Script Web App URL。");
  try{
    await gasPostNoCors("save", state, "v4.1.2");
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastCloudUploadAt = localIsoLikeString();
    recordActivity("cloud","已送出完整資料到 Google Sheet", {});
    saveState();
    alert("已送出完整資料到 Google Sheet。若資料很大，請等 2–3 秒後再讀取確認。");
    render();
  }catch(err){
    console.error(err);
    alert("上傳失敗，請確認 Apps Script URL 與部署權限。");
  }
}

async function downloadFromCloud(){
  if(!confirm("從 Google Sheet 讀取會覆蓋目前本機資料。系統會先自動匯出目前資料備份，確定繼續？")) return;
  exportBackup();
  try{
    const result = await gasJsonp("load");
    if(!result.ok) throw new Error(result.error || "讀取失敗");
    if(!result.data) return alert("雲端尚無完整備份資料。");
    state = migrateState(result.data);
    if(!state.backupMeta) state.backupMeta = {};
    state.backupMeta.lastCloudDownloadAt = localIsoLikeString();
    saveState();
    alert("已用 JSONP 從 Google Sheet 讀取完整資料。");
    render();
  }catch(err){
    console.error(err);
    alert("完整讀取失敗：" + (err.message || err));
  }
}



async function testCloudRead(action="load"){
  if(!gasUrl()) return alert("請先貼上 Google Apps Script Web App URL。");
  try{
    const result = await gasJsonp(action);
    if(result.ok){
      const hasData = !!result.data;
      const sheet = result.sheet || result.mode || "";
      alert(`讀取測試成功。\n類型：${action}\n資料：${hasData ? "有資料" : "尚無資料"}\n來源：${sheet}`);
    }else{
      alert("讀取測試有回應，但回傳錯誤：" + (result.error || "未知錯誤"));
    }
  }catch(err){
    console.error(err);
    alert("讀取測試失敗：" + err.message);
  }
}

async function testCloudConnection(){
  if(!gasUrl()) return alert("請先貼上 Google Apps Script Web App URL。");
  try{
    const result = await gasJsonp("ping");
    if(result.ok){
      alert(`雲端連線正常。\nAPI：${result.message || "OK"}\n試算表：${result.spreadsheetName || "未回傳名稱"}\n伺服器時間：${result.serverTime || ""}`);
    }else{
      alert("雲端有回應，但回傳錯誤：" + (result.error || "未知錯誤"));
    }
  }catch(err){
    console.error(err);
    alert("雲端測試失敗。請確認 URL、部署權限、或是否貼到正確試算表的 Apps Script。");
  }
}

function saveGasUrl(){
  const input = document.getElementById("gasUrlInput");
  if(!input) return;
  if(!state.cloudConfig) state.cloudConfig = {};
  state.cloudConfig.gasUrl = input.value.trim();
  saveState();
  alert("Google Apps Script URL 已儲存。");
}


async function smartDownloadFromCloud(){
  if(!confirm("智慧讀取會優先讀取分表資料；若分表沒有資料，會自動改讀完整備份。讀取前會先匯出本機備份。確定繼續？")) return;
  exportBackup();
  try{
    let result = await gasJsonp("loadPartitioned");
    if(result.ok && result.data){
      applyPartitionData(result.data);
      if(!state.backupMeta) state.backupMeta = {};
      state.backupMeta.lastPartitionDownloadAt = localIsoLikeString();
      saveState();
      alert("已讀取分表資料。");
      render();
      return;
    }

    result = await gasJsonp("load");
    if(result.ok && result.data){
      state = migrateState(result.data);
      if(!state.backupMeta) state.backupMeta = {};
      state.backupMeta.lastCloudDownloadAt = localIsoLikeString();
      saveState();
      alert("分表無資料，已自動改讀完整備份。");
      render();
      return;
    }

    alert("雲端目前沒有可讀取的資料。");
  }catch(err){
    console.error(err);
    alert("智慧讀取失敗：" + (err.message || err));
  }
}


function renderGrowthSettings(){
  const levels = (state.growthSettings?.xpLevels || []).slice().sort((a,b)=>(Number(a.level)||0)-(Number(b.level)||0));
  const types = allGrowthTypes();
  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>🌱 成長日誌設定</h3>
      <div class="note">這裡可以編輯「冒險等級需要多少 XP」、每級稱號，以及成長日誌的類型與快速按鈕預設值。這些不會影響正式升級考，也不能兌換獎品。</div>
    </section>

    <section class="card">
      <h3>⭐ 冒險等級 / XP 表</h3>
      <div class="row">
        <div class="f2"><label>LV</label><input id="newGrowthLevel" type="number" value="${levels.length+1}"></div>
        <div class="f3"><label>需要 XP</label><input id="newGrowthXp" type="number" value="${levels.length ? Number(levels[levels.length-1].xp)+500 : 0}"></div>
        <div class="f5"><label>稱號</label><input id="newGrowthTitle" placeholder="例如：🎵 旋律冒險家"></div>
        <div class="f2"><button class="btn primary" onclick="addGrowthLevelSetting()">新增等級</button></div>
      </div>
      <table class="table">
        <tr><th>LV</th><th>需要XP</th><th>稱號</th><th>操作</th></tr>
        ${levels.map((lv,idx)=>`
          <tr>
            <td><input type="number" value="${Number(lv.level)||1}" onchange="state.growthSettings.xpLevels[${idx}].level=Number(this.value); saveState(); render()"></td>
            <td><input type="number" value="${Number(lv.xp)||0}" onchange="state.growthSettings.xpLevels[${idx}].xp=Number(this.value); saveState(); render()"></td>
            <td><input value="${escapeHtml(lv.title || "")}" onchange="state.growthSettings.xpLevels[${idx}].title=this.value; saveState(); render()"></td>
            <td><button class="btn red small" onclick="deleteGrowthLevelSetting(${idx})">刪除</button></td>
          </tr>
        `).join("")}
      </table>
    </section>

    <section class="card">
      <h3>🧩 成長類型 / 快速按鈕</h3>
      <div class="row">
        <div class="f3"><label>名稱</label><input id="newGrowthTypeName" placeholder="例如：舞台表現"></div>
        <div class="f2"><label>預設XP</label><input id="newGrowthTypeXp" type="number" value="10"></div>
        <div class="f2"><label>排序</label><input id="newGrowthTypeOrder" type="number" value="${types.length+1}"></div>
        <div class="f5"><label>預設回饋</label><input id="newGrowthTypeFeedback" placeholder="例如：上台時更有自信。"></div>
        <div class="f12"><button class="btn primary" onclick="addGrowthTypeSetting()">新增成長類型</button></div>
      </div>
      <table class="table">
        <tr><th>名稱</th><th>預設XP</th><th>排序</th><th>狀態</th><th>預設回饋</th><th>操作</th></tr>
        ${types.map((t,idx)=>`
          <tr class="${t.active===false?'inactive-row':''}">
            <td><input value="${escapeHtml(t.name || "")}" onchange="state.growthSettings.growthTypes[${idx}].name=this.value; saveState(); render()"></td>
            <td><input type="number" value="${Number(t.defaultXp)||0}" onchange="state.growthSettings.growthTypes[${idx}].defaultXp=Number(this.value); saveState(); render()"></td>
            <td><input type="number" value="${Number(t.order)||0}" onchange="state.growthSettings.growthTypes[${idx}].order=Number(this.value); saveState(); render()"></td>
            <td>${t.active===false ? "隱藏" : "顯示"}</td>
            <td><textarea onchange="state.growthSettings.growthTypes[${idx}].defaultFeedback=this.value; saveState()">${escapeHtml(t.defaultFeedback || "")}</textarea></td>
            <td>
              <button class="btn small" onclick="toggleGrowthTypeSetting(${idx})">${t.active===false ? "顯示" : "隱藏"}</button>
              <button class="btn red small" onclick="deleteGrowthTypeSetting(${idx})">刪除</button>
            </td>
          </tr>
        `).join("")}
      </table>
    </section>
  `;
}

function addGrowthLevelSetting(){
  const level = Number(document.getElementById("newGrowthLevel").value)||1;
  const xp = Number(document.getElementById("newGrowthXp").value)||0;
  const title = document.getElementById("newGrowthTitle").value.trim() || `LV${level}`;
  state.growthSettings.xpLevels.push({level,xp,title});
  saveState();
  render();
}

function deleteGrowthLevelSetting(index){
  if(!confirm("確定刪除這個冒險等級？")) return;
  state.growthSettings.xpLevels.splice(index,1);
  saveState();
  render();
}

function addGrowthTypeSetting(){
  const name = document.getElementById("newGrowthTypeName").value.trim();
  if(!name) return alert("請輸入名稱。");
  state.growthSettings.growthTypes.push({
    id:makeId(),
    name,
    active:true,
    order:Number(document.getElementById("newGrowthTypeOrder").value)||state.growthSettings.growthTypes.length+1,
    defaultXp:Number(document.getElementById("newGrowthTypeXp").value)||10,
    defaultFeedback:document.getElementById("newGrowthTypeFeedback").value.trim() || `${name}有明顯進步。`
  });
  saveState();
  render();
}

function toggleGrowthTypeSetting(index){
  const item = state.growthSettings.growthTypes[index];
  item.active = item.active === false ? true : false;
  saveState();
  render();
}

function deleteGrowthTypeSetting(index){
  if(!confirm("確定刪除這個成長類型？已存在的舊紀錄不會刪除。")) return;
  state.growthSettings.growthTypes.splice(index,1);
  saveState();
  render();
}


function renderCurriculumSettings(){
  const templates = ensureCurriculumTemplates();
  const ui = ensureCurriculumUiState();
  const selected = selectedCurriculumTemplate();

  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>📚 課綱母版管理</h3>
      <div class="note">
        課綱母版是固定課程，例如「三年級上學期 20 週」。這裡負責建立與編輯；上課介面只讀取當週內容，不在課程紀錄頁直接修改母版。
      </div>

      <div class="row">
        <div class="f5">
          <label>選擇要編輯的課綱</label>
          <select onchange="setSelectedCurriculumTemplate(this.value)">
            ${templates.map(t=>`<option value="${t.id}" ${t.id===ui.selectedTemplateId?'selected':''}>${escapeHtml(t.name)}</option>`).join("")}
          </select>
        </div>
        <div class="f5">
          <label>新增課綱名稱</label>
          <input id="newCurriculumTemplateName" placeholder="例如：三年級下學期">
        </div>
        <div class="f2">
          <label>&nbsp;</label>
          <button class="btn primary" onclick="createCurriculumTemplate(document.getElementById('newCurriculumTemplateName').value)">新增20週課綱</button>
        </div>
      </div>
    </section>

    ${selected ? `
      <section class="card">
        <h3>📘 編輯：${escapeHtml(selected.name)}</h3>
        <div class="row">
          <div class="f8">
            <label>課綱名稱</label>
            <input value="${escapeHtml(selected.name || "")}" onchange="updateCurriculumTemplateName('${selected.id}',this.value)">
          </div>
          <div class="f4">
            <label>&nbsp;</label>
            <button class="btn red" onclick="deleteSelectedCurriculumTemplate()">刪除這份課綱</button>
          </div>
        </div>

        <div class="note">
          編輯方式：每週填「主題、目標、任務」。任務欄位一行一項，上課介面會自動顯示對應週次。
        </div>

        <div style="overflow:auto; max-height:64vh;">
          <table class="table">
            <tr>
              <th style="min-width:70px;">週次</th>
              <th style="min-width:180px;">主題</th>
              <th style="min-width:280px;">本週目標</th>
              <th style="min-width:280px;">任務 / 內容</th>
            </tr>
            ${(selected.weeks || []).map((w,idx)=>`
              <tr>
                <td>第 ${Number(w.week)||idx+1} 週</td>
                <td><input value="${escapeHtml(w.title || "")}" onchange="updateCurriculumWeekField('${selected.id}',${idx},'title',this.value)"></td>
                <td><textarea onchange="updateCurriculumWeekField('${selected.id}',${idx},'goal',this.value)">${escapeHtml(w.goal || "")}</textarea></td>
                <td><textarea placeholder="一行一項" onchange="updateCurriculumWeekField('${selected.id}',${idx},'items',this.value)">${escapeHtml(w.items || "")}</textarea></td>
              </tr>
            `).join("")}
          </table>
        </div>
      </section>
    ` : `<section class="card"><div class="note">尚未建立課綱母版。</div></section>`}
  `;
}




function renderModeTemplateSettings(){
  const templates = ensureModeTemplates();

  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>🎛️ 模式模板庫</h3>
      <div class="note">
        模式模板會套用到「本週主線」。你可以依不同學校、年級、曲目建立不同模板，例如「音樂會模式｜天空之城」、「比賽模式｜慢速精修」。
      </div>

      <div class="row">
        <div class="f9">
          <label>新增模板名稱</label>
          <input id="newModeTemplateName" placeholder="例如：音樂會模式｜天空之城">
        </div>
        <div class="f3">
          <label>&nbsp;</label>
          <button class="btn primary" onclick="addModeTemplate()">新增模板</button>
        </div>
      </div>
    </section>

    ${templates.map(t=>`
      <section class="template-card">
        <div class="row">
          <div class="f4">
            <label>按鈕名稱</label>
            <input value="${escapeHtml(t.name || "")}" onchange="updateModeTemplate('${t.id}','name',this.value)">
          </div>
          <div class="f4">
            <label>主線標題</label>
            <input value="${escapeHtml(t.title || "")}" onchange="updateModeTemplate('${t.id}','title',this.value)">
          </div>
          <div class="f4">
            <label>&nbsp;</label>
            <button class="btn red" onclick="deleteModeTemplate('${t.id}')">刪除模板</button>
          </div>
        </div>

        <label>本週目標</label>
        <textarea onchange="updateModeTemplate('${t.id}','goal',this.value)">${escapeHtml(t.goal || "")}</textarea>

        <label>支線 / 臨時任務</label>
        <textarea onchange="updateModeTemplate('${t.id}','sideQuest',this.value)">${escapeHtml(t.sideQuest || "")}</textarea>

        <label>任務清單（一行一項，會同步到今天課堂勾選）</label>
        <textarea onchange="updateModeTemplate('${t.id}','tasks',this.value)">${escapeHtml(t.tasks || "")}</textarea>
      </section>
    `).join("")}
  `;
}



/* =========================================================
   CLEAN CORE: DATE / DISPLAY UTILITIES
   ========================================================= */
function daysAgoText(dateValue){
  if(!dateValue) return "尚未備份";
  const d = new Date(dateValue);
  if(Number.isNaN(d.getTime())) return String(dateValue);

  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if(diffDays <= 0) return "0 天前";
  if(diffDays === 1) return "1 天前";
  return `${diffDays} 天前`;
}

function safeFormatDateTime(value){
  if(!value) return "尚未紀錄";
  try{
    return formatDateTime(value);
  }catch(e){
    return String(value);
  }
}

/* =========================================================
   CLEAN CORE: BACKUP SETTINGS
   - Firebase 為主同步
   - JSON 匯出/匯入為本機保險
   - Google Sheet 保留為進階備份
   ========================================================= */

/* =========================================================
   CLEAN CORE: CLOUD CONFIG
   ========================================================= */
function getCloudConfig(){
  if(!state.cloud) state.cloud = {};
  if(state.cloud.gasUrl === undefined){
    state.cloud.gasUrl = localStorage.getItem("battle_gas_url") || "";
  }
  return state.cloud;
}

function saveGasUrl(){
  const cfg = getCloudConfig();
  cfg.gasUrl = document.getElementById("gasUrlInput")?.value?.trim() || "";
  localStorage.setItem("battle_gas_url", cfg.gasUrl);
  saveState();
  markDirty?.("Google Sheet URL");
  alert("URL 已儲存");
}

/* SYNC MODULE: Backup Settings */
function renderBackupSettings(){
  ensureBackupMeta?.();
  const cloud = getCloudConfig();
  const lastBackup = daysAgoText(state.backupMeta?.lastExportAt);

  const firebaseUploadText = state.backupMeta?.lastFirebaseUploadAt
    ? safeFormatDateTime(state.backupMeta.lastFirebaseUploadAt)
    : "尚未上傳";

  const firebaseDownloadText = state.backupMeta?.lastFirebaseDownloadAt
    ? safeFormatDateTime(state.backupMeta.lastFirebaseDownloadAt)
    : "尚未讀取";

  const sheetUploadText = state.backupMeta?.lastUploadAt
    ? safeFormatDateTime(state.backupMeta.lastUploadAt)
    : "尚未上傳";

  const sheetDownloadText = state.backupMeta?.lastDownloadAt
    ? safeFormatDateTime(state.backupMeta.lastDownloadAt)
    : "尚未讀取";

  document.getElementById("settingsBody").innerHTML = `
    <section class="card">
      <h3>🔥 Firebase 主同步</h3><div class="core-health-note">v7 Clean Core：頁面路由與資料正規化已集中管理</div><div class="small-muted">模組狀態：Clean Core 已啟用</div>
      <div class="note">建議平常主要使用 Firebase。速度快，手機與 iPad 較穩定。</div>
      <div class="note">
        上次 Firebase 上傳：${escapeHtml(firebaseUploadText)}<br>
        上次 Firebase 讀取：${escapeHtml(firebaseDownloadText)}
      </div>
      <button class="btn primary" onclick="firebaseUploadAll()">🔥 上傳 Firebase</button>
      <button class="btn gold" onclick="firebaseDownloadAll()">🔥 讀取 Firebase</button>
    </section>

    <section class="card">
      <h3>💾 本機備份 / 匯入</h3>
      <div class="note">這是保險用備份。建議每週或重大修改前匯出一次 JSON。</div>
      <div class="note">上次備份：約 ${escapeHtml(lastBackup)}</div>
      <button class="btn primary" onclick="exportBackup()">匯出備份 JSON</button>
      <hr>
      <label>匯入備份 JSON</label>
      <input type="file" accept="application/json" onchange="importBackup(event)">
    </section>

    <section class="card">
      <h3>☁️ Google Sheet 備份（進階）</h3>
      <div class="note">這區保留給需要轉成試算表、列印或行政封存時使用。平常上課建議以 Firebase 為主。</div>

      <label>Google Apps Script Web App URL</label>
      <input id="gasUrlInput" value="${escapeHtml(cloud.gasUrl || "")}" placeholder="https://script.google.com/macros/s/.../exec">

      <button class="btn ghost" onclick="saveGasUrl()">儲存 URL</button>
      <button class="btn primary" onclick="testCloudConnection()">測試雲端連線</button>
      <button class="btn gold" onclick="testCloudRead('load')">測試完整讀取</button>

      <div class="note">
        上次完整雲端上傳：${escapeHtml(sheetUploadText)}<br>
        上次完整雲端讀取：${escapeHtml(sheetDownloadText)}
      </div>

      <button class="btn primary" onclick="uploadToCloud()">完整上傳到 Google Sheet</button>
      <button class="btn gold" onclick="downloadFromCloud()">完整從 Google Sheet 讀取</button>
    </section>
  `;
}


function exportBackup(){
  if(!state.backupMeta) state.backupMeta = {};
  state.backupMeta.lastExportAt = new Date().toISOString();
  saveState();
  const blob = new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `教學系統備份_${today()}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
}

function importBackup(file){
  if(!file) return;
  if(!confirm("匯入會覆蓋目前資料。系統會先自動下載一份目前資料備份，確定繼續？")) return;
  exportBackup();
  const reader = new FileReader();
  reader.onload = () => {
    try{
      state = migrateState(JSON.parse(reader.result));
      saveState();
      alert("匯入完成");
      render();
    }catch(err){
      alert("匯入失敗，請確認檔案格式");
    }
  };
  reader.readAsText(file);
}

/* =========================================================
   INIT
   ========================================================= */

document.addEventListener("click", function(e){
  const btn = e.target.closest(".nav button[data-page]");
  if(!btn) return;
  currentPage = btn.dataset.page || "classroom";
  document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active", b.dataset.page === currentPage));
  render();
});

render();
